# Character Videos — drop your 6 MP4s here

Place the provided files in this folder with EXACT names:

- Mark_idle.mp4
- Mark_thinking.mp4
- Mark_speaking.mp4
- Priya_idle.mp4
- Priya_thinking.mp4
- Priya_speaking.mp4

The app references them as `/videos/<Name>.mp4` (see `src/config/characterVideos.ts`).

- Only the SELECTED character's 3 videos are loaded (never all 6 at once).
- Idle preloads immediately; thinking/speaking preload intelligently.
- Hidden layers are paused to save mobile battery/decoder.
- Until files exist, the animated orb fallback shows — no black screen.
