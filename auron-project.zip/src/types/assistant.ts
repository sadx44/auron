export type AssistantState =
  | "disconnected"
  | "connecting"
  | "listening"
  | "thinking"
  | "speaking"
  | "error";

export type MicPermissionState = "unknown" | "prompt" | "granted" | "denied";

export type Character = "mark" | "priya";

export type CharacterVideoState = "idle" | "thinking" | "speaking";

export type ErrorType =
  | "MicrophonePermissionDenied"
  | "AudioContextError"
  | "GeminiConnectionError"
  | "SessionTimeout"
  | "ToolExecutionError"
  | "InvalidToolArguments"
  | "NetworkError"
  | "MissingApiKey"
  | "UnknownError";

export interface AssistantError {
  type: ErrorType;
  message: string;
  friendlyMessage: string;
  recoverable: boolean;
}

export interface Captions {
  user: string;
  assistant: string;
}

export interface ToolActivityItem {
  id: string;
  tool: string;
  args: Record<string, unknown>;
  status: "running" | "success" | "failed";
  result?: string;
  timestamp: number;
}

export interface LiveSessionHandlers {
  onStateChange: (state: AssistantState) => void;
  onUserTranscript: (text: string, isFinal: boolean) => void;
  onAssistantTranscript: (text: string, isFinal: boolean) => void;
  onToolActivity: (item: ToolActivityItem) => void;
  onError: (err: AssistantError) => void;
  onInterrupted: () => void;
}

export interface AudioChunkPayload {
  base64: string;
  sampleRate: number;
}
