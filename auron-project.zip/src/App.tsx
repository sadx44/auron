import { useEffect, useMemo, useState } from "react";
import {
  Settings,
  Zap,
  Globe,
  Clock,
  CheckCircle2,
  Loader2,
  KeyRound,
  Mars,
  Venus,
  Sparkles,
  Wand2,
} from "lucide-react";
import CharacterVideo from "./components/CharacterVideo";
import MicButton from "./components/MicButton";
import Waveform from "./components/Waveform";
import StatusIndicator from "./components/StatusIndicator";
import SettingsPanel from "./components/SettingsPanel";
import WebsiteBuilderView from "./website-builder/components/WebsiteBuilderView";
import { ToolManager } from "./services/ToolManager";
import { useLiveSession } from "./hooks/useLiveSession";
import { CHARACTER_META } from "./config/characterVideos";
import { getStatusCopy } from "./config/constants";
import type { Character } from "./types/assistant";
import { cn } from "./utils/cn";

export default function App() {
  const {
    assistantState,
    videoState,
    captions,
    tools,
    error,
    apiKey,
    setApiKey,
    model,
    setModel,
    voice,
    setVoice,
    character,
    setCharacter,
    animationEnabled,
    setAnimationEnabled,
    micPermission,
    sessionStartedAt,
    isLive,
    inputLevelRef,
    outputLevelRef,
    toggle,
    retry,
  } = useLiveSession();

  const [settingsOpen, setSettingsOpen] = useState(false);
  const [keyDraft, setKeyDraft] = useState("");

  // AI Website Builder Modal & Workflow State
  const [builderOpen, setBuilderOpen] = useState(false);
  const [builderPrompt, setBuilderPrompt] = useState(
    "Create a modern portfolio website for an app developer with a dark futuristic design"
  );

  const meta = CHARACTER_META[character];
  const isPriya = character === "priya";
  const status = getStatusCopy(assistantState, character);

  // Connect ToolManager buildWebsite hook & Custom Event Listener
  useEffect(() => {
    const handleVoiceBuild = (prompt: string, style?: string) => {
      const fullPrompt = style ? `${prompt} with ${style} design` : prompt;
      setBuilderPrompt(fullPrompt);
      setBuilderOpen(true);
    };

    ToolManager.setWebsiteBuilderHandler(handleVoiceBuild);

    const onCustomEvent = (e: Event) => {
      const customEv = e as CustomEvent<{ prompt: string; style?: string }>;
      if (customEv.detail?.prompt) {
        handleVoiceBuild(customEv.detail.prompt, customEv.detail.style);
      }
    };

    window.addEventListener("priya:build-website", onCustomEvent);
    return () => window.removeEventListener("priya:build-website", onCustomEvent);
  }, []);

  // Keyboard: M toggles session, 1/2 switch character, Escape closes settings
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      const typing =
        target &&
        (target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.isContentEditable);
      if (e.key === "Escape") {
        setSettingsOpen(false);
      }
      if (typing) return;
      if (e.key === "m" || e.key === "M") {
        e.preventDefault();
        toggle();
      }
      if (e.key === "1") setCharacter("mark");
      if (e.key === "2") setCharacter("priya");
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [toggle, setCharacter]);

  const latestTool = tools.length > 0 ? tools[tools.length - 1] : null;
  const showCaptions = captions.user || captions.assistant;
  const needsKey = !apiKey || apiKey.trim().length < 8;

  const toolIcon = useMemo(() => {
    if (!latestTool) return null;
    if (latestTool.tool === "openWebsite" || latestTool.tool === "searchWeb")
      return <Globe className="h-3.5 w-3.5" />;
    if (latestTool.tool === "getCurrentTime" || latestTool.tool === "getCurrentDate")
      return <Clock className="h-3.5 w-3.5" />;
    return <Zap className="h-3.5 w-3.5" />;
  }, [latestTool]);

  const switchCharacter = (c: Character) => setCharacter(c);

  return (
    <div className="relative flex min-h-dvh flex-col overflow-x-clip bg-[#04060f] text-white">
      {/* Ambient background — tinted per character */}
      <div className="pointer-events-none fixed inset-0" aria-hidden="true">
        <div
          className={cn(
            "absolute -top-40 left-1/2 h-[480px] w-[720px] -translate-x-1/2 rounded-full blur-[120px] transition-colors duration-700",
            isPriya ? "bg-fuchsia-500/[0.14]" : "bg-cyan-500/[0.14]"
          )}
        />
        <div className="absolute bottom-[-180px] left-[-120px] h-[420px] w-[420px] rounded-full bg-fuchsia-600/[0.12] blur-[110px]" />
        <div className="absolute bottom-[-120px] right-[-100px] h-[380px] w-[380px] rounded-full bg-indigo-600/[0.14] blur-[110px]" />
        <div
          className="absolute inset-0 opacity-[0.35]"
          style={{
            backgroundImage:
              "linear-gradient(rgba(255,255,255,0.035) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.035) 1px, transparent 1px)",
            backgroundSize: "44px 44px",
            maskImage: "radial-gradient(ellipse 90% 70% at 50% 40%, black 30%, transparent 75%)",
            WebkitMaskImage:
              "radial-gradient(ellipse 90% 70% at 50% 40%, black 30%, transparent 75%)",
          }}
        />
      </div>

      {/* Top bar */}
      <header className="relative z-10 flex items-center justify-between px-5 pb-2 pt-5 sm:px-8">
        <div className="flex items-center gap-2.5">
          {/* Active character avatar badge */}
          <div
            className={cn(
              "relative flex h-10 w-10 overflow-hidden rounded-xl border shadow-lg backdrop-blur-xl transition-all duration-300",
              isPriya
                ? "border-fuchsia-300/40 shadow-[0_0_20px_rgba(232,121,249,0.35)] ring-1 ring-fuchsia-400/30"
                : "border-cyan-300/40 shadow-[0_0_20px_rgba(34,211,238,0.35)] ring-1 ring-cyan-400/30"
            )}
          >
            <img
              src={meta.image}
              alt={meta.name}
              className="h-full w-full object-cover object-top"
            />
          </div>
          <div className="leading-tight">
            <div className="flex items-center gap-1.5">
              <h1 className="text-[15px] font-extrabold tracking-[0.14em]">
                {meta.name.toUpperCase()}
              </h1>
              <span className="rounded bg-white/10 px-1 py-0.2 text-[9px] font-bold tracking-wider text-slate-300">
                AI
              </span>
            </div>
            <p className="text-[10px] font-medium tracking-[0.24em] text-slate-400">
              AURON COMPANION
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* AI Website Builder Primary Header Action */}
          <button
            onClick={() => {
              setBuilderPrompt("Create a modern portfolio website for an app developer with a dark futuristic design");
              setBuilderOpen(true);
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full border border-cyan-400/40 bg-gradient-to-r from-cyan-500/20 to-purple-500/20 hover:from-cyan-500/30 hover:to-purple-500/30 text-white text-xs font-bold transition shadow-md shadow-cyan-500/10 active:scale-95"
            title="Launch Autonomous AI Website Builder"
          >
            <Globe className="w-3.5 h-3.5 text-cyan-300 animate-pulse" />
            <span className="hidden sm:inline">AI Website Builder</span>
            <span className="sm:hidden">Builder</span>
            <span className="hidden md:inline-block px-1.5 py-0.2 rounded-full bg-cyan-400/20 text-[9px] text-cyan-200 uppercase font-mono">
              NEW
            </span>
          </button>

          <div
            className={cn(
              "hidden items-center gap-1.5 rounded-full border px-3 py-1.5 text-[11px] font-semibold backdrop-blur-xl sm:flex",
              assistantState === "listening" || assistantState === "speaking"
                ? "border-emerald-300/20 bg-emerald-400/10 text-emerald-200"
                : "border-white/10 bg-white/5 text-slate-400"
            )}
          >
            <span
              className={cn(
                "h-1.5 w-1.5 rounded-full",
                assistantState === "listening" || assistantState === "speaking"
                  ? "animate-pulse bg-emerald-400"
                  : "bg-slate-500"
              )}
            />
            {assistantState === "listening" || assistantState === "speaking" ? "Online" : "Standby"}
          </div>

          <button
            onClick={() => setSettingsOpen(true)}
            aria-label="Open settings"
            className="flex h-10 w-10 items-center justify-center rounded-full border border-white/10 bg-white/[0.06] text-slate-300 backdrop-blur-xl transition hover:bg-white/[0.12] hover:text-white active:scale-95"
          >
            <Settings className="h-[18px] w-[18px]" />
          </button>
        </div>
      </header>

      {/* Main Container */}
      <main className="relative z-10 mx-auto flex w-full max-w-md flex-1 flex-col items-center px-5 pb-6 sm:max-w-lg">
        {/* Character switcher chips with image thumbnails */}
        <div className="mt-1 flex items-center gap-2.5" role="group" aria-label="Quick character switch">
          {(
            [
              { id: "mark" as Character, icon: Mars },
              { id: "priya" as Character, icon: Venus },
            ]
          ).map(({ id, icon: Icon }) => {
            const active = character === id;
            const m = CHARACTER_META[id];
            const isM = id === "mark";
            return (
              <button
                key={id}
                onClick={() => switchCharacter(id)}
                aria-pressed={active}
                aria-label={`Switch to ${m.name}`}
                className={cn(
                  "group flex items-center gap-2 rounded-full border py-1 pl-1.5 pr-3 text-xs font-bold backdrop-blur-xl transition-all duration-200 active:scale-95",
                  active
                    ? isM
                      ? "border-cyan-300/60 bg-cyan-400/15 text-cyan-100 shadow-[0_0_24px_rgba(34,211,238,0.35)] ring-1 ring-cyan-300/40"
                      : "border-fuchsia-300/60 bg-fuchsia-400/15 text-fuchsia-100 shadow-[0_0_24px_rgba(232,121,249,0.35)] ring-1 ring-fuchsia-300/40"
                    : "border-white/10 bg-white/[0.04] text-slate-400 hover:border-white/25 hover:text-white"
                )}
              >
                <div className="relative h-6 w-6 overflow-hidden rounded-full border border-white/20">
                  <img src={m.image} alt={m.name} className="h-full w-full object-cover object-top" />
                </div>
                <span>{m.name}</span>
                <Icon className="h-3 w-3 opacity-60" />
              </button>
            );
          })}
          <span className="hidden font-mono text-[10px] text-slate-600 sm:inline">Press 1 or 2</span>
        </div>

        {/* ── OPTION B: CHARACTER VISUAL HERO (MARK: Boy / PRIYA: Girl) ── */}
        <section
          aria-label={`${meta.name} visual — ${videoState}`}
          className="relative mt-3 w-full"
          style={{ height: "min(52dvh, 430px)" }}
        >
          {/* Dynamic Ambient Glow Frame */}
          <div
            className={cn(
              "absolute -inset-3 rounded-[30px] blur-2xl transition-all duration-700",
              assistantState === "speaking"
                ? isPriya
                  ? "bg-fuchsia-500/35"
                  : "bg-cyan-500/35"
                : assistantState === "thinking"
                  ? "bg-violet-500/30"
                  : assistantState === "listening"
                    ? "bg-emerald-500/25"
                    : isPriya
                      ? "bg-fuchsia-500/15"
                      : "bg-cyan-500/15"
            )}
            aria-hidden="true"
          />

          {/* Main Frame Box */}
          <div
            className={cn(
              "relative h-full w-full overflow-hidden rounded-[26px] border bg-black/50 shadow-2xl backdrop-blur-xl transition-all duration-500",
              isPriya
                ? "border-fuchsia-300/30 shadow-[0_0_40px_rgba(232,121,249,0.2)]"
                : "border-cyan-300/30 shadow-[0_0_40px_rgba(34,211,238,0.2)]"
            )}
          >
            {/* The Character Visual Engine (Mark / Priya images + video layers) */}
            <CharacterVideo
              character={character}
              state={videoState}
              assistantState={assistantState}
              inputLevelRef={inputLevelRef}
              outputLevelRef={outputLevelRef}
              animationEnabled={animationEnabled}
            />

            {/* Top-left: Character & State Badge */}
            <div className="absolute left-3 top-3 flex items-center gap-2">
              <span
                className={cn(
                  "flex items-center gap-1.5 rounded-full border px-3 py-1 text-[11px] font-extrabold tracking-wide backdrop-blur-xl shadow-lg",
                  isPriya
                    ? "border-fuchsia-200/40 bg-black/65 text-fuchsia-100"
                    : "border-cyan-200/40 bg-black/65 text-cyan-100"
                )}
              >
                <Sparkles className="h-3 w-3" />
                {meta.name}
              </span>
              <span className="rounded-full border border-white/15 bg-black/65 px-2.5 py-1 font-mono text-[10px] uppercase tracking-wider text-slate-300 backdrop-blur-xl shadow-lg">
                {assistantState === "speaking" ? "Speaking" : assistantState === "thinking" ? "Thinking" : assistantState === "listening" ? "Listening" : "Idle"}
              </span>
            </div>

            {/* Top-right: Live Avatar Pill & Tagline */}
            <div className="absolute right-3 top-3 flex items-center gap-1.5">
              <span className="flex items-center gap-1 rounded-full border border-emerald-400/30 bg-emerald-500/20 px-2.5 py-1 text-[10px] font-extrabold tracking-wider text-emerald-300 backdrop-blur-xl shadow-lg">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
                LIVE
              </span>
              <span className="hidden sm:inline-block rounded-full border border-white/10 bg-black/55 px-2.5 py-1 text-[10px] font-medium text-slate-300 backdrop-blur-xl">
                {meta.tagline}
              </span>
            </div>

            {/* Listening state active border ring */}
            {assistantState === "listening" && (
              <div
                className="pointer-events-none absolute inset-0 rounded-[26px] border-2 border-emerald-300/50"
                style={{
                  animation: animationEnabled ? "auron-pulse-ring 1.8s ease-in-out infinite" : "none",
                }}
              />
            )}
          </div>
        </section>

        {/* Captions — minimal, live subtitles */}
        <div className="mt-3 flex min-h-[56px] w-full flex-col items-center justify-start gap-1.5">
          {!showCaptions ? (
            <p className="max-w-[300px] text-center text-[13px] leading-relaxed text-slate-400">
              {assistantState === "disconnected" && (
                <>Tap the mic and talk to {meta.name} — real-time voice AI.</>
              )}
              {assistantState === "connecting" && <>Linking neural audio with {meta.name}…</>}
              {(assistantState === "listening" ||
                assistantState === "speaking" ||
                assistantState === "thinking") && (
                <>{status.title} · {status.sub}</>
              )}
              {assistantState === "error" && (
                <span className="text-rose-300">{error?.friendlyMessage ?? "Let's try that again."}</span>
              )}
            </p>
          ) : (
            <>
              {captions.assistant && (
                <div className="w-full rounded-2xl border border-white/10 bg-white/[0.06] px-4 py-2.5 text-center backdrop-blur-xl">
                  <p className="line-clamp-2 text-[13px] font-medium leading-snug text-slate-100">
                    <span
                      className={cn(
                        "mr-1.5 inline-block h-1.5 w-1.5 rounded-full align-middle",
                        isPriya ? "bg-fuchsia-300" : "bg-cyan-300"
                      )}
                    />
                    {captions.assistant.slice(-220)}
                  </p>
                </div>
              )}
              {captions.user && (
                <p className="line-clamp-1 max-w-full px-2 text-xs text-slate-400">
                  <span className="text-slate-500">you · </span>
                  {captions.user.slice(-140)}
                </p>
              )}
            </>
          )}
        </div>

        {/* Waveform */}
        <div className="mt-1 w-full">
          <Waveform state={assistantState} inputLevelRef={inputLevelRef} outputLevelRef={outputLevelRef} />
        </div>

        {/* Status Indicator */}
        <div className="mt-1.5">
          <StatusIndicator state={assistantState} labelOverride={status} />
        </div>

        {/* Central Glowing Mic Button */}
        <div className="mt-4">
          <MicButton state={assistantState} onToggle={toggle} />
        </div>

        <p className="mt-3 text-[11px] tracking-wide text-slate-500">
          {assistantState === "disconnected" && `Tap to start · speak with ${meta.name}`}
          {assistantState === "connecting" && "Establishing secure voice link…"}
          {assistantState === "listening" && "Listening — interrupt anytime"}
          {assistantState === "thinking" && `${meta.name} is thinking…`}
          {assistantState === "speaking" && "Speaking — talk to barge in"}
          {assistantState === "error" && "Tap retry, or check settings"}
        </p>

        {/* Quick Website Builder Launcher Capsule */}
        <button
          onClick={() => {
            setBuilderPrompt("Create a modern portfolio website for an app developer with a dark futuristic design");
            setBuilderOpen(true);
          }}
          className="mt-2.5 flex items-center gap-2 px-3.5 py-1.5 rounded-full border border-cyan-400/25 bg-black/40 hover:bg-cyan-500/10 hover:border-cyan-400/40 text-[11px] text-cyan-200 transition shadow-sm group active:scale-95"
          title="Open AI Website Builder"
        >
          <Wand2 className="w-3.5 h-3.5 text-cyan-400 group-hover:rotate-12 transition-transform" />
          <span>Say or tap: <strong>"{meta.name}, build me a website"</strong></span>
          <span className="text-slate-500">&rarr;</span>
        </button>

        {/* Tool activity toast */}
        {latestTool && (
          <div
            className={cn(
              "mt-4 flex w-full items-center gap-3 rounded-2xl border px-4 py-3 backdrop-blur-xl transition-all",
              latestTool.status === "running"
                ? "border-cyan-300/20 bg-cyan-400/[0.07]"
                : latestTool.status === "success"
                  ? "border-emerald-300/20 bg-emerald-400/[0.07]"
                  : "border-rose-300/20 bg-rose-400/[0.07]"
            )}
            role="status"
            aria-live="polite"
          >
            <span
              className={cn(
                "flex h-8 w-8 shrink-0 items-center justify-center rounded-full",
                latestTool.status === "running"
                  ? "bg-cyan-400/20 text-cyan-200"
                  : latestTool.status === "success"
                    ? "bg-emerald-400/20 text-emerald-200"
                    : "bg-rose-400/20 text-rose-200"
              )}
            >
              {latestTool.status === "running" ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : latestTool.status === "success" ? (
                <CheckCircle2 className="h-4 w-4" />
              ) : (
                toolIcon
              )}
            </span>
            <div className="min-w-0 flex-1">
              <p className="truncate text-[13px] font-semibold text-white">
                {latestTool.status === "running"
                  ? `Running ${latestTool.tool}…`
                  : latestTool.status === "success"
                    ? `${latestTool.tool} done`
                    : `${latestTool.tool} blocked`}
              </p>
              <p className="truncate text-xs text-slate-400">
                {latestTool.result ?? JSON.stringify(latestTool.args)}
              </p>
            </div>
          </div>
        )}

        {/* Error banner */}
        {assistantState === "error" && (
          <div className="mt-3 flex w-full items-center justify-between gap-3 rounded-2xl border border-rose-300/20 bg-rose-500/[0.08] px-4 py-3 backdrop-blur-xl">
            <p className="flex-1 text-[13px] leading-snug text-rose-100">
              {error?.friendlyMessage ?? "Oops, I lost the connection. Let's try that again."}
            </p>
            <button
              onClick={retry}
              className="shrink-0 rounded-full bg-rose-400/20 px-4 py-2 text-xs font-bold text-rose-100 transition hover:bg-rose-400/30 active:scale-95"
            >
              Retry
            </button>
          </div>
        )}

        {/* Key prompt if missing */}
        {needsKey && assistantState === "disconnected" && (
          <div className="mt-3 w-full rounded-2xl border border-amber-300/20 bg-amber-400/[0.07] p-4 backdrop-blur-xl">
            <div className="mb-2 flex items-center gap-2">
              <KeyRound className="h-4 w-4 text-amber-300" />
              <p className="text-[13px] font-bold text-amber-100">Add your Gemini key to wake {meta.name}</p>
            </div>
            <div className="flex gap-2">
              <input
                type="password"
                value={keyDraft}
                onChange={(e) => setKeyDraft(e.target.value)}
                placeholder="AIza…"
                aria-label="Gemini API key"
                className="min-w-0 flex-1 rounded-xl border border-white/10 bg-black/40 px-3 py-2 text-sm text-white placeholder:text-slate-600 outline-none focus:border-amber-300/50"
              />
              <button
                onClick={() => {
                  if (keyDraft.trim().length >= 8) {
                    setApiKey(keyDraft.trim());
                    setKeyDraft("");
                  } else {
                    setSettingsOpen(true);
                  }
                }}
                className="shrink-0 rounded-xl bg-gradient-to-br from-amber-400 to-orange-500 px-4 py-2 text-xs font-extrabold text-black transition hover:brightness-110 active:scale-95"
              >
                Save
              </button>
            </div>
            <button
              onClick={() => setSettingsOpen(true)}
              className="mt-2 text-[11px] text-amber-200/80 hover:text-amber-100 hover:underline"
            >
              Where do I get a key? Open control deck →
            </button>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="relative z-10 flex flex-col items-center justify-center gap-1.5 px-5 pb-5">
        <div className="flex items-center gap-1.5 rounded-full border border-white/10 bg-white/[0.04] px-3 py-1 backdrop-blur-xl">
          <span
            className={cn(
              "h-1.5 w-1.5 animate-pulse rounded-full",
              isPriya ? "bg-fuchsia-300" : "bg-cyan-300"
            )}
          />
          <p className="font-mono text-[10px] font-semibold tracking-[0.14em] text-slate-300">
            {model || "gemini-3.8-flash-live-preview"}
          </p>
        </div>
        <p className="text-[10px] tracking-[0.2em] text-slate-600">
          {meta.name.toUpperCase()} · GEMINI LIVE · AUDIO-TO-AUDIO
        </p>
      </footer>

      {/* Slide-in Control Deck */}
      <SettingsPanel
        open={settingsOpen}
        onClose={() => setSettingsOpen(false)}
        apiKey={apiKey}
        onApiKeyChange={setApiKey}
        model={model}
        onModelChange={setModel}
        voice={voice}
        onVoiceChange={setVoice}
        character={character}
        onCharacterChange={setCharacter}
        animationEnabled={animationEnabled}
        onAnimationEnabledChange={setAnimationEnabled}
        micPermission={micPermission}
        connection={assistantState}
        sessionStartedAt={sessionStartedAt}
        isLive={isLive}
      />

      {/* Autonomous AI Website Builder View */}
      {builderOpen && (
        <WebsiteBuilderView
          initialPrompt={builderPrompt}
          apiKey={apiKey}
          characterName={meta.name}
          onClose={() => setBuilderOpen(false)}
        />
      )}
    </div>
  );
}
