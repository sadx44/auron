// AudioPlayer — Gemini PCM 24kHz chunks → smooth streaming playback with queue.
// Low-latency scheduling, interruption support, output level metering.

import { AUDIO_OUTPUT_SAMPLE_RATE } from "../config/constants";

export class AudioPlayer {
  private ctx: AudioContext | null = null;
  private gain: GainNode | null = null;
  private analyser: AnalyserNode | null = null;
  private sources = new Set<AudioBufferSourceNode>();
  private nextStart = 0;
  private timeDomain: Uint8Array<ArrayBuffer> | null = null;
  private smoothedLevel = 0;
  private onFirstChunk: (() => void) | null = null;
  private onDrained: (() => void) | null = null;
  private drainTimer: number | null = null;

  setCallbacks(cb: { onFirstChunk?: () => void; onDrained?: () => void }) {
    this.onFirstChunk = cb.onFirstChunk ?? null;
    this.onDrained = cb.onDrained ?? null;
  }

  private ensureContext() {
    if (this.ctx) return;
    const AC: typeof AudioContext | undefined =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AC) throw new Error("AudioContext not supported");
    this.ctx = new AC({ sampleRate: AUDIO_OUTPUT_SAMPLE_RATE, latencyHint: "interactive" });
    this.gain = this.ctx.createGain();
    this.gain.gain.value = 1.0;
    this.analyser = this.ctx.createAnalyser();
    this.analyser.fftSize = 1024;
    this.analyser.smoothingTimeConstant = 0.55;
    this.gain.connect(this.analyser);
    this.analyser.connect(this.ctx.destination);
    this.nextStart = this.ctx.currentTime;
  }

  async resume() {
    this.ensureContext();
    if (this.ctx!.state === "suspended") {
      try {
        await this.ctx!.resume();
      } catch {
        /* ignore */
      }
    }
  }

  get isPlaying(): boolean {
    if (!this.ctx) return false;
    return this.nextStart > this.ctx.currentTime + 0.05 && this.sources.size > 0;
  }

  get pendingSeconds(): number {
    if (!this.ctx) return 0;
    return Math.max(0, this.nextStart - this.ctx.currentTime);
  }

  getOutputLevel(): number {
    if (!this.analyser || !this.ctx) return 0;
    if (this.sources.size === 0) {
      this.smoothedLevel *= 0.85;
      return this.smoothedLevel;
    }
    if (!this.timeDomain) this.timeDomain = new Uint8Array(new ArrayBuffer(this.analyser.fftSize));
    this.analyser.getByteTimeDomainData(this.timeDomain);
    let sum = 0;
    for (let i = 0; i < this.timeDomain.length; i += 2) {
      const v = (this.timeDomain[i] - 128) / 128;
      sum += v * v;
    }
    const rms = Math.sqrt(sum / (this.timeDomain.length / 2));
    const boosted = Math.min(1, rms * 4);
    this.smoothedLevel = this.smoothedLevel * 0.65 + boosted * 0.35;
    return this.smoothedLevel;
  }

  private base64ToFloat32(b64: string): Float32Array {
    const binary = atob(b64);
    const len = binary.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) bytes[i] = binary.charCodeAt(i);
    // PCM16 LE → float32
    const count = Math.floor(bytes.length / 2);
    const out = new Float32Array(count);
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    for (let i = 0; i < count; i++) {
      const s = view.getInt16(i * 2, true);
      out[i] = s / 32768;
    }
    return out;
  }

  async playChunk(base64: string) {
    if (!base64) return;
    this.ensureContext();
    await this.resume();
    const ctx = this.ctx!;
    let samples: Float32Array;
    try {
      samples = this.base64ToFloat32(base64);
    } catch {
      return;
    }
    if (samples.length === 0) return;

    const wasIdle = this.sources.size === 0 && this.pendingSeconds <= 0.02;
    const buffer = ctx.createBuffer(1, samples.length, AUDIO_OUTPUT_SAMPLE_RATE);
    buffer.copyToChannel(samples as unknown as Float32Array<ArrayBuffer>, 0);

    const src = ctx.createBufferSource();
    src.buffer = buffer;
    src.connect(this.gain!);

    const startAt = Math.max(ctx.currentTime + 0.02, this.nextStart);
    const hadCallback = this.onFirstChunk;
    try {
      src.start(startAt);
    } catch {
      return;
    }
    this.sources.add(src);
    this.nextStart = startAt + buffer.duration;

    if (wasIdle && hadCallback) {
      try {
        hadCallback?.();
      } catch {
        /* noop */
      }
    }

    src.onended = () => {
      this.sources.delete(src);
      try {
        src.disconnect();
      } catch {
        /* noop */
      }
      this.scheduleDrainCheck();
    };
    this.clearDrainTimer();
  }

  private clearDrainTimer() {
    if (this.drainTimer !== null) {
      window.clearTimeout(this.drainTimer);
      this.drainTimer = null;
    }
  }

  private scheduleDrainCheck() {
    this.clearDrainTimer();
    const remaining = this.pendingSeconds;
    const wait = Math.max(80, remaining * 1000 + 120);
    this.drainTimer = window.setTimeout(() => {
      if (this.sources.size === 0 && this.pendingSeconds <= 0.05) {
        try {
          this.onDrained?.();
        } catch {
          /* noop */
        }
      } else {
        this.scheduleDrainCheck();
      }
    }, wait);
  }

  /** Barge-in: stop everything immediately. */
  interrupt() {
    this.clearDrainTimer();
    if (!this.ctx) return;
    const now = this.ctx.currentTime;
    const copy = Array.from(this.sources);
    this.sources.clear();
    for (const s of copy) {
      try {
        s.onended = null;
        s.stop(now);
      } catch {
        /* already stopped */
      }
      try {
        s.disconnect();
      } catch {
        /* noop */
      }
    }
    this.nextStart = now;
    this.smoothedLevel = 0;
  }

  stop() {
    this.interrupt();
    if (this.ctx) {
      const c = this.ctx;
      this.ctx = null;
      this.gain = null;
      this.analyser = null;
      this.timeDomain = null;
      c.close().catch(() => undefined);
    }
  }
}
