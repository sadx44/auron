// ToolManager — Gemini Live function calling: definitions, validation, execution.

import { Type } from "@google/genai";

export const TOOL_DECLARATIONS = [
  {
    name: "openWebsite",
    description:
      "Open a website URL in a new browser tab when the user asks to open, visit, launch or go to a website. Always use a full https URL.",
    parameters: {
      type: Type.OBJECT,
      properties: {
        url: {
          type: Type.STRING,
          description: "Full https URL to open, e.g. https://www.youtube.com",
        },
        label: {
          type: Type.STRING,
          description: "Short human label of the site, e.g. YouTube",
        },
      },
      required: ["url"],
    },
  },
  {
    name: "searchWeb",
    description:
      "Search the web with Google when the user asks to search, look up or google something. Opens a Google search results tab.",
    parameters: {
      type: Type.OBJECT,
      properties: {
        query: {
          type: Type.STRING,
          description: "Search query text",
        },
      },
      required: ["query"],
    },
  },
  {
    name: "getCurrentTime",
    description: "Get the current local time. Use when the user asks for the time.",
    parameters: {
      type: Type.OBJECT,
      properties: {},
    },
  },
  {
    name: "getCurrentDate",
    description: "Get today's date. Use when the user asks for the date, day or year.",
    parameters: {
      type: Type.OBJECT,
      properties: {},
    },
  },
  {
    name: "buildWebsite",
    description:
      "Activate the AI Website Builder to design, code, test, and preview a complete website whenever the user asks to create, build, generate or code a website (e.g. portfolio, netflix clone, saas page, anime site, etc.).",
    parameters: {
      type: Type.OBJECT,
      properties: {
        prompt: {
          type: Type.STRING,
          description: "Full natural language description of the website to build",
        },
        style: {
          type: Type.STRING,
          description: "Design style such as dark futuristic, neon cyberpunk, minimal, or glassmorphism",
        },
      },
      required: ["prompt"],
    },
  },
];

export const LIVE_TOOLS = [{ functionDeclarations: TOOL_DECLARATIONS }];

export interface ToolResult {
  success: boolean;
  result: string;
  openedUrl?: string;
}

function normalizeUrl(raw: unknown): { ok: boolean; url?: string; reason?: string } {
  if (typeof raw !== "string" || raw.trim().length === 0) {
    return { ok: false, reason: "URL is empty" };
  }
  let candidate = raw.trim();
  // Block dangerous schemes outright
  const lower = candidate.toLowerCase();
  if (
    lower.startsWith("javascript:") ||
    lower.startsWith("data:") ||
    lower.startsWith("file:") ||
    lower.startsWith("blob:") ||
    lower.startsWith("vbscript:")
  ) {
    return { ok: false, reason: "Blocked protocol" };
  }
  if (!/^https?:\/\//i.test(candidate)) {
    candidate = "https://" + candidate;
  }
  try {
    const u = new URL(candidate);
    if (u.protocol !== "https:" && u.protocol !== "http:") {
      return { ok: false, reason: "Only https/http allowed" };
    }
    if (!u.hostname || !u.hostname.includes(".")) {
      // allow localhost for dev
      if (u.hostname !== "localhost") return { ok: false, reason: "Invalid hostname" };
    }
    if (u.username || u.password) return { ok: false, reason: "Credentials in URL blocked" };
    if (candidate.length > 2048) return { ok: false, reason: "URL too long" };
    return { ok: true, url: u.toString() };
  } catch {
    return { ok: false, reason: "Invalid URL format" };
  }
}

export class ToolManager {
  private static websiteBuilderHandler: ((prompt: string, style?: string) => void) | null = null;

  static setWebsiteBuilderHandler(handler: (prompt: string, style?: string) => void) {
    this.websiteBuilderHandler = handler;
  }

  async execute(name: string, args: Record<string, unknown> = {}): Promise<ToolResult> {
    switch (name) {
      case "buildWebsite":
        return this.buildWebsite(args);
      case "openWebsite":
        return this.openWebsite(args);
      case "searchWeb":
        return this.searchWeb(args);
      case "getCurrentTime":
        return this.getTime();
      case "getCurrentDate":
        return this.getDate();
      default:
        return { success: false, result: `Unknown tool: ${name}` };
    }
  }

  private buildWebsite(args: Record<string, unknown>): ToolResult {
    const prompt = typeof args.prompt === "string" ? args.prompt.trim() : "Modern Portfolio Website";
    const style = typeof args.style === "string" ? args.style.trim() : undefined;

    if (ToolManager.websiteBuilderHandler) {
      ToolManager.websiteBuilderHandler(prompt, style);
    }

    // Also dispatch custom event for decouple handling
    if (typeof window !== "undefined") {
      window.dispatchEvent(
        new CustomEvent("priya:build-website", {
          detail: { prompt, style },
        })
      );
    }

    return {
      success: true,
      result: `AI Website Builder launched successfully. Designing and synthesizing the code for: "${prompt}". Preview environment is opening now.`,
    };
  }

  private openWebsite(args: Record<string, unknown>): ToolResult {
    const check = normalizeUrl(args.url);
    if (!check.ok || !check.url) {
      return { success: false, result: `Could not open website: ${check.reason || "invalid URL"}.` };
    }
    try {
      const opened = window.open(check.url, "_blank", "noopener,noreferrer");
      if (!opened) {
        // Popup blocked — fallback to same-tab safe navigation? Keep new-tab intent, report it.
        return {
          success: false,
          result: `Popup was blocked by the browser for ${check.url}. Ask the user to allow popups, or tap the link.`,
          openedUrl: check.url,
        };
      }
      const label =
        typeof args.label === "string" && args.label.length > 0
          ? args.label
          : new URL(check.url).hostname;
      return {
        success: true,
        result: `Successfully opened ${label} (${check.url}) in a new tab.`,
        openedUrl: check.url,
      };
    } catch (e) {
      return { success: false, result: `Failed to open website: ${(e as Error).message}` };
    }
  }

  private searchWeb(args: Record<string, unknown>): ToolResult {
    const q = typeof args.query === "string" ? args.query.trim() : "";
    if (!q) return { success: false, result: "Search query is empty." };
    const url = `https://www.google.com/search?q=${encodeURIComponent(q)}`;
    try {
      const opened = window.open(url, "_blank", "noopener,noreferrer");
      if (!opened) {
        return { success: false, result: `Popup blocked for search "${q}". Allow popups to see results.` };
      }
      return { success: true, result: `Searched Google for "${q}" and opened results in a new tab.` };
    } catch (e) {
      return { success: false, result: `Search failed: ${(e as Error).message}` };
    }
  }

  private getTime(): ToolResult {
    const now = new Date();
    const str = now.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
    return { success: true, result: `The current local time is ${str}.` };
  }

  private getDate(): ToolResult {
    const now = new Date();
    const str = now.toLocaleDateString([], {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    });
    return { success: true, result: `Today is ${str}.` };
  }
}
