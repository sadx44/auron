// LiveSession — Gemini Live API connection layer.
// Handles: connect, audio in/out, tool calls, interruptions, errors, cleanup.

import { GoogleGenAI, Modality, StartSensitivity, EndSensitivity } from "@google/genai";
import type { AssistantState, Character, LiveSessionHandlers, ToolActivityItem } from "../types/assistant";
import { getGreetingPrompt, getSystemInstruction } from "../config/constants";
import { LIVE_TOOLS, ToolManager } from "./ToolManager";
import type { AudioPlayer } from "./AudioPlayer";

interface ConnectOpts {
  apiKey: string;
  model: string;
  voice: string;
  character: Character;
  player: AudioPlayer;
  handlers: LiveSessionHandlers;
}

let toolId = 0;

export class LiveSession {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  private session: any = null;
  private ai: GoogleGenAI | null = null;
  private toolManager = new ToolManager();
  private handlers: LiveSessionHandlers | null = null;
  private player: AudioPlayer | null = null;
  private state: AssistantState = "disconnected";
  private connectTimeout: number | null = null;
  private closed = false;

  getState(): AssistantState {
    return this.state;
  }

  private setState(s: AssistantState) {
    this.state = s;
    try {
      this.handlers?.onStateChange(s);
    } catch {
      /* noop */
    }
  }

  async connect({ apiKey, model, voice, character, player, handlers }: ConnectOpts): Promise<void> {
    this.disconnect();
    this.closed = false;
    this.handlers = handlers;
    this.player = player;
    this.setState("connecting");

    if (!apiKey || apiKey.trim().length < 8) {
      this.fail("MissingApiKey", "Add your Gemini API key to wake Auron up.", false);
      throw new Error("MissingApiKey");
    }

    // Connection timeout guard
    this.clearTimeout();
    this.connectTimeout = window.setTimeout(() => {
      if (this.state === "connecting") {
        this.fail("SessionTimeout", "Connection timed out. Check network and retry.", true);
        this.disconnect();
      }
    }, 20000);

    try {
      this.ai = new GoogleGenAI({ apiKey: apiKey.trim() });

      const sessionPromise = this.ai.live.connect({
        model,
        config: {
          responseModalities: [Modality.AUDIO],
          systemInstruction: { parts: [{ text: getSystemInstruction(character) }] },
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: voice } },
          },
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          tools: LIVE_TOOLS as any,
          inputAudioTranscription: {},
          outputAudioTranscription: {},
          realtimeInputConfig: {
            automaticActivityDetection: {
              disabled: false,
              startOfSpeechSensitivity: StartSensitivity.START_SENSITIVITY_HIGH,
              endOfSpeechSensitivity: EndSensitivity.END_SENSITIVITY_HIGH,
              prefixPaddingMs: 20,
              silenceDurationMs: 100,
            },
          },
        },
        callbacks: {
          onopen: () => {
            this.clearTimeout();
            if (this.closed) return;
            this.setState("listening");
            // Gentle greeting trigger — voice-first, not a chat UI.
            // Small delay so mic pipeline is ready.
            window.setTimeout(() => {
              if (this.closed || !this.session) return;
              try {
                this.session.sendClientContent({
                  turns: [
                    {
                      role: "user",
                      parts: [{ text: getGreetingPrompt(character) }],
                    },
                  ],
                  turnComplete: true,
                });
              } catch {
                /* greeting optional */
              }
            }, 400);
          },
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          onmessage: (msg: any) => this.handleMessage(msg),
          onerror: (e: ErrorEvent) => {
            console.warn("[Auron] Live error", e);
            if (this.state === "connecting") {
              this.fail(
                "GeminiConnectionError",
                "Could not reach Gemini Live. Verify API key and network.",
                true
              );
            }
          },
          onclose: (e: CloseEvent) => {
            this.clearTimeout();
            if (this.closed) return;
            // If we were live and socket closed unexpectedly → error state
            if (this.state !== "disconnected" && this.state !== "error") {
              console.warn("[Auron] Live closed", e?.reason);
              this.fail("NetworkError", "Connection lost. Tap the microphone to reconnect.", true);
            }
          },
        },
      });

      this.session = await sessionPromise;
    } catch (e: unknown) {
      this.clearTimeout();
      console.error("[Auron] connect failed", e);
      const msg = (e as Error)?.message || "";
      if (/api key|API_KEY|403|401/i.test(msg)) {
        this.fail("GeminiConnectionError", "Invalid API key. Check your Gemini key and retry.", true);
      } else if (/network|fetch|websocket|failed/i.test(msg)) {
        this.fail("NetworkError", "Network wobble detected. Check your connection and retry.", true);
      } else if ((e as Error)?.message === "MissingApiKey") {
        // already handled
      } else {
        this.fail("GeminiConnectionError", "Oops, I lost the connection. Let's try that again.", true);
      }
      throw e;
    }
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  private async handleMessage(msg: any) {
    if (this.closed) return;
    try {
      // 1) Setup complete
      if (msg?.setupComplete) {
        this.setState("listening");
        return;
      }

      const serverContent = msg?.serverContent;
      const toolCall = msg?.toolCall;

      // 2) Interruption — user barged in, flush speaker
      if (serverContent?.interrupted) {
        try {
          this.player?.interrupt();
        } catch {
          /* noop */
        }
        this.handlers?.onInterrupted();
        this.setState("listening");
        return;
      }

      // 3) Transcriptions (live captions, not chat)
      const inTr = serverContent?.inputTranscription;
      if (inTr?.text) {
        this.handlers?.onUserTranscript(inTr.text, false);
        if (this.state === "listening" || this.state === "speaking") {
          // user started speaking — show thinking briefly if Auron was speaking
        }
      }
      const outTr = serverContent?.outputTranscription;
      if (outTr?.text) {
        this.handlers?.onAssistantTranscript(outTr.text, false);
      }

      // 4) Audio output — 24kHz PCM base64
      const parts = serverContent?.modelTurn?.parts as Array<any> | undefined;
      if (parts && parts.length > 0) {
        let gotAudio = false;
        for (const p of parts) {
          const b64 = p?.inlineData?.data;
          if (typeof b64 === "string" && b64.length > 0) {
            gotAudio = true;
            const cur = this.state as string;
            if (cur !== "speaking") this.setState("speaking");
            try {
              await this.player?.playChunk(b64);
            } catch (e) {
              console.warn("[Auron] playChunk failed", e);
            }
          }
          // Text parts may also arrive — fold into captions
          if (typeof p?.text === "string" && p.text.length > 0) {
            this.handlers?.onAssistantTranscript(p.text, false);
          }
        }
        if (gotAudio && this.state !== "speaking") this.setState("speaking");
      }

      // Generation started → thinking (if not already speaking)
      if (serverContent && !parts && this.state === "listening") {
        // Heuristic: server acknowledged input, model is working
        if (serverContent?.generationComplete === false || serverContent?.modelTurn) {
          this.setState("thinking");
        }
      }

      // 5) Turn complete → back to listening (player drain handles exact timing via hook)
      if (serverContent?.turnComplete === true) {
        // If no audio pending, go listening immediately; else hook's drain callback will do it.
        const pending = this.player?.pendingSeconds ?? 0;
        if (pending <= 0.05) {
          if (this.state === "thinking" || this.state === "speaking") this.setState("listening");
        } else {
          // stay speaking until drained
          if (this.state === "thinking") this.setState("speaking");
        }
        // finalize captions
        this.handlers?.onUserTranscript("", true);
        this.handlers?.onAssistantTranscript("", true);
      }

      // 6) Tool calls — must respond immediately
      if (toolCall?.functionCalls && Array.isArray(toolCall.functionCalls)) {
        for (const fc of toolCall.functionCalls) {
          const name = fc?.name as string;
          const args = (fc?.args as Record<string, unknown>) ?? {};
          const id = (fc?.id as string) ?? `tool-${++toolId}`;
          const item: ToolActivityItem = {
            id,
            tool: name,
            args,
            status: "running",
            timestamp: Date.now(),
          };
          this.handlers?.onToolActivity(item);
          // Execute
          try {
            const res = await this.toolManager.execute(name, args);
            const updated: ToolActivityItem = {
              ...item,
              status: res.success ? "success" : "failed",
              result: res.result,
              timestamp: Date.now(),
            };
            this.handlers?.onToolActivity(updated);
            // Send response back immediately
            try {
              this.session?.sendToolResponse({
                functionResponses: [
                  {
                    id,
                    name,
                    response: { result: res.result },
                  },
                ],
              });
            } catch (e) {
              console.warn("[Auron] sendToolResponse failed", e);
            }
          } catch (e) {
            const updated: ToolActivityItem = {
              ...item,
              status: "failed",
              result: `Tool failed: ${(e as Error).message}`,
              timestamp: Date.now(),
            };
            this.handlers?.onToolActivity(updated);
            try {
              this.session?.sendToolResponse({
                functionResponses: [
                  { id, name, response: { result: `Tool failed: ${(e as Error).message}` } },
                ],
              });
            } catch {
              /* noop */
            }
          }
        }
      }

      // Tool cancellations (user interrupted during tool)
      if (msg?.toolCallCancellation) {
        // just log — server will continue
        console.debug("[Auron] toolCallCancellation", msg.toolCallCancellation);
      }
    } catch (e) {
      console.warn("[Auron] handleMessage error", e);
    }
  }

  sendAudio(base64: string) {
    if (!this.session || this.closed) return;
    try {
      this.session.sendRealtimeInput({
        audio: { data: base64, mimeType: "audio/pcm;rate=16000" },
      });
    } catch (e) {
      // High-frequency path — don't spam errors. Only fail on repeated?
      console.debug("[Auron] sendAudio failed", e);
    }
  }

  interrupt() {
    try {
      this.player?.interrupt();
    } catch {
      /* noop */
    }
    if (this.state === "speaking" || this.state === "thinking") {
      this.setState("listening");
    }
  }

  private fail(
    type: "MissingApiKey" | "GeminiConnectionError" | "SessionTimeout" | "NetworkError",
    message: string,
    _recoverable: boolean
  ) {
    this.handlers?.onError({
      type,
      message,
      friendlyMessage: message,
      recoverable: true,
    });
    this.setState("error");
  }

  private clearTimeout() {
    if (this.connectTimeout !== null) {
      window.clearTimeout(this.connectTimeout);
      this.connectTimeout = null;
    }
  }

  disconnect() {
    this.closed = true;
    this.clearTimeout();
    try {
      this.session?.close?.();
    } catch {
      /* noop */
    }
    this.session = null;
    this.ai = null;
    // state reset handled by caller (hook) to avoid flicker during reconnect
  }
}
