// AudioStreamer — mic capture → PCM16 / 16kHz mono → base64 chunks
// Keeps all audio processing outside React render cycles.

import { AUDIO_INPUT_SAMPLE_RATE } from "../config/constants";

export class AudioStreamer {
  private stream: MediaStream | null = null;
  private ctx: AudioContext | null = null;
  private source: MediaStreamAudioSourceNode | null = null;
  private processor: ScriptProcessorNode | null = null;
  private analyser: AnalyserNode | null = null;
  private muteGain: GainNode | null = null;
  private running = false;
  private volume = 0;
  private timeDomain: Uint8Array<ArrayBuffer> | null = null;

  private onChunk: ((base64: string) => void) | null = null;

  get isActive() {
    return this.running;
  }

  /** Current mic level 0..1 (smoothed RMS) */
  getInputLevel(): number {
    if (!this.analyser || !this.running) return 0;
    if (!this.timeDomain)
      this.timeDomain = new Uint8Array(new ArrayBuffer(this.analyser.fftSize));
    this.analyser.getByteTimeDomainData(this.timeDomain);
    let sum = 0;
    for (let i = 0; i < this.timeDomain.length; i += 2) {
      const v = (this.timeDomain[i] - 128) / 128;
      sum += v * v;
    }
    const rms = Math.sqrt(sum / (this.timeDomain.length / 2));
    // smooth + boost for visibility
    const boosted = Math.min(1, rms * 3.2);
    this.volume = this.volume * 0.7 + boosted * 0.3;
    return this.volume;
  }

  async start(onChunk: (base64: string) => void): Promise<void> {
    if (this.running) return;
    this.onChunk = onChunk;

    try {
      this.stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
          channelCount: 1,
        },
      });
    } catch (e: unknown) {
      const err = e as DOMException;
      if (err?.name === "NotAllowedError" || err?.name === "SecurityError") {
        const denied = new Error("MicrophonePermissionDenied");
        denied.name = "MicrophonePermissionDenied";
        throw denied;
      }
      const notFound = new Error(err?.message || "Microphone not available");
      notFound.name = err?.name === "NotFoundError" ? "MicrophoneNotFound" : "AudioContextError";
      throw notFound;
    }

    const AC: typeof AudioContext | undefined =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AC) {
      const err = new Error("AudioContext not supported");
      err.name = "AudioContextError";
      throw err;
    }

    this.ctx = new AC({ latencyHint: "interactive" });
    if (this.ctx.state === "suspended") {
      try {
        await this.ctx.resume();
      } catch {
        /* ignore */
      }
    }

    this.source = this.ctx.createMediaStreamSource(this.stream);
    this.analyser = this.ctx.createAnalyser();
    this.analyser.fftSize = 2048;
    this.analyser.smoothingTimeConstant = 0.6;
    this.source.connect(this.analyser);

    // ScriptProcessor for wide mobile support. Muted via zero gain to avoid feedback.
    const bufferSize = 4096;
    this.processor = this.ctx.createScriptProcessor(bufferSize, 1, 1);
    this.muteGain = this.ctx.createGain();
    this.muteGain.gain.value = 0;
    this.source.connect(this.processor);
    this.processor.connect(this.muteGain);
    this.muteGain.connect(this.ctx.destination);

    const inputRate = this.ctx.sampleRate;
    const targetRate = AUDIO_INPUT_SAMPLE_RATE;

    this.processor.onaudioprocess = (ev: AudioProcessingEvent) => {
      if (!this.running && !this.onChunk) return;
      const input = ev.inputBuffer.getChannelData(0);
      const pcm16 = this.resampleToPCM16(input, inputRate, targetRate);
      if (pcm16.length === 0) return;
      const b64 = this.encodeBase64(pcm16);
      this.onChunk?.(b64);
    };

    this.running = true;
  }

  private resampleToPCM16(input: Float32Array, fromRate: number, toRate: number): Int16Array {
    let data: Float32Array;
    if (fromRate === toRate) {
      data = input;
    } else {
      const ratio = fromRate / toRate;
      const newLen = Math.floor(input.length / ratio);
      data = new Float32Array(newLen);
      for (let i = 0; i < newLen; i++) {
        const pos = i * ratio;
        const idx = Math.floor(pos);
        const frac = pos - idx;
        const a = input[idx] ?? 0;
        const b = input[idx + 1] ?? a;
        data[i] = a + (b - a) * frac;
      }
    }
    const out = new Int16Array(data.length);
    for (let i = 0; i < data.length; i++) {
      const s = Math.max(-1, Math.min(1, data[i]));
      out[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
    }
    return out;
  }

  private encodeBase64(pcm: Int16Array): string {
    const bytes = new Uint8Array(pcm.buffer, pcm.byteOffset, pcm.byteLength);
    const chunk = 0x8000;
    let binary = "";
    for (let i = 0; i < bytes.length; i += chunk) {
      const sub = bytes.subarray(i, i + chunk);
      binary += String.fromCharCode.apply(null, sub as unknown as number[]);
    }
    return btoa(binary);
  }

  stop() {
    this.running = false;
    this.onChunk = null;
    try {
      this.processor?.disconnect();
      this.muteGain?.disconnect();
      this.source?.disconnect();
      this.analyser?.disconnect();
    } catch {
      /* noop */
    }
    this.processor = null;
    this.source = null;
    this.analyser = null;
    this.muteGain = null;
    if (this.stream) {
      this.stream.getTracks().forEach((t) => {
        try {
          t.stop();
        } catch {
          /* noop */
        }
      });
      this.stream = null;
    }
    if (this.ctx) {
      const c = this.ctx;
      this.ctx = null;
      c.close().catch(() => undefined);
    }
    this.volume = 0;
  }
}
