import { Terminal, Trash2, AlertCircle, AlertTriangle, Info } from "lucide-react";
import type { ConsoleLogMessage } from "../types/website";
import { cn } from "../../utils/cn";

interface Props {
  logs: ConsoleLogMessage[];
  onClear: () => void;
  virtualPort: number;
}

export default function ConsolePanel({ logs, onClear, virtualPort }: Props) {
  const getIcon = (type: ConsoleLogMessage["type"]) => {
    switch (type) {
      case "error":
        return <AlertCircle className="w-3.5 h-3.5 text-rose-400 shrink-0" />;
      case "warn":
        return <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0" />;
      case "info":
        return <Info className="w-3.5 h-3.5 text-cyan-400 shrink-0" />;
      default:
        return <Terminal className="w-3.5 h-3.5 text-slate-400 shrink-0" />;
    }
  };

  return (
    <div className="flex flex-col h-full w-full bg-[#080b18] border-t border-white/10 font-mono text-xs">
      <div className="flex items-center justify-between px-4 py-2 bg-[#0c1024] border-b border-white/10">
        <div className="flex items-center gap-2">
          <Terminal className="w-4 h-4 text-emerald-400" />
          <span className="font-bold text-slate-200">Sandbox Console</span>
          <span className="text-[10px] text-slate-400">(:{virtualPort})</span>
          <span className="text-[10px] px-1.5 py-0.2 rounded bg-white/10 text-slate-300">
            {logs.length} events
          </span>
        </div>

        <button
          onClick={onClear}
          className="flex items-center gap-1 text-[11px] text-slate-400 hover:text-white px-2 py-1 rounded bg-white/5 transition"
          title="Clear Console"
        >
          <Trash2 className="w-3 h-3" />
          <span>Clear</span>
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-3 space-y-1.5 font-mono">
        <div className="text-[11px] text-emerald-400/80 mb-2">
          [System] Local development sandbox runtime listening on port {virtualPort}.
        </div>

        {logs.map((item) => (
          <div
            key={item.id}
            className={cn(
              "flex items-start gap-2 py-1 px-2 rounded text-[11px] leading-relaxed",
              item.type === "error" && "bg-rose-500/10 text-rose-300",
              item.type === "warn" && "bg-amber-500/10 text-amber-300",
              item.type === "info" && "bg-cyan-500/10 text-cyan-300",
              item.type === "log" && "text-slate-300 hover:bg-white/[0.03]"
            )}
          >
            {getIcon(item.type)}
            <span className="text-slate-500 text-[10px] select-none">
              {new Date(item.timestamp).toLocaleTimeString()}
            </span>
            <span className="flex-1 break-all">{item.message}</span>
          </div>
        ))}

        {logs.length === 0 && (
          <div className="text-slate-600 text-xs py-2 italic">
            Console clean. No runtime warnings or uncaught exceptions.
          </div>
        )}
      </div>
    </div>
  );
}
