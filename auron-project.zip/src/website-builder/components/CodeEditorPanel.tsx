import { useState, useEffect } from "react";
import { Copy, Check, Download, Save, RotateCcw, Code2 } from "lucide-react";
import type { ProjectFile } from "../types/website";
import { ZipExporter } from "../services/ZipExporter";

interface Props {
  file: ProjectFile;
  onSave: (fileName: string, newContent: string) => void;
}

export default function CodeEditorPanel({ file, onSave }: Props) {
  const [content, setContent] = useState(file.content);
  const [copied, setCopied] = useState(false);
  const [hasChanges, setHasChanges] = useState(false);

  useEffect(() => {
    setContent(file.content);
    setHasChanges(false);
  }, [file.name, file.content]);

  const handleChange = (val: string) => {
    setContent(val);
    setHasChanges(val !== file.content);
  };

  const handleSave = () => {
    onSave(file.name, content);
    setHasChanges(false);
  };

  const handleReset = () => {
    setContent(file.content);
    setHasChanges(false);
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const lines = content.split("\n");

  return (
    <div className="flex flex-col h-full w-full bg-[#090d1f] border border-white/10 rounded-2xl overflow-hidden shadow-2xl">
      {/* Editor Header Bar */}
      <div className="flex items-center justify-between px-4 py-2.5 bg-[#0d132c] border-b border-white/10">
        <div className="flex items-center gap-2">
          <Code2 className="w-4 h-4 text-cyan-400" />
          <span className="text-xs font-mono font-bold text-white">{file.name}</span>
          <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-white/5 text-slate-400">
            {file.language}
          </span>
          {hasChanges && (
            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-500/20 text-amber-300">
              Unsaved Changes
            </span>
          )}
        </div>

        <div className="flex items-center gap-1.5">
          {hasChanges && (
            <>
              <button
                onClick={handleReset}
                className="flex items-center gap-1 px-2.5 py-1 text-xs text-slate-400 hover:text-white rounded bg-white/5 transition"
                title="Discard Changes"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset</span>
              </button>
              <button
                onClick={handleSave}
                className="flex items-center gap-1 px-3 py-1 text-xs text-white rounded bg-cyan-600 hover:bg-cyan-500 font-bold transition shadow-sm"
                title="Save & Live Refresh (Ctrl+S)"
              >
                <Save className="w-3.5 h-3.5" />
                <span>Save Code</span>
              </button>
            </>
          )}

          <button
            onClick={handleCopy}
            className="flex items-center gap-1 px-2.5 py-1 text-xs text-slate-400 hover:text-white rounded bg-white/5 transition"
            title="Copy Code"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? "Copied" : "Copy"}</span>
          </button>

          <button
            onClick={() => ZipExporter.downloadSingleFile({ ...file, content })}
            className="flex items-center gap-1 px-2.5 py-1 text-xs text-slate-400 hover:text-white rounded bg-white/5 transition"
            title="Download File"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Download</span>
          </button>
        </div>
      </div>

      {/* Editor Area with Line Numbers */}
      <div className="flex-1 flex overflow-hidden font-mono text-xs sm:text-sm">
        {/* Line Numbers Column */}
        <div
          className="select-none py-3 px-3 text-right bg-[#070914] text-slate-600 border-r border-white/5 overflow-hidden"
          style={{ width: "48px" }}
          aria-hidden="true"
        >
          {lines.map((_, i) => (
            <div key={i} className="leading-6">
              {i + 1}
            </div>
          ))}
        </div>

        {/* Text Area */}
        <textarea
          value={content}
          onChange={(e) => handleChange(e.target.value)}
          onKeyDown={(e) => {
            if ((e.ctrlKey || e.metaKey) && e.key === "s") {
              e.preventDefault();
              handleSave();
            }
          }}
          spellCheck={false}
          className="flex-1 h-full w-full p-3 bg-transparent text-slate-200 outline-none resize-none leading-6 font-mono overflow-auto selection:bg-cyan-500/30"
          placeholder="Enter code here..."
        />
      </div>

      {/* Footer Info Bar */}
      <div className="px-4 py-1.5 bg-[#070a18] border-t border-white/5 flex items-center justify-between text-[11px] text-slate-500 font-mono">
        <span>Lines: {lines.length} &bull; Characters: {content.length}</span>
        <span>UTF-8 &bull; {file.language.toUpperCase()} &bull; Press Ctrl+S to save</span>
      </div>
    </div>
  );
}
