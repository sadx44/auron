import { History, X, RotateCcw, Check, Clock } from "lucide-react";
import type { ProjectVersion } from "../types/website";
import { cn } from "../../utils/cn";

interface Props {
  open: boolean;
  onClose: () => void;
  versions: ProjectVersion[];
  currentVersionIndex: number;
  onRestore: (versionIndex: number) => void;
}

export default function VersionHistoryModal({
  open,
  onClose,
  versions,
  currentVersionIndex,
  onRestore,
}: Props) {
  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md">
      <div className="flex flex-col w-full max-w-lg bg-[#0b1024] border border-white/10 rounded-2xl shadow-2xl overflow-hidden max-h-[85vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 bg-[#0e1634] border-b border-white/10">
          <div className="flex items-center gap-2">
            <History className="w-4 h-4 text-cyan-400" />
            <h3 className="text-sm font-bold text-white">Project Version History</h3>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 font-mono">
              {versions.length} versions
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Versions List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2.5">
          {versions.map((ver, idx) => {
            const isCurrent = idx === currentVersionIndex;
            const fileCount = Object.keys(ver.files).length;

            return (
              <div
                key={ver.id}
                className={cn(
                  "p-3.5 rounded-xl border transition flex items-center justify-between gap-3",
                  isCurrent
                    ? "bg-cyan-500/10 border-cyan-400/40 shadow-sm"
                    : "bg-white/[0.02] border-white/5 hover:border-white/15 hover:bg-white/[0.04]"
                )}
              >
                <div className="flex flex-col gap-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-xs text-white">
                      Version {ver.versionNumber}
                    </span>
                    {isCurrent && (
                      <span className="flex items-center gap-1 text-[10px] font-bold text-emerald-300 bg-emerald-500/20 px-2 py-0.5 rounded-full">
                        <Check className="w-3 h-3" /> Active
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-slate-300 truncate font-medium">
                    {ver.description}
                  </p>
                  <div className="flex items-center gap-3 text-[10px] text-slate-500 font-mono">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {new Date(ver.timestamp).toLocaleTimeString()} &bull;{" "}
                      {new Date(ver.timestamp).toLocaleDateString()}
                    </span>
                    <span>{fileCount} files</span>
                    <span className="truncate max-w-[120px]">{ver.modelUsed}</span>
                  </div>
                </div>

                {!isCurrent && (
                  <button
                    onClick={() => {
                      onRestore(idx);
                      onClose();
                    }}
                    className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-cyan-200 bg-cyan-500/20 hover:bg-cyan-500/30 rounded-lg transition shrink-0"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>Restore</span>
                  </button>
                )}
              </div>
            );
          })}
        </div>

        <div className="p-3 bg-[#070914] border-t border-white/5 text-[11px] text-slate-500 text-center">
          You can restore any prior version at any time without data loss.
        </div>
      </div>
    </div>
  );
}
