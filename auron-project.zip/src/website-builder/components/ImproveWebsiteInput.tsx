import { useState, useEffect } from "react";
import { Sparkles, Mic, MicOff, Send, Wand2 } from "lucide-react";
import { cn } from "../../utils/cn";

interface Props {
  onImprove: (instruction: string) => void;
  disabled?: boolean;
}

const QUICK_PROMPTS = [
  "Change theme to dark neon cyan & magenta",
  "Make the navbar sticky with blur glassmorphism",
  "Add interactive pricing section with toggle",
  "Enhance hover animations and micro-interactions",
  "Optimize mobile layout for 320px screens",
];

export default function ImproveWebsiteInput({ onImprove, disabled }: Props) {
  const [text, setText] = useState("");
  const [isListening, setIsListening] = useState(false);

  // Web Speech API for voice dictation
  const toggleVoice = () => {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert("Voice input is supported in Chrome, Edge, and Safari.");
      return;
    }

    if (isListening) {
      setIsListening(false);
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = "en-US";

      recognition.onstart = () => setIsListening(true);
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setText((prev) => (prev ? `${prev} ${transcript}` : transcript));
      };
      recognition.onerror = () => setIsListening(false);
      recognition.onend = () => setIsListening(false);

      recognition.start();
    } catch {
      setIsListening(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim() || disabled) return;
    onImprove(text.trim());
    setText("");
  };

  useEffect(() => {
    return () => {
      setIsListening(false);
    };
  }, []);

  return (
    <div className="flex flex-col gap-2 w-full">
      <form onSubmit={handleSubmit} className="relative flex items-center gap-2">
        <div className="relative flex-1">
          <input
            type="text"
            value={text}
            onChange={(e) => setText(e.target.value)}
            disabled={disabled}
            placeholder='Ask Priya: "Change colors to dark neon", "Make header sticky", "Add reviews"...'
            className="w-full pl-9 pr-12 py-2.5 rounded-xl bg-black/40 border border-white/10 text-xs sm:text-sm text-white placeholder:text-slate-500 outline-none focus:border-cyan-400/50 focus:ring-2 focus:ring-cyan-400/20 transition"
          />
          <Wand2 className="w-4 h-4 text-cyan-400 absolute left-3 top-3 pointer-events-none" />

          {/* Voice Mic Button */}
          <button
            type="button"
            onClick={toggleVoice}
            disabled={disabled}
            className={cn(
              "absolute right-2 top-2 p-1.5 rounded-lg transition",
              isListening
                ? "bg-rose-500/30 text-rose-300 animate-pulse"
                : "text-slate-400 hover:text-white hover:bg-white/10"
            )}
            title="Dictate with voice"
          >
            {isListening ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5" />}
          </button>
        </div>

        <button
          type="submit"
          disabled={!text.trim() || disabled}
          className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500 text-white font-bold text-xs sm:text-sm disabled:opacity-40 disabled:cursor-not-allowed transition shadow-lg shrink-0"
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Improve</span>
          <Send className="w-3.5 h-3.5 sm:hidden" />
        </button>
      </form>

      {/* Quick Suggestion Chips */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-[11px] no-scrollbar">
        <span className="text-slate-500 text-[10px] font-semibold uppercase tracking-wider shrink-0">
          Suggestions:
        </span>
        {QUICK_PROMPTS.map((prompt) => (
          <button
            key={prompt}
            type="button"
            onClick={() => onImprove(prompt)}
            disabled={disabled}
            className="px-2.5 py-1 rounded-full bg-white/5 border border-white/5 hover:border-cyan-400/30 hover:bg-cyan-500/10 text-slate-300 hover:text-white transition whitespace-nowrap shrink-0 text-[11px]"
          >
            {prompt}
          </button>
        ))}
      </div>
    </div>
  );
}
