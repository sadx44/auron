import {
  Briefcase,
  Cpu,
  Film,
  Sparkles,
  ShoppingBag,
  Gamepad2,
  X,
  ArrowRight,
} from "lucide-react";
import { TemplateRegistry, type WebsiteTemplate } from "../services/TemplateRegistry";

interface Props {
  open: boolean;
  onClose: () => void;
  onSelectTemplate: (template: WebsiteTemplate) => void;
}

export default function TemplateSelectorModal({ open, onClose, onSelectTemplate }: Props) {
  if (!open) return null;

  const templates = TemplateRegistry.getTemplates();

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case "Briefcase":
        return <Briefcase className="w-5 h-5 text-cyan-400" />;
      case "Cpu":
        return <Cpu className="w-5 h-5 text-purple-400" />;
      case "Film":
        return <Film className="w-5 h-5 text-rose-400" />;
      case "Sparkles":
        return <Sparkles className="w-5 h-5 text-amber-400" />;
      case "ShoppingBag":
        return <ShoppingBag className="w-5 h-5 text-emerald-400" />;
      case "Gamepad2":
        return <Gamepad2 className="w-5 h-5 text-fuchsia-400" />;
      default:
        return <Sparkles className="w-5 h-5 text-cyan-400" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className="flex flex-col w-full max-w-2xl bg-[#0b1024] border border-white/10 rounded-2xl shadow-2xl overflow-hidden max-h-[90vh]">
        <div className="flex items-center justify-between px-6 py-4 bg-[#0e1634] border-b border-white/10">
          <div>
            <h3 className="text-base font-bold text-white">Choose a Website Architecture</h3>
            <p className="text-xs text-slate-400">
              Select a production template or let Priya generate a custom website
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6 grid grid-cols-1 md:grid-cols-2 gap-4">
          {templates.map((tpl) => (
            <div
              key={tpl.id}
              onClick={() => {
                onSelectTemplate(tpl);
                onClose();
              }}
              className="group p-4 rounded-xl bg-white/[0.03] hover:bg-cyan-500/10 border border-white/10 hover:border-cyan-400/40 cursor-pointer transition flex flex-col justify-between gap-3"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <div className="p-2 rounded-lg bg-black/40 border border-white/10">
                    {getIcon(tpl.icon)}
                  </div>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300">
                    {tpl.badge}
                  </span>
                </div>
                <h4 className="text-sm font-bold text-white group-hover:text-cyan-300 transition">
                  {tpl.name}
                </h4>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                  {tpl.description}
                </p>
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-white/5 text-xs text-cyan-400 font-semibold">
                <span>Build this template</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
