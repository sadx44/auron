import {
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  Loader2,
  Clock,
  Cpu,
} from "lucide-react";
import type { AgentLog, AIModelCandidate, BuilderState } from "../types/website";
import { cn } from "../../utils/cn";

interface Props {
  state: BuilderState;
  logs: AgentLog[];
  selectedModel: AIModelCandidate;
  repairAttempts: number;
}

const WORKFLOW_STEPS = [
  { id: "analyzing", label: "Analyze Requirements" },
  { id: "planning", label: "Architecture Plan" },
  { id: "selecting-model", label: "Model Selection" },
  { id: "generating", label: "Synthesize Code" },
  { id: "running", label: "Local Sandbox" },
  { id: "testing", label: "Syntax & Responsiveness" },
  { id: "fixing", label: "Auto-Repair Loop" },
  { id: "ready", label: "Production Preview" },
];

export default function AIActivityPanel({
  state,
  logs,
  selectedModel,
  repairAttempts,
}: Props) {
  const getStepProgress = () => {
    switch (state) {
      case "idle":
        return 0;
      case "analyzing":
        return 15;
      case "planning":
        return 30;
      case "selecting-model":
        return 45;
      case "generating":
        return 65;
      case "running":
        return 80;
      case "testing":
        return 88;
      case "fixing":
        return 92;
      case "ready":
        return 100;
      case "error":
        return 100;
      default:
        return 0;
    }
  };

  const progress = getStepProgress();

  return (
    <div className="flex flex-col h-full w-full bg-[#0a0f24] border border-white/10 rounded-2xl overflow-hidden shadow-xl">
      {/* Header */}
      <div className="px-4 py-3 bg-[#0d1430] border-b border-white/10 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-cyan-400" />
          <span className="text-xs font-extrabold uppercase tracking-wider text-slate-200">
            AI Coding Agent Activity
          </span>
        </div>
        <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-cyan-500/10 border border-cyan-400/20 text-[11px] font-mono text-cyan-300">
          <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
          {state}
        </div>
      </div>

      {/* Selected Model Capsule */}
      <div className="p-3 bg-black/30 border-b border-white/5 flex items-center justify-between text-xs">
        <div className="flex items-center gap-2 truncate">
          <Cpu className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
          <span className="font-semibold text-slate-200 truncate">{selectedModel.name}</span>
        </div>
        <div className="flex items-center gap-1 shrink-0 font-mono text-[10px]">
          <span className="px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold">
            {selectedModel.codingScore}% Code Score
          </span>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="w-full bg-black/40 h-1.5 overflow-hidden">
        <div
          className={cn(
            "h-full transition-all duration-500",
            state === "error"
              ? "bg-rose-500"
              : state === "ready"
              ? "bg-emerald-400"
              : "bg-gradient-to-r from-cyan-500 to-purple-500"
          )}
          style={{ width: `${progress}%` }}
        />
      </div>

      {/* Workflow Timeline Steps */}
      <div className="px-4 py-3 border-b border-white/5 bg-[#090d20]">
        <div className="grid grid-cols-2 gap-2 text-[11px]">
          {WORKFLOW_STEPS.map((step, idx) => {
            const isCompleted =
              progress >= ((idx + 1) / WORKFLOW_STEPS.length) * 100 || state === "ready";
            const isCurrent = state === step.id;

            return (
              <div
                key={step.id}
                className={cn(
                  "flex items-center gap-1.5 p-1 rounded-lg transition text-[11px]",
                  isCurrent && "bg-cyan-500/20 text-cyan-200 font-bold",
                  isCompleted && !isCurrent && "text-slate-300",
                  !isCompleted && !isCurrent && "text-slate-600"
                )}
              >
                {isCurrent ? (
                  <Loader2 className="w-3 h-3 animate-spin text-cyan-400 shrink-0" />
                ) : isCompleted ? (
                  <CheckCircle2 className="w-3 h-3 text-emerald-400 shrink-0" />
                ) : (
                  <Clock className="w-3 h-3 text-slate-600 shrink-0" />
                )}
                <span className="truncate">{step.label}</span>
              </div>
            );
          })}
        </div>
        {repairAttempts > 0 && (
          <div className="mt-2 text-[11px] text-amber-300 flex items-center gap-1.5 bg-amber-500/10 px-2 py-1 rounded">
            <AlertTriangle className="w-3 h-3 shrink-0" />
            <span>Auto-repair loop executed {repairAttempts} pass(es)</span>
          </div>
        )}
      </div>

      {/* Real-time Agent Activity Feed */}
      <div className="flex-1 overflow-y-auto p-3 space-y-2 font-mono text-[11px]">
        {logs.map((log) => (
          <div
            key={log.id}
            className="p-2 rounded-xl bg-white/[0.03] border border-white/5 flex flex-col gap-1"
          >
            <div className="flex items-center justify-between text-[10px] text-slate-500">
              <span className="font-semibold text-cyan-400">{log.step}</span>
              <span>{new Date(log.timestamp).toLocaleTimeString()}</span>
            </div>
            <p className="text-slate-200 leading-relaxed font-sans">{log.message}</p>
          </div>
        ))}
        {logs.length === 0 && (
          <div className="text-center py-8 text-slate-500 text-xs">
            Awaiting prompt to begin autonomous web synthesis...
          </div>
        )}
      </div>
    </div>
  );
}
