import { useState, useEffect, useRef, useCallback } from "react";
import {
  Code,
  Eye,
  Download,
  FileDown,
  History,
  LayoutGrid,
  X,
  RefreshCw,
  FolderTree,
  Activity,
  Terminal,
} from "lucide-react";
import type {
  WebsiteProject,
  ConsoleLogMessage,
} from "../types/website";
import { WebsiteRequirementAnalyzer } from "../services/WebsiteRequirementAnalyzer";
import { ModelSelector } from "../services/ModelSelector";
import { CodeGenerator } from "../services/CodeGenerator";
import { CodeValidator } from "../services/CodeValidator";
import { CodeRepairAgent } from "../services/CodeRepairAgent";
import { LocalPreviewManager } from "../services/LocalPreviewManager";
import { ZipExporter } from "../services/ZipExporter";
import { PDFExporter } from "../services/PDFExporter";
import { VersionManager } from "../services/VersionManager";
import { TemplateRegistry, type WebsiteTemplate } from "../services/TemplateRegistry";
import LivePreviewFrame from "./LivePreviewFrame";
import CodeEditorPanel from "./CodeEditorPanel";
import FileExplorer from "./FileExplorer";
import AIActivityPanel from "./AIActivityPanel";
import ConsolePanel from "./ConsolePanel";
import ImproveWebsiteInput from "./ImproveWebsiteInput";
import VersionHistoryModal from "./VersionHistoryModal";
import TemplateSelectorModal from "./TemplateSelectorModal";
import { cn } from "../../utils/cn";

interface Props {
  initialPrompt?: string;
  apiKey?: string;
  characterName?: string;
  onClose: () => void;
}

export default function WebsiteBuilderView({
  initialPrompt = "Create a modern portfolio website for an app developer with a dark futuristic design",
  apiKey = "",
  characterName = "Priya",
  onClose,
}: Props) {
  // Main Project State
  const [project, setProject] = useState<WebsiteProject>(() => {
    const port = LocalPreviewManager.allocatePort();
    const defaultModel = ModelSelector.selectBestModel(initialPrompt);
    const req = WebsiteRequirementAnalyzer.analyze(initialPrompt);
    const initialFiles = TemplateRegistry.generatePortfolioFiles(req);

    return {
      id: `proj-${Date.now()}`,
      name: req.title,
      prompt: initialPrompt,
      status: "idle",
      files: initialFiles,
      activeFileName: "index.html",
      versions: [
        VersionManager.createSnapshot(
          initialFiles,
          "Initial Generation",
          defaultModel.name,
          []
        ),
      ],
      currentVersionIndex: 0,
      selectedModel: defaultModel,
      requirements: req,
      logs: [],
      validationErrors: [],
      repairAttempts: 0,
      virtualPort: port,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
  });

  // UI State
  const [activeTab, setActiveTab] = useState<"preview" | "code">("preview");
  const [mobileTab, setMobileTab] = useState<"preview" | "code" | "files" | "agent" | "console">("preview");
  const [showConsole, setShowConsole] = useState(false);
  const [consoleLogs, setConsoleLogs] = useState<ConsoleLogMessage[]>([]);
  const [historyModalOpen, setHistoryModalOpen] = useState(false);
  const [templateModalOpen, setTemplateModalOpen] = useState(false);
  const [isExportingZip, setIsExportingZip] = useState(false);

  const hasGeneratedInitialRef = useRef(false);

  // Helper to append agent log
  const addLog = useCallback((step: string, message: string, status: "pending" | "running" | "done" | "warn" | "error" = "done") => {
    setProject((prev) => ({
      ...prev,
      logs: [
        ...prev.logs,
        {
          id: `log-${Date.now()}-${Math.random().toString(36).substring(2, 5)}`,
          step,
          message,
          status,
          timestamp: Date.now(),
        },
      ],
    }));
  }, []);

  // ─────────────────────────────────────────────────────────────
  // THE AGENTIC CODING WORKFLOW
  // REQUEST → PLAN → MODEL → GENERATE → RUN → VALIDATE → FIX → READY
  // ─────────────────────────────────────────────────────────────
  const runAgentWorkflow = useCallback(async (
    targetPrompt: string,
    isImprovement: boolean = false
  ) => {
    setProject((prev) => ({ ...prev, status: "analyzing" }));
    addLog("Analyzing", `Analyzing requirements for: "${targetPrompt}"...`, "running");

    // 1. Analyze Requirements
    const req = WebsiteRequirementAnalyzer.analyze(targetPrompt);
    addLog("Planning", `Architecture Plan: ${req.websiteType} with ${req.sections.length} core sections and ${req.theme.mode} theme.`, "done");

    // 2. Select Coding Model
    setProject((prev) => ({ ...prev, status: "selecting-model", requirements: req }));
    const model = ModelSelector.selectBestModel(targetPrompt);
    addLog("Model Selection", `Evaluated candidates. Selected: ${model.name} (${model.codingScore}% benchmark score, ${model.speed} speed).`, "done");

    // 3. Generate Code
    setProject((prev) => ({
      ...prev,
      status: "generating",
      selectedModel: model,
      name: isImprovement ? prev.name : req.title,
    }));
    addLog("Synthesizing", `Generating semantic HTML5, modern CSS3 & interactive JavaScript...`, "running");

    try {
      const generatedFiles = await CodeGenerator.generate({
        prompt: targetPrompt,
        requirements: req,
        model,
        apiKey,
        existingFiles: isImprovement ? project.files : undefined,
        isImprovement,
        onProgress: (msg) => addLog("Code Generator", msg, "running"),
      });

      // 4. Run in Local Sandbox
      setProject((prev) => ({ ...prev, status: "running" }));
      addLog("Local Sandbox", `Mounting isolated sandbox container on virtual port :${project.virtualPort}...`, "done");

      // 5. Validate Code
      setProject((prev) => ({ ...prev, status: "testing" }));
      addLog("Code Validator", "Running deep AST syntax checks, viewport compliance, and listener integrity...", "running");
      const validationErrors = CodeValidator.validate(generatedFiles);

      let finalFiles = generatedFiles;
      let repairPasses = 0;

      // 6. Automatic Repair Loop
      if (validationErrors.length > 0) {
        setProject((prev) => ({ ...prev, status: "fixing" }));
        addLog("Repair Agent", `Detected ${validationErrors.length} issue(s). Initiating autonomous self-healing loop...`, "warn");

        const repairResult = CodeRepairAgent.repair(generatedFiles, validationErrors);
        finalFiles = repairResult.repairedFiles;
        repairPasses = 1;

        for (const action of repairResult.actionsTaken) {
          addLog("Self-Heal", action, "done");
        }
      } else {
        addLog("Validation", "Code passed syntax checks, zero mismatched tags, universal box-sizing verified.", "done");
      }

      // 7. Save Version Snapshot
      const newVersion = VersionManager.createSnapshot(
        finalFiles,
        isImprovement ? `Improvement: ${targetPrompt}` : `Initial: ${targetPrompt}`,
        model.name,
        project.versions
      );

      setProject((prev) => {
        const nextVersions = [...prev.versions, newVersion];
        return {
          ...prev,
          status: "ready",
          files: finalFiles,
          versions: nextVersions,
          currentVersionIndex: nextVersions.length - 1,
          validationErrors,
          repairAttempts: repairPasses,
          updatedAt: Date.now(),
        };
      });

      addLog("Ready", `Website deployment ready! Preview live on localhost:${project.virtualPort}.`, "done");
    } catch (err) {
      console.error("[WebsiteBuilder] Generation error:", err);
      setProject((prev) => ({ ...prev, status: "error" }));
      addLog("Error", `An error occurred during build: ${(err as Error).message}. ${characterName} is standing by to retry.`, "error");
    }
  }, [addLog, apiKey, characterName, project.files, project.versions, project.virtualPort]);

  // Initial trigger
  useEffect(() => {
    if (!hasGeneratedInitialRef.current) {
      hasGeneratedInitialRef.current = true;
      runAgentWorkflow(initialPrompt, false);
    }
  }, [initialPrompt, runAgentWorkflow]);

  // Listen to iframe sandbox console logs
  useEffect(() => {
    const cleanup = LocalPreviewManager.listenToConsole((log) => {
      setConsoleLogs((prev) => [...prev.slice(-100), log]);
    });
    return cleanup;
  }, []);

  // Handle Save File from Editor
  const handleSaveFile = (fileName: string, newContent: string) => {
    setProject((prev) => {
      const updatedFiles = {
        ...prev.files,
        [fileName]: {
          ...prev.files[fileName],
          content: newContent,
        },
      };

      const newVersion = VersionManager.createSnapshot(
        updatedFiles,
        `Manual edit: ${fileName}`,
        "User Manual Edit",
        prev.versions
      );

      return {
        ...prev,
        files: updatedFiles,
        versions: [...prev.versions, newVersion],
        currentVersionIndex: prev.versions.length,
        updatedAt: Date.now(),
      };
    });

    addLog("Editor", `Manual edit saved for ${fileName}. Sandbox preview hot-reloaded.`, "done");
  };

  // Handle Restore Version
  const handleRestoreVersion = (versionIndex: number) => {
    const targetVersion = project.versions[versionIndex];
    if (!targetVersion) return;

    const restoredFiles = VersionManager.restoreVersion(targetVersion);
    setProject((prev) => ({
      ...prev,
      files: restoredFiles,
      currentVersionIndex: versionIndex,
      updatedAt: Date.now(),
    }));

    addLog("Version History", `Restored project to Version ${targetVersion.versionNumber} ("${targetVersion.description}").`, "done");
  };

  // Handle Template Pick
  const handleSelectTemplate = (tpl: WebsiteTemplate) => {
    setTemplateModalOpen(false);
    runAgentWorkflow(tpl.promptExample, false);
  };

  // Export ZIP
  const handleExportZip = async () => {
    setIsExportingZip(true);
    try {
      await ZipExporter.exportToZip(project.files, project.name);
      addLog("Export", `Project successfully packaged into ${project.name.toLowerCase().replace(/[^a-z0-9]/g, "-")}.zip.`, "done");
    } catch (e) {
      console.error(e);
    } finally {
      setIsExportingZip(false);
    }
  };

  // Export PDF
  const handleExportPDF = () => {
    PDFExporter.exportToPDF(project);
    addLog("Export", "Rendered website preview dispatched to PDF print service.", "done");
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-[#050814] text-white overflow-hidden select-none animate-fadeIn">
      {/* ── TOP APPLICATION BAR ── */}
      <header className="flex items-center justify-between px-3 sm:px-6 py-2.5 bg-[#0b1026] border-b border-white/10 gap-2 shrink-0">
        {/* Left: Branding & Project Title */}
        <div className="flex items-center gap-3 min-w-0">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-cyan-400 to-purple-600 flex items-center justify-center shadow-lg shadow-cyan-500/20 text-white font-black text-sm">
              AI
            </div>
            <div className="leading-tight hidden sm:block">
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-extrabold tracking-wider text-white">
                  {characterName} AI Website Builder
                </span>
                <span className="px-1.5 py-0.2 rounded bg-cyan-500/20 text-cyan-300 font-mono text-[9px] font-bold">
                  AUTONOMOUS
                </span>
              </div>
              <p className="text-[10px] text-slate-400 truncate max-w-[220px]">
                {project.name}
              </p>
            </div>
          </div>
        </div>

        {/* Center: Desktop Preview / Code Toggle */}
        <div className="hidden md:flex items-center gap-1 p-1 rounded-xl bg-black/40 border border-white/10">
          <button
            onClick={() => setActiveTab("preview")}
            className={cn(
              "flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition",
              activeTab === "preview"
                ? "bg-cyan-500/20 text-cyan-200 shadow-sm border border-cyan-400/30"
                : "text-slate-400 hover:text-white"
            )}
          >
            <Eye className="w-3.5 h-3.5" />
            <span>Live Preview</span>
          </button>
          <button
            onClick={() => setActiveTab("code")}
            className={cn(
              "flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition",
              activeTab === "code"
                ? "bg-cyan-500/20 text-cyan-200 shadow-sm border border-cyan-400/30"
                : "text-slate-400 hover:text-white"
            )}
          >
            <Code className="w-3.5 h-3.5" />
            <span>Inspect & Edit Code</span>
          </button>
        </div>

        {/* Right: Actions (Templates, History, ZIP, PDF, Close) */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Templates */}
          <button
            onClick={() => setTemplateModalOpen(true)}
            className="flex items-center gap-1 px-2.5 py-1.5 text-xs text-slate-300 hover:text-white bg-white/5 hover:bg-white/10 rounded-xl border border-white/10 transition"
            title="Choose Template Architecture"
          >
            <LayoutGrid className="w-3.5 h-3.5 text-purple-400" />
            <span className="hidden lg:inline">Templates</span>
          </button>

          {/* Version History */}
          <button
            onClick={() => setHistoryModalOpen(true)}
            className="flex items-center gap-1 px-2.5 py-1.5 text-xs text-slate-300 hover:text-white bg-white/5 hover:bg-white/10 rounded-xl border border-white/10 transition"
            title="Version Snapshots & Undo"
          >
            <History className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden lg:inline">Versions</span>
            <span className="px-1.5 py-0.2 rounded-full bg-cyan-500/20 text-cyan-300 text-[10px] font-mono font-bold">
              v{project.versions.length}
            </span>
          </button>

          {/* Export PDF */}
          <button
            onClick={handleExportPDF}
            className="flex items-center gap-1 px-2.5 py-1.5 text-xs text-slate-300 hover:text-white bg-white/5 hover:bg-white/10 rounded-xl border border-white/10 transition"
            title="Export rendered website as PDF"
          >
            <FileDown className="w-3.5 h-3.5 text-rose-400" />
            <span className="hidden sm:inline">Export PDF</span>
          </button>

          {/* Download ZIP */}
          <button
            onClick={handleExportZip}
            disabled={isExportingZip}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-white bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 rounded-xl shadow-lg shadow-cyan-500/20 transition active:scale-95 disabled:opacity-50"
            title="Download complete project ZIP"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download ZIP</span>
          </button>

          {/* Close Builder and return to Assistant */}
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition ml-1"
            title="Return to Voice Assistant"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* ── MOBILE TAB SWITCHER BAR (Below 768px) ── */}
      <div className="flex md:hidden items-center justify-around bg-[#080d20] border-b border-white/10 px-2 py-1 text-xs font-bold shrink-0">
        <button
          onClick={() => setMobileTab("preview")}
          className={cn(
            "flex items-center gap-1 px-2.5 py-1.5 rounded-lg transition",
            mobileTab === "preview" ? "bg-cyan-500/20 text-cyan-200" : "text-slate-400"
          )}
        >
          <Eye className="w-3.5 h-3.5" />
          <span>Preview</span>
        </button>
        <button
          onClick={() => setMobileTab("code")}
          className={cn(
            "flex items-center gap-1 px-2.5 py-1.5 rounded-lg transition",
            mobileTab === "code" ? "bg-cyan-500/20 text-cyan-200" : "text-slate-400"
          )}
        >
          <Code className="w-3.5 h-3.5" />
          <span>Code</span>
        </button>
        <button
          onClick={() => setMobileTab("files")}
          className={cn(
            "flex items-center gap-1 px-2.5 py-1.5 rounded-lg transition",
            mobileTab === "files" ? "bg-cyan-500/20 text-cyan-200" : "text-slate-400"
          )}
        >
          <FolderTree className="w-3.5 h-3.5" />
          <span>Files</span>
        </button>
        <button
          onClick={() => setMobileTab("agent")}
          className={cn(
            "flex items-center gap-1 px-2.5 py-1.5 rounded-lg transition",
            mobileTab === "agent" ? "bg-cyan-500/20 text-cyan-200" : "text-slate-400"
          )}
        >
          <Activity className="w-3.5 h-3.5" />
          <span>Agent</span>
        </button>
        <button
          onClick={() => setMobileTab("console")}
          className={cn(
            "flex items-center gap-1 px-2.5 py-1.5 rounded-lg transition",
            mobileTab === "console" ? "bg-cyan-500/20 text-cyan-200" : "text-slate-400"
          )}
        >
          <Terminal className="w-3.5 h-3.5" />
          <span>Console</span>
        </button>
      </div>

      {/* ── MAIN WORKSPACE BODY ── */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* DESKTOP LAYOUT (Grid 3-Column IDE) */}
        <div className="hidden md:flex flex-1 overflow-hidden p-3 gap-3">
          {/* Left Column: File Explorer (220px) */}
          <div className="w-60 shrink-0 h-full">
            <FileExplorer
              files={project.files}
              activeFileName={project.activeFileName}
              onSelectFile={(fileName) => {
                setProject((prev) => ({ ...prev, activeFileName: fileName }));
                setActiveTab("code");
              }}
            />
          </div>

          {/* Center Column: Live Preview or Code Editor (Flex-1) */}
          <div className="flex-1 flex flex-col h-full min-w-0 gap-3">
            <div className="flex-1 min-h-0">
              {activeTab === "preview" ? (
                <LivePreviewFrame
                  files={project.files}
                  virtualPort={project.virtualPort}
                  projectName={project.name}
                />
              ) : (
                <CodeEditorPanel
                  file={
                    project.files[project.activeFileName] ||
                    project.files["index.html"]
                  }
                  onSave={handleSaveFile}
                />
              )}
            </div>

            {/* Bottom Bar: Improve Website Prompt & Console Toggle */}
            <div className="p-3 bg-[#0a0f24] border border-white/10 rounded-2xl flex flex-col gap-2 shrink-0">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                  <RefreshCw className="w-3.5 h-3.5 text-cyan-400" />
                  Ask {characterName} to Improve or Expand Website
                </span>
                <button
                  onClick={() => setShowConsole((prev) => !prev)}
                  className="text-[11px] text-slate-400 hover:text-white flex items-center gap-1 px-2 py-0.5 rounded bg-white/5 transition"
                >
                  <Terminal className="w-3 h-3 text-emerald-400" />
                  <span>{showConsole ? "Hide Sandbox Console" : "Show Console"}</span>
                  <span className="px-1 py-0.2 rounded bg-white/10 font-mono text-[10px]">
                    {consoleLogs.length}
                  </span>
                </button>
              </div>

              <ImproveWebsiteInput
                onImprove={(instruction) => runAgentWorkflow(instruction, true)}
                disabled={project.status !== "ready" && project.status !== "idle" && project.status !== "error"}
              />

              {/* Collapsible Sandbox Console in Desktop */}
              {showConsole && (
                <div className="h-44 mt-2 rounded-xl overflow-hidden border border-white/10">
                  <ConsolePanel
                    logs={consoleLogs}
                    onClear={() => setConsoleLogs([])}
                    virtualPort={project.virtualPort}
                  />
                </div>
              )}
            </div>
          </div>

          {/* Right Column: AI Coding Agent Activity Status (310px) */}
          <div className="w-72 lg:w-80 shrink-0 h-full">
            <AIActivityPanel
              state={project.status}
              logs={project.logs}
              selectedModel={project.selectedModel}
              repairAttempts={project.repairAttempts}
            />
          </div>
        </div>

        {/* MOBILE LAYOUT (Tab-based fullscreen) */}
        <div className="flex md:hidden flex-1 flex-col overflow-hidden p-2 gap-2">
          <div className="flex-1 min-h-0">
            {mobileTab === "preview" && (
              <LivePreviewFrame
                files={project.files}
                virtualPort={project.virtualPort}
                projectName={project.name}
              />
            )}
            {mobileTab === "code" && (
              <CodeEditorPanel
                file={
                  project.files[project.activeFileName] ||
                  project.files["index.html"]
                }
                onSave={handleSaveFile}
              />
            )}
            {mobileTab === "files" && (
              <FileExplorer
                files={project.files}
                activeFileName={project.activeFileName}
                onSelectFile={(fileName) => {
                  setProject((prev) => ({ ...prev, activeFileName: fileName }));
                  setMobileTab("code");
                }}
              />
            )}
            {mobileTab === "agent" && (
              <AIActivityPanel
                state={project.status}
                logs={project.logs}
                selectedModel={project.selectedModel}
                repairAttempts={project.repairAttempts}
              />
            )}
            {mobileTab === "console" && (
              <ConsolePanel
                logs={consoleLogs}
                onClear={() => setConsoleLogs([])}
                virtualPort={project.virtualPort}
              />
            )}
          </div>

          {/* Mobile Lower Improve Prompt */}
          <div className="p-2.5 bg-[#0a0f24] border border-white/10 rounded-2xl shrink-0">
            <ImproveWebsiteInput
              onImprove={(instruction) => runAgentWorkflow(instruction, true)}
              disabled={project.status !== "ready" && project.status !== "idle" && project.status !== "error"}
            />
          </div>
        </div>
      </div>

      {/* ── MODALS ── */}
      <VersionHistoryModal
        open={historyModalOpen}
        onClose={() => setHistoryModalOpen(false)}
        versions={project.versions}
        currentVersionIndex={project.currentVersionIndex}
        onRestore={handleRestoreVersion}
      />

      <TemplateSelectorModal
        open={templateModalOpen}
        onClose={() => setTemplateModalOpen(false)}
        onSelectTemplate={handleSelectTemplate}
      />
    </div>
  );
}
