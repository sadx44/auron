import { useState, useRef } from "react";
import {
  Smartphone,
  Tablet,
  Monitor,
  RotateCw,
  ExternalLink,
  ShieldCheck,
  Maximize2,
  Minimize2,
} from "lucide-react";
import type { DeviceViewport, ProjectFile } from "../types/website";
import { LocalPreviewManager } from "../services/LocalPreviewManager";
import { cn } from "../../utils/cn";

interface Props {
  files: Record<string, ProjectFile>;
  virtualPort: number;
  projectName: string;
}

export default function LivePreviewFrame({ files, virtualPort, projectName }: Props) {
  const [viewport, setViewport] = useState<DeviceViewport>("desktop");
  const [key, setKey] = useState(0);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const previewHtml = LocalPreviewManager.createPreviewDocument(files, virtualPort);

  const handleRefresh = () => {
    setKey((prev) => prev + 1);
  };

  const handleOpenNewTab = () => {
    const blob = new Blob([previewHtml], { type: "text/html" });
    const url = URL.createObjectURL(blob);
    window.open(url, "_blank");
  };

  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen().catch(() => {});
      setIsFullscreen(true);
    } else {
      document.exitFullscreen().catch(() => {});
      setIsFullscreen(false);
    }
  };

  return (
    <div
      ref={containerRef}
      className={cn(
        "flex flex-col h-full w-full bg-[#070a14] border border-white/10 rounded-2xl overflow-hidden shadow-2xl relative",
        isFullscreen && "rounded-none border-none"
      )}
    >
      {/* Browser Chrome Header */}
      <div className="flex items-center justify-between px-4 py-2.5 bg-[#0b1021] border-b border-white/10 gap-2 flex-wrap">
        {/* Left: Window Dots & Port URL */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5" aria-hidden="true">
            <span className="w-3 h-3 rounded-full bg-rose-500/80" />
            <span className="w-3 h-3 rounded-full bg-amber-500/80" />
            <span className="w-3 h-3 rounded-full bg-emerald-500/80" />
          </div>

          <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-black/50 border border-white/10 text-xs text-slate-300 font-mono">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span className="text-slate-500">http://localhost:{virtualPort}</span>
            <span className="text-slate-400 font-semibold truncate max-w-[120px] sm:max-w-[200px]">
              /{projectName.toLowerCase().replace(/[^a-z0-9]/g, "-")}
            </span>
          </div>
        </div>

        {/* Center: Device Viewport Switcher */}
        <div className="flex items-center gap-1 p-0.5 rounded-xl bg-black/40 border border-white/10">
          <button
            onClick={() => setViewport("mobile")}
            className={cn(
              "flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-medium transition",
              viewport === "mobile"
                ? "bg-cyan-500/20 text-cyan-300 font-bold shadow-sm"
                : "text-slate-400 hover:text-white"
            )}
            title="Mobile (375px)"
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span className="hidden md:inline">375px</span>
          </button>
          <button
            onClick={() => setViewport("tablet")}
            className={cn(
              "flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-medium transition",
              viewport === "tablet"
                ? "bg-cyan-500/20 text-cyan-300 font-bold shadow-sm"
                : "text-slate-400 hover:text-white"
            )}
            title="Tablet (768px)"
          >
            <Tablet className="w-3.5 h-3.5" />
            <span className="hidden md:inline">768px</span>
          </button>
          <button
            onClick={() => setViewport("desktop")}
            className={cn(
              "flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-medium transition",
              viewport === "desktop"
                ? "bg-cyan-500/20 text-cyan-300 font-bold shadow-sm"
                : "text-slate-400 hover:text-white"
            )}
            title="Desktop (100%)"
          >
            <Monitor className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Fluid</span>
          </button>
        </div>

        {/* Right: Actions */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={handleRefresh}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/5 transition"
            title="Reload Sandbox"
          >
            <RotateCw className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={handleOpenNewTab}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/5 transition"
            title="Open in New Tab"
          >
            <ExternalLink className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={toggleFullscreen}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/5 transition"
            title="Toggle Fullscreen"
          >
            {isFullscreen ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* Frame Canvas Wrapper */}
      <div className="flex-1 bg-[#03050c] overflow-auto flex items-center justify-center p-2 sm:p-4">
        <div
          className={cn(
            "h-full bg-white transition-all duration-300 rounded-lg overflow-hidden shadow-2xl relative",
            viewport === "mobile" && "w-[375px] max-w-full rounded-2xl border-4 border-slate-800",
            viewport === "tablet" && "w-[768px] max-w-full rounded-2xl border-4 border-slate-800",
            viewport === "desktop" && "w-full"
          )}
        >
          <iframe
            key={key}
            title={projectName}
            srcDoc={previewHtml}
            sandbox="allow-scripts allow-forms allow-modals allow-popups"
            className="w-full h-full border-none block bg-white"
          />
        </div>
      </div>
    </div>
  );
}
