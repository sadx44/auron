import { FileCode, FileText, Download, Copy, Check } from "lucide-react";
import { useState } from "react";
import type { ProjectFile } from "../types/website";
import { ZipExporter } from "../services/ZipExporter";
import { cn } from "../../utils/cn";

interface Props {
  files: Record<string, ProjectFile>;
  activeFileName: string;
  onSelectFile: (fileName: string) => void;
}

export default function FileExplorer({ files, activeFileName, onSelectFile }: Props) {
  const [copiedFile, setCopiedFile] = useState<string | null>(null);

  const getFileIcon = (fileName: string) => {
    if (fileName.endsWith(".html")) return <FileCode className="w-4 h-4 text-orange-400" />;
    if (fileName.endsWith(".css")) return <FileCode className="w-4 h-4 text-cyan-400" />;
    if (fileName.endsWith(".js")) return <FileCode className="w-4 h-4 text-amber-400" />;
    return <FileText className="w-4 h-4 text-slate-400" />;
  };

  const handleCopy = (file: ProjectFile, e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(file.content);
    setCopiedFile(file.name);
    setTimeout(() => setCopiedFile(null), 2000);
  };

  const handleDownload = (file: ProjectFile, e: React.MouseEvent) => {
    e.stopPropagation();
    ZipExporter.downloadSingleFile(file);
  };

  const fileList = Object.values(files);

  return (
    <div className="flex flex-col h-full w-full bg-[#0a0f24] border border-white/10 rounded-2xl overflow-hidden shadow-xl">
      <div className="px-4 py-3 bg-[#0d1430] border-b border-white/10 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-xs font-extrabold uppercase tracking-wider text-slate-300">Project Files</span>
          <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 font-bold">
            {fileList.length}
          </span>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-2 space-y-1">
        {fileList.map((file) => {
          const isActive = file.name === activeFileName;
          const bytes = new Blob([file.content]).size;
          const kb = (bytes / 1024).toFixed(1);

          return (
            <div
              key={file.name}
              onClick={() => onSelectFile(file.name)}
              className={cn(
                "group flex items-center justify-between px-3 py-2.5 rounded-xl cursor-pointer transition text-xs font-mono",
                isActive
                  ? "bg-cyan-500/15 border border-cyan-400/30 text-white font-semibold"
                  : "hover:bg-white/5 text-slate-300 border border-transparent"
              )}
            >
              <div className="flex items-center gap-2.5 truncate">
                {getFileIcon(file.name)}
                <span className="truncate">{file.name}</span>
                <span className="text-[10px] text-slate-500 hidden sm:inline">{kb} KB</span>
              </div>

              <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition">
                <button
                  onClick={(e) => handleCopy(file, e)}
                  className="p-1 rounded hover:bg-white/10 text-slate-400 hover:text-white"
                  title="Copy File Content"
                >
                  {copiedFile === file.name ? (
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                </button>
                <button
                  onClick={(e) => handleDownload(file, e)}
                  className="p-1 rounded hover:bg-white/10 text-slate-400 hover:text-white"
                  title="Download File"
                >
                  <Download className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      <div className="p-3 bg-[#070a18] border-t border-white/5 text-[11px] text-slate-500 font-mono text-center">
        Click to inspect and edit code
      </div>
    </div>
  );
}
