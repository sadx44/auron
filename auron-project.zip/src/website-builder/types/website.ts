export type BuilderState =
  | "idle"
  | "analyzing"
  | "planning"
  | "selecting-model"
  | "generating"
  | "running"
  | "testing"
  | "fixing"
  | "ready"
  | "error";

export type DeviceViewport = "mobile" | "tablet" | "desktop" | "fullscreen";

export interface ProjectFile {
  name: string;
  language: "html" | "css" | "javascript" | "json" | "markdown";
  content: string;
}

export interface ProjectVersion {
  id: string;
  versionNumber: number;
  timestamp: number;
  description: string;
  files: Record<string, string>;
  modelUsed: string;
}

export interface WebsiteRequirement {
  title: string;
  websiteType: string;
  purpose: string;
  targetAudience: string;
  sections: string[];
  theme: {
    mode: "dark" | "light" | "cyberpunk" | "minimal" | "glassmorphism" | "neon";
    primaryColor: string;
    secondaryColor: string;
    backgroundColor: string;
    textColor: string;
    accentColor: string;
  };
  typography: string;
  animations: boolean;
  interactiveFeatures: string[];
  responsiveRequirements: string;
  selectedTemplate?: string;
}

export interface AgentLog {
  id: string;
  step: string;
  status: "pending" | "running" | "done" | "warn" | "error";
  message: string;
  timestamp: number;
}

export interface AIModelCandidate {
  id: string;
  name: string;
  provider: "Google Gemini" | "Anthropic" | "OpenAI" | "Local LLM";
  codingScore: number; // 0-100
  speed: "Fast" | "Balanced" | "Maximum";
  contextWindow: string;
  recommendedFor: string;
  isAvailable: boolean;
  isDefault?: boolean;
}

export interface CodeValidationError {
  file: string;
  line?: number;
  severity: "error" | "warning";
  message: string;
  codeSnippet?: string;
  autoFixable: boolean;
}

export interface ConsoleLogMessage {
  id: string;
  type: "log" | "warn" | "error" | "info";
  message: string;
  timestamp: number;
}

export interface WebsiteProject {
  id: string;
  name: string;
  prompt: string;
  status: BuilderState;
  files: Record<string, ProjectFile>;
  activeFileName: string;
  versions: ProjectVersion[];
  currentVersionIndex: number;
  selectedModel: AIModelCandidate;
  requirements?: WebsiteRequirement;
  logs: AgentLog[];
  validationErrors: CodeValidationError[];
  repairAttempts: number;
  virtualPort: number;
  createdAt: number;
  updatedAt: number;
  liveUrl?: string;
}
