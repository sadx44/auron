import type { ConsoleLogMessage, ProjectFile } from "../types/website";

export class LocalPreviewManager {
  private static portCounter = 3400;

  /**
   * Generates a unique virtual localhost port for each generated website
   */
  static allocatePort(): number {
    this.portCounter += Math.floor(Math.random() * 8) + 1;
    return this.portCounter;
  }

  /**
   * Constructs an isolated, secure bundled HTML document suitable for an iframe sandbox.
   * Embeds CSS & JavaScript seamlessly, while injecting an isolated postMessage
   * bridge to stream iframe console messages to the IDE console panel.
   */
  static createPreviewDocument(
    files: Record<string, ProjectFile>,
    _virtualPort: number
  ): string {
    const htmlFile = files["index.html"]?.content || "<!DOCTYPE html><html><body><h1>Empty Project</h1></body></html>";
    const cssContent = files["style.css"]?.content || "";
    const jsContent = files["script.js"]?.content || "";

    // Console bridge script injected into preview to safely capture logs
    const consoleBridge = `
<script>
  (function() {
    const sendLog = (type, args) => {
      try {
        const text = Array.from(args).map(a => {
          if (typeof a === 'object') return JSON.stringify(a);
          return String(a);
        }).join(' ');
        window.parent.postMessage({
          source: 'priya-preview-sandbox',
          type: type,
          message: text,
          timestamp: Date.now()
        }, '*');
      } catch (e) {}
    };

    const origLog = console.log;
    const origWarn = console.warn;
    const origError = console.error;

    console.log = function(...args) { sendLog('log', args); origLog.apply(console, args); };
    console.warn = function(...args) { sendLog('warn', args); origWarn.apply(console, args); };
    console.error = function(...args) { sendLog('error', args); origError.apply(console, args); };

    window.addEventListener('error', function(e) {
      sendLog('error', [e.message + ' at ' + (e.filename || '') + ':' + (e.lineno || '')]);
    });
  })();
</script>
`;

    let bundled = htmlFile;

    // Inject console bridge right after <head> or at start
    if (bundled.includes("<head>")) {
      bundled = bundled.replace("<head>", `<head>\n${consoleBridge}`);
    } else {
      bundled = consoleBridge + bundled;
    }

    // Inline style.css if present to avoid external fetch dependency in sandboxed frame
    if (cssContent.trim()) {
      const inlineStyle = `<style id="priya-inlined-styles">\n${cssContent}\n</style>`;
      if (bundled.includes("</head>")) {
        bundled = bundled.replace("</head>", `${inlineStyle}\n</head>`);
      } else {
        bundled = inlineStyle + bundled;
      }
    }

    // Inline script.js if present
    if (jsContent.trim()) {
      const inlineScript = `<script id="priya-inlined-script">\n${jsContent}\n</script>`;
      if (bundled.includes("</body>")) {
        bundled = bundled.replace("</body>", `${inlineScript}\n</body>`);
      } else {
        bundled += `\n${inlineScript}`;
      }
    }

    return bundled;
  }

  /**
   * Sets up a message listener to pipe console logs from the sandboxed iframe into a callback.
   */
  static listenToConsole(onLog: (msg: ConsoleLogMessage) => void): () => void {
    const handler = (event: MessageEvent) => {
      if (event.data && event.data.source === "priya-preview-sandbox") {
        onLog({
          id: `log-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
          type: event.data.type || "log",
          message: event.data.message || "",
          timestamp: event.data.timestamp || Date.now(),
        });
      }
    };

    window.addEventListener("message", handler);
    return () => window.removeEventListener("message", handler);
  }
}
