import type { CodeValidationError, ProjectFile } from "../types/website";

export class CodeValidator {
  /**
   * Validates HTML, CSS, and JS files for common frontend breakages,
   * syntax discrepancies, broken listeners, unclosed tags, and mobile issues.
   */
  static validate(files: Record<string, ProjectFile>): CodeValidationError[] {
    const errors: CodeValidationError[] = [];

    // 1. Validate index.html
    const htmlFile = files["index.html"];
    if (!htmlFile || !htmlFile.content.trim()) {
      errors.push({
        file: "index.html",
        severity: "error",
        message: "Missing or empty index.html entry point.",
        autoFixable: true,
      });
    } else {
      const html = htmlFile.content;

      if (!html.toLowerCase().includes("<!doctype html>")) {
        errors.push({
          file: "index.html",
          severity: "warning",
          message: "Missing <!DOCTYPE html> declaration at top of file.",
          autoFixable: true,
        });
      }

      if (!html.includes('<meta name="viewport"') && !html.includes("<meta name='viewport'")) {
        errors.push({
          file: "index.html",
          severity: "error",
          message: "Missing responsive viewport meta tag. Mobile rendering will be compromised.",
          autoFixable: true,
        });
      }

      // Check tag balance for critical tags
      const criticalTags = ["html", "head", "body", "main", "nav", "header", "footer"];
      for (const tag of criticalTags) {
        const openCount = (html.match(new RegExp(`<${tag}(\\s|>|$)`, "gi")) || []).length;
        const closeCount = (html.match(new RegExp(`</${tag}>`, "gi")) || []).length;
        if (openCount !== closeCount) {
          errors.push({
            file: "index.html",
            severity: "error",
            message: `Mismatched tag count for <${tag}>: ${openCount} opened, ${closeCount} closed.`,
            autoFixable: true,
          });
        }
      }

      // Check for link to style.css and script.js if they exist
      if (files["style.css"] && !html.includes("style.css")) {
        errors.push({
          file: "index.html",
          severity: "warning",
          message: 'style.css exists in project but is not linked via <link rel="stylesheet" href="style.css">.',
          autoFixable: true,
        });
      }

      if (files["script.js"] && !html.includes("script.js")) {
        errors.push({
          file: "index.html",
          severity: "warning",
          message: 'script.js exists in project but is not referenced via <script src="script.js">.',
          autoFixable: true,
        });
      }
    }

    // 2. Validate style.css
    const cssFile = files["style.css"];
    if (cssFile && cssFile.content) {
      const css = cssFile.content;
      const openBraces = (css.match(/\{/g) || []).length;
      const closeBraces = (css.match(/\}/g) || []).length;

      if (openBraces !== closeBraces) {
        errors.push({
          file: "style.css",
          severity: "error",
          message: `Unbalanced CSS braces: ${openBraces} '{' vs ${closeBraces} '}'. Styles may fail to cascade.`,
          autoFixable: true,
        });
      }

      if (!css.includes("box-sizing") && !css.includes("* {")) {
        errors.push({
          file: "style.css",
          severity: "warning",
          message: "Missing universal box-sizing: border-box reset. Layout may overflow on narrow viewports.",
          autoFixable: true,
        });
      }
    }

    // 3. Validate script.js
    const jsFile = files["script.js"];
    if (jsFile && jsFile.content) {
      const js = jsFile.content;

      // Check parentheses and curly braces
      const openParens = (js.match(/\(/g) || []).length;
      const closeParens = (js.match(/\)/g) || []).length;
      if (openParens !== closeParens) {
        errors.push({
          file: "script.js",
          severity: "error",
          message: `Mismatched parentheses in JavaScript: ${openParens} '(' vs ${closeParens} ')'.`,
          autoFixable: true,
        });
      }

      const openBraces = (js.match(/\{/g) || []).length;
      const closeBraces = (js.match(/\}/g) || []).length;
      if (openBraces !== closeBraces) {
        errors.push({
          file: "script.js",
          severity: "error",
          message: `Mismatched braces in JavaScript: ${openBraces} '{' vs ${closeBraces} '}'.`,
          autoFixable: true,
        });
      }

      // Check for document.addEventListener DOMContentLoaded or defer
      if (!js.includes("DOMContentLoaded") && !js.includes("addEventListener") && !js.includes("window.onload")) {
        errors.push({
          file: "script.js",
          severity: "warning",
          message: "JavaScript code runs immediately without DOMContentLoaded guard.",
          autoFixable: true,
        });
      }
    }

    return errors;
  }
}
