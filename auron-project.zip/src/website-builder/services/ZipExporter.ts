import JSZip from "jszip";
import type { ProjectFile } from "../types/website";

export class ZipExporter {
  /**
   * Packages project files into a clean zip archive and triggers browser download
   */
  static async exportToZip(
    files: Record<string, ProjectFile>,
    projectName: string = "priya-ai-website"
  ): Promise<void> {
    const zip = new JSZip();

    for (const [filename, file] of Object.entries(files)) {
      zip.file(filename, file.content);
    }

    const blob = await zip.generateAsync({ type: "blob" });
    const safeName = projectName.toLowerCase().replace(/[^a-z0-9_-]/g, "-") || "my-website";

    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${safeName}.zip`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  /**
   * Downloads a single project file directly (e.g. index.html, style.css)
   */
  static downloadSingleFile(file: ProjectFile): void {
    const mimeTypes: Record<string, string> = {
      html: "text/html;charset=utf-8",
      css: "text/css;charset=utf-8",
      javascript: "application/javascript;charset=utf-8",
      json: "application/json;charset=utf-8",
      markdown: "text/markdown;charset=utf-8",
    };

    const mime = mimeTypes[file.language] || "text/plain;charset=utf-8";
    const blob = new Blob([file.content], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = file.name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }
}
