import type { ProjectFile, ProjectVersion } from "../types/website";

export class VersionManager {
  /**
   * Creates a new version snapshot from current files
   */
  static createSnapshot(
    files: Record<string, ProjectFile>,
    description: string,
    modelUsed: string,
    existingVersions: ProjectVersion[] = []
  ): ProjectVersion {
    const serialized: Record<string, string> = {};
    for (const [key, file] of Object.entries(files)) {
      serialized[key] = file.content;
    }

    const versionNumber = existingVersions.length + 1;
    return {
      id: `v-${Date.now()}-${versionNumber}`,
      versionNumber,
      timestamp: Date.now(),
      description: description || `Version ${versionNumber}`,
      files: serialized,
      modelUsed,
    };
  }

  /**
   * Restores a version into active ProjectFile structures
   */
  static restoreVersion(version: ProjectVersion): Record<string, ProjectFile> {
    const restored: Record<string, ProjectFile> = {};
    for (const [filename, content] of Object.entries(version.files)) {
      let language: ProjectFile["language"] = "html";
      if (filename.endsWith(".css")) language = "css";
      else if (filename.endsWith(".js")) language = "javascript";
      else if (filename.endsWith(".json")) language = "json";
      else if (filename.endsWith(".md")) language = "markdown";

      restored[filename] = {
        name: filename,
        language,
        content,
      };
    }
    return restored;
  }
}
