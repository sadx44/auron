import type { ProjectFile, WebsiteRequirement } from "../types/website";

export interface WebsiteTemplate {
  id: string;
  name: string;
  category: string;
  badge: string;
  description: string;
  icon: string;
  promptExample: string;
  buildFiles: (req: WebsiteRequirement) => Record<string, ProjectFile>;
}

export class TemplateRegistry {
  static getTemplates(): WebsiteTemplate[] {
    return [
      {
        id: "portfolio",
        name: "Futuristic Developer Portfolio",
        category: "Portfolio & Resume",
        badge: "Trending",
        description: "Dark neon aesthetic, interactive project modals, skill radar, and contact drawer.",
        icon: "Briefcase",
        promptExample: "Create a modern portfolio website for a senior full-stack developer with dark neon theme and interactive project cards.",
        buildFiles: (req) => this.generatePortfolioFiles(req),
      },
      {
        id: "saas",
        name: "NexusAI SaaS Platform",
        category: "SaaS & Startup",
        badge: "High Conversion",
        description: "Bento-grid features, interactive pricing calculator, live dashboard mockup, and testimonials.",
        icon: "Cpu",
        promptExample: "Build a high-converting SaaS landing page with dark glassmorphism, billing toggle, and customer reviews.",
        buildFiles: (req) => this.generateSaaSFiles(req),
      },
      {
        id: "streaming",
        name: "CineStream Cinema Portal",
        category: "Entertainment",
        badge: "Netflix Style",
        description: "Dark cinema interface, trending billboard, category carousels, and video trailer modal.",
        icon: "Film",
        promptExample: "Make a Netflix-style movie streaming website with a dark interface and category slider.",
        buildFiles: (req) => this.generateStreamingFiles(req),
      },
      {
        id: "anime",
        name: "AnimeVerse Streaming Hub",
        category: "Anime & Otaku",
        badge: "Vibrant",
        description: "Anime series showcase, episode selector, character highlights, and watchlist tracker.",
        icon: "Sparkles",
        promptExample: "Build a responsive anime streaming landing page with top 10 series and trailer preview.",
        buildFiles: (req) => this.generateAnimeFiles(req),
      },
      {
        id: "ecommerce",
        name: "Aura Minimalist E-Commerce",
        category: "E-Commerce",
        badge: "Shop Ready",
        description: "Curated lifestyle catalog, interactive slide-over cart, size selector, and checkout preview.",
        icon: "ShoppingBag",
        promptExample: "Create a luxury minimalist e-commerce store with working cart and instant filter tabs.",
        buildFiles: (req) => this.generateEcommerceFiles(req),
      },
      {
        id: "gaming",
        name: "Cyberpunk 2088 Title Portal",
        category: "Gaming & Esports",
        badge: "Ultra Sci-Fi",
        description: "Glitch neon typography, character class picker, preorder countdown, and trailer popup.",
        icon: "Gamepad2",
        promptExample: "Design a cyberpunk gaming website with neon glowing buttons and character selector.",
        buildFiles: (req) => this.generateGamingFiles(req),
      },
    ];
  }

  // 1. Portfolio Files Generator
  static generatePortfolioFiles(req: WebsiteRequirement): Record<string, ProjectFile> {
    const p = req.theme.primaryColor || "#22d3ee";
    const s = req.theme.secondaryColor || "#a855f7";
    const bg = req.theme.backgroundColor || "#070913";
    const text = req.theme.textColor || "#f8fafc";

    const html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${req.title || "Alex Vance — Full Stack Engineer"}</title>
  <link rel="stylesheet" href="style.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;600;800&family=JetBrains+Mono:wght@400;700&display=swap" rel="stylesheet">
</head>
<body>
  <!-- Ambient background glow -->
  <div class="glow-orb glow-top"></div>
  <div class="glow-orb glow-bottom"></div>

  <!-- Navigation -->
  <header class="navbar">
    <div class="container nav-inner">
      <a href="#" class="brand-logo">
        <span class="logo-dot"></span>
        <span class="logo-text">Alex.dev</span>
      </a>
      <nav class="nav-links" id="navLinks">
        <a href="#about" class="nav-item">About</a>
        <a href="#projects" class="nav-item">Projects</a>
        <a href="#skills" class="nav-item">Skills</a>
        <a href="#contact" class="nav-item btn-primary-nav">Let's Talk</a>
      </nav>
      <button class="mobile-toggle" id="menuToggle" aria-label="Toggle Menu">
        <span></span><span></span><span></span>
      </button>
    </div>
  </header>

  <!-- Hero Section -->
  <section class="hero-section">
    <div class="container hero-grid">
      <div class="hero-content">
        <div class="status-badge">
          <span class="ping-circle"></span>
          <span>Available for New Projects & Roles</span>
        </div>
        <h1 class="hero-title">
          Building <span class="gradient-text">Scalable Systems</span> & Expressive User Interfaces.
        </h1>
        <p class="hero-subtitle">
          Senior Full Stack Engineer specializing in TypeScript, React, Distributed Systems, and Real-Time AI applications. Transforming bold ideas into production software.
        </p>
        <div class="hero-cta-group">
          <a href="#projects" class="btn btn-primary">Explore Featured Work</a>
          <button class="btn btn-secondary" id="openResumeModal">View Tech Stack</button>
        </div>
        <div class="hero-metrics">
          <div class="metric-item">
            <span class="metric-num">7+</span>
            <span class="metric-label">Years Experience</span>
          </div>
          <div class="metric-divider"></div>
          <div class="metric-item">
            <span class="metric-num">45+</span>
            <span class="metric-label">Apps Delivered</span>
          </div>
          <div class="metric-divider"></div>
          <div class="metric-item">
            <span class="metric-num">99.9%</span>
            <span class="metric-label">Uptime Record</span>
          </div>
        </div>
      </div>

      <div class="hero-visual">
        <div class="code-card">
          <div class="card-header">
            <span class="dot dot-red"></span>
            <span class="dot dot-yellow"></span>
            <span class="dot dot-green"></span>
            <span class="card-filename">engineer.config.ts</span>
          </div>
          <pre class="code-body"><code><span class="kw">const</span> <span class="var">developer</span> = {
  name: <span class="str">"Alex Vance"</span>,
  title: <span class="str">"Senior Full-Stack Architect"</span>,
  specialties: [
    <span class="str">"Next.js"</span>, <span class="str">"Node.js"</span>,
    <span class="str">"WebSockets"</span>, <span class="str">"AI Models"</span>
  ],
  passion: <span class="str">"Crafting fast, intuitive web"</span>,
  hireable: <span class="bool">true</span>
};

<span class="comment">// Ready to collaborate?</span>
<span class="var">developer</span>.<span class="fn">connect</span>({ speed: <span class="str">"fast"</span> });</code></pre>
        </div>
      </div>
    </div>
  </section>

  <!-- Projects Section -->
  <section class="section" id="projects">
    <div class="container">
      <div class="section-header">
        <p class="section-tag">SELECTED WORKS</p>
        <h2 class="section-title">Projects That Made an Impact</h2>
        <div class="filter-bar" id="projectFilters">
          <button class="filter-btn active" data-filter="all">All Systems</button>
          <button class="filter-btn" data-filter="ai">AI / ML</button>
          <button class="filter-btn" data-filter="web">Web Apps</button>
          <button class="filter-btn" data-filter="mobile">Cloud & Scale</button>
        </div>
      </div>

      <div class="projects-grid" id="projectsGrid">
        <!-- Project 1 -->
        <article class="project-card" data-category="ai">
          <div class="project-thumb thumb-1">
            <span class="project-tag">Real-Time AI</span>
          </div>
          <div class="project-body">
            <h3 class="project-name">Aether AI Assistant</h3>
            <p class="project-desc">Real-time voice-to-voice neural assistant with sub-200ms latency Web Audio engine.</p>
            <div class="tech-stack">
              <span>TypeScript</span><span>Web Audio</span><span>Gemini Live</span>
            </div>
            <button class="project-link-btn" onclick="openProjectModal('Aether AI Assistant', 'Sub-200ms latency voice interface built with WebSockets, Web Audio API, and Gemini Live.')">View Details &rarr;</button>
          </div>
        </article>

        <!-- Project 2 -->
        <article class="project-card" data-category="web">
          <div class="project-thumb thumb-2">
            <span class="project-tag">Fintech Cloud</span>
          </div>
          <div class="project-body">
            <h3 class="project-name">VaultIQ Dashboard</h3>
            <p class="project-desc">High-frequency algorithmic trading terminal processing 100k events/sec with reactive chart widgets.</p>
            <div class="tech-stack">
              <span>React</span><span>Tailwind</span><span>Go Engine</span>
            </div>
            <button class="project-link-btn" onclick="openProjectModal('VaultIQ Dashboard', 'High-speed financial metrics visualizer with real-time websocket candles and risk calculation.')">View Details &rarr;</button>
          </div>
        </article>

        <!-- Project 3 -->
        <article class="project-card" data-category="ai">
          <div class="project-thumb thumb-3">
            <span class="project-tag">Developer Tools</span>
          </div>
          <div class="project-body">
            <h3 class="project-name">DevPulse Autonomous Agent</h3>
            <p class="project-desc">Self-healing CI/CD agent that automatically diagnoses broken build runs and generates PR fixes.</p>
            <div class="tech-stack">
              <span>Node.js</span><span>Docker</span><span>LLM Graph</span>
            </div>
            <button class="project-link-btn" onclick="openProjectModal('DevPulse Autonomous Agent', 'Autonomous developer workflow tool integrating Git hooks with automated test synthesis.')">View Details &rarr;</button>
          </div>
        </article>
      </div>
    </div>
  </section>

  <!-- Skills Section -->
  <section class="section section-darker" id="skills">
    <div class="container">
      <div class="section-header">
        <p class="section-tag">CAPABILITIES</p>
        <h2 class="section-title">Technical Mastery</h2>
      </div>
      <div class="skills-grid">
        <div class="skill-card">
          <div class="skill-icon">&lt;/&gt;</div>
          <h3>Frontend Engineering</h3>
          <p>React 19, TypeScript, Next.js, Web Audio API, Canvas, Tailwind CSS, Responsive Design, State Architecture.</p>
        </div>
        <div class="skill-card">
          <div class="skill-icon">&#9881;</div>
          <h3>Backend & Distributed</h3>
          <p>Node.js, Express, Go, PostgreSQL, Redis, GraphQL, WebSocket Streaming, RESTful API Design.</p>
        </div>
        <div class="skill-card">
          <div class="skill-icon">&#9889;</div>
          <h3>AI & Agentic Systems</h3>
          <p>Gemini Live API, Multi-modal streaming, Agentic workflows, RAG, Prompt Engineering, Function Calling.</p>
        </div>
      </div>
    </div>
  </section>

  <!-- Contact CTA -->
  <section class="section" id="contact">
    <div class="container">
      <div class="contact-card">
        <div class="contact-header">
          <h2 class="contact-title">Let's Build Something Extraordinary</h2>
          <p class="contact-desc">Have a visionary project in mind or looking for a lead engineer? Drop a line and let's talk.</p>
        </div>
        <form class="contact-form" id="contactForm">
          <div class="form-row">
            <input type="text" placeholder="Your Name" required class="form-input">
            <input type="email" placeholder="Your Email" required class="form-input">
          </div>
          <textarea placeholder="Tell me about your project..." rows="4" required class="form-input"></textarea>
          <button type="submit" class="btn btn-primary btn-block">Send Message</button>
        </form>
        <div class="toast" id="formToast">Message dispatched successfully! Alex will reply shortly.</div>
      </div>
    </div>
  </section>

  <!-- Footer -->
  <footer class="footer">
    <div class="container footer-inner">
      <p class="copyright">&copy; <span id="currentYear"></span> Alex Vance. Crafted with precision & clean code.</p>
      <div class="social-links">
        <a href="https://github.com" target="_blank" rel="noreferrer">GitHub</a>
        <a href="https://twitter.com" target="_blank" rel="noreferrer">X / Twitter</a>
        <a href="https://linkedin.com" target="_blank" rel="noreferrer">LinkedIn</a>
      </div>
    </div>
  </footer>

  <!-- Modal Component -->
  <div class="modal-overlay" id="projectModal">
    <div class="modal-box">
      <div class="modal-header">
        <h3 id="modalTitle">Project Title</h3>
        <button class="modal-close" id="modalClose">&times;</button>
      </div>
      <p id="modalDesc" class="modal-content-text">Project description will appear here.</p>
      <div class="modal-footer">
        <button class="btn btn-primary" onclick="closeProjectModal()">Close Preview</button>
      </div>
    </div>
  </div>

  <script src="script.js" defer></script>
</body>
</html>`;

    const css = `/* Modern Aesthetic Stylesheet */
:root {
  --primary: ${p};
  --secondary: ${s};
  --bg: ${bg};
  --surface: #0f152b;
  --surface-hover: #182245;
  --text: ${text};
  --text-muted: #94a3b8;
  --border: rgba(255, 255, 255, 0.1);
  --border-focus: ${p};
  --radius-sm: 8px;
  --radius-md: 14px;
  --radius-lg: 24px;
  --font-sans: 'Plus Jakarta Sans', system-ui, sans-serif;
  --font-mono: 'JetBrains Mono', monospace;
}

*, *::before, *::after {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}

html {
  scroll-behavior: smooth;
  font-family: var(--font-sans);
  background-color: var(--bg);
  color: var(--text);
  line-height: 1.6;
}

body {
  overflow-x: hidden;
  position: relative;
  min-height: 100vh;
}

.container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 1.5rem;
}

/* Ambient Background Orbs */
.glow-orb {
  position: fixed;
  border-radius: 50%;
  filter: blur(140px);
  pointer-events: none;
  z-index: 0;
  opacity: 0.15;
}

.glow-top {
  width: 500px;
  height: 500px;
  top: -150px;
  left: 20%;
  background: var(--primary);
}

.glow-bottom {
  width: 450px;
  height: 450px;
  bottom: -100px;
  right: 15%;
  background: var(--secondary);
}

/* Navbar */
.navbar {
  position: sticky;
  top: 0;
  z-index: 100;
  background: rgba(7, 9, 19, 0.85);
  backdrop-filter: blur(16px);
  border-bottom: 1px solid var(--border);
}

.nav-inner {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 72px;
}

.brand-logo {
  display: flex;
  align-items: center;
  gap: 0.6rem;
  text-decoration: none;
  font-weight: 800;
  font-size: 1.25rem;
  color: #fff;
}

.logo-dot {
  width: 10px;
  height: 10px;
  border-radius: 50%;
  background: var(--primary);
  box-shadow: 0 0 14px var(--primary);
}

.nav-links {
  display: flex;
  align-items: center;
  gap: 2rem;
}

.nav-item {
  color: var(--text-muted);
  text-decoration: none;
  font-size: 0.95rem;
  font-weight: 600;
  transition: color 0.2s;
}

.nav-item:hover {
  color: #fff;
}

.btn-primary-nav {
  padding: 0.55rem 1.2rem;
  border-radius: var(--radius-sm);
  background: linear-gradient(135deg, var(--primary), var(--secondary));
  color: #fff !important;
}

.mobile-toggle {
  display: none;
  flex-direction: column;
  gap: 5px;
  background: transparent;
  border: none;
  cursor: pointer;
  padding: 6px;
}

.mobile-toggle span {
  display: block;
  width: 24px;
  height: 2px;
  background: #fff;
  transition: 0.3s;
}

/* Hero Section */
.hero-section {
  position: relative;
  z-index: 1;
  padding: 6rem 0 4rem;
}

.hero-grid {
  display: grid;
  grid-template-columns: 1.2fr 1fr;
  gap: 4rem;
  align-items: center;
}

.status-badge {
  display: inline-flex;
  align-items: center;
  gap: 0.6rem;
  padding: 0.4rem 0.9rem;
  border-radius: 9999px;
  background: rgba(34, 211, 238, 0.1);
  border: 1px solid rgba(34, 211, 238, 0.3);
  font-size: 0.85rem;
  font-weight: 600;
  color: var(--primary);
  margin-bottom: 1.5rem;
}

.ping-circle {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: var(--primary);
  box-shadow: 0 0 10px var(--primary);
  animation: pulse 2s infinite;
}

@keyframes pulse {
  0% { transform: scale(0.95); opacity: 0.8; }
  50% { transform: scale(1.2); opacity: 1; }
  100% { transform: scale(0.95); opacity: 0.8; }
}

.hero-title {
  font-size: 3.4rem;
  font-weight: 800;
  line-height: 1.15;
  margin-bottom: 1.2rem;
  letter-spacing: -0.03em;
}

.gradient-text {
  background: linear-gradient(135deg, var(--primary), #a5f3fc, var(--secondary));
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}

.hero-subtitle {
  font-size: 1.15rem;
  color: var(--text-muted);
  max-width: 580px;
  margin-bottom: 2.2rem;
}

.hero-cta-group {
  display: flex;
  gap: 1rem;
  margin-bottom: 3.5rem;
}

.btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  padding: 0.85rem 1.75rem;
  font-size: 0.95rem;
  font-weight: 700;
  border-radius: var(--radius-sm);
  cursor: pointer;
  text-decoration: none;
  transition: all 0.25s;
  border: none;
}

.btn-primary {
  background: linear-gradient(135deg, var(--primary), var(--secondary));
  color: #fff;
  box-shadow: 0 4px 20px rgba(34, 211, 238, 0.3);
}

.btn-primary:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 30px rgba(34, 211, 238, 0.45);
}

.btn-secondary {
  background: rgba(255, 255, 255, 0.06);
  border: 1px solid var(--border);
  color: #fff;
}

.btn-secondary:hover {
  background: rgba(255, 255, 255, 0.12);
  border-color: rgba(255, 255, 255, 0.25);
}

.hero-metrics {
  display: flex;
  align-items: center;
  gap: 2rem;
  padding-top: 1.5rem;
  border-top: 1px solid var(--border);
}

.metric-item {
  display: flex;
  flex-direction: column;
}

.metric-num {
  font-size: 1.75rem;
  font-weight: 800;
  color: #fff;
}

.metric-label {
  font-size: 0.82rem;
  color: var(--text-muted);
}

.metric-divider {
  width: 1px;
  height: 36px;
  background: var(--border);
}

/* Code Card Visual */
.code-card {
  background: #090d1f;
  border: 1px solid rgba(255, 255, 255, 0.12);
  border-radius: var(--radius-md);
  box-shadow: 0 20px 50px rgba(0, 0, 0, 0.6);
  overflow: hidden;
}

.card-header {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px 18px;
  background: rgba(255, 255, 255, 0.04);
  border-bottom: 1px solid var(--border);
}

.dot {
  width: 11px;
  height: 11px;
  border-radius: 50%;
}

.dot-red { background: #ef4444; }
.dot-yellow { background: #f59e0b; }
.dot-green { background: #10b981; }

.card-filename {
  margin-left: 8px;
  font-family: var(--font-mono);
  font-size: 0.8rem;
  color: var(--text-muted);
}

.code-body {
  padding: 1.5rem;
  font-family: var(--font-mono);
  font-size: 0.9rem;
  line-height: 1.7;
  overflow-x: auto;
}

.kw { color: #f472b6; font-weight: bold; }
.var { color: #38bdf8; }
.str { color: #34d399; }
.bool { color: #fbbf24; }
.fn { color: #a78bfa; }
.comment { color: #64748b; font-style: italic; }

/* Sections */
.section {
  position: relative;
  z-index: 1;
  padding: 6rem 0;
}

.section-darker {
  background: rgba(5, 7, 15, 0.6);
  border-top: 1px solid var(--border);
  border-bottom: 1px solid var(--border);
}

.section-header {
  text-align: center;
  max-width: 650px;
  margin: 0 auto 3.5rem;
}

.section-tag {
  font-size: 0.8rem;
  font-weight: 800;
  letter-spacing: 0.15em;
  color: var(--primary);
  margin-bottom: 0.6rem;
}

.section-title {
  font-size: 2.4rem;
  font-weight: 800;
  letter-spacing: -0.02em;
}

/* Projects Filter & Grid */
.filter-bar {
  display: inline-flex;
  gap: 0.5rem;
  background: rgba(255, 255, 255, 0.05);
  padding: 4px;
  border-radius: 9999px;
  margin-top: 1.5rem;
  border: 1px solid var(--border);
}

.filter-btn {
  padding: 0.45rem 1.1rem;
  background: transparent;
  border: none;
  color: var(--text-muted);
  font-weight: 600;
  font-size: 0.85rem;
  border-radius: 9999px;
  cursor: pointer;
  transition: all 0.2s;
}

.filter-btn.active {
  background: var(--primary);
  color: #000;
}

.projects-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
  gap: 2rem;
}

.project-card {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: var(--radius-md);
  overflow: hidden;
  transition: all 0.3s;
}

.project-card:hover {
  transform: translateY(-6px);
  border-color: rgba(34, 211, 238, 0.4);
  box-shadow: 0 14px 40px rgba(0, 0, 0, 0.5);
}

.project-thumb {
  height: 180px;
  display: flex;
  align-items: flex-end;
  padding: 1.2rem;
  background-size: cover;
}

.thumb-1 { background: linear-gradient(135deg, #093444, #191b45); }
.thumb-2 { background: linear-gradient(135deg, #182645, #3a1c52); }
.thumb-3 { background: linear-gradient(135deg, #2b173d, #0d383b); }

.project-tag {
  font-size: 0.75rem;
  font-weight: 700;
  padding: 4px 10px;
  border-radius: 9999px;
  background: rgba(0, 0, 0, 0.6);
  backdrop-filter: blur(8px);
  color: #fff;
  border: 1px solid rgba(255, 255, 255, 0.15);
}

.project-body {
  padding: 1.5rem;
}

.project-name {
  font-size: 1.25rem;
  font-weight: 700;
  margin-bottom: 0.6rem;
}

.project-desc {
  font-size: 0.9rem;
  color: var(--text-muted);
  margin-bottom: 1.2rem;
}

.tech-stack {
  display: flex;
  flex-wrap: wrap;
  gap: 0.4rem;
  margin-bottom: 1.2rem;
}

.tech-stack span {
  font-family: var(--font-mono);
  font-size: 0.75rem;
  background: rgba(255, 255, 255, 0.05);
  padding: 3px 8px;
  border-radius: 4px;
  color: #a5f3fc;
}

.project-link-btn {
  background: transparent;
  border: none;
  color: var(--primary);
  font-weight: 700;
  font-size: 0.9rem;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 4px;
}

/* Skills */
.skills-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
  gap: 2rem;
}

.skill-card {
  background: var(--surface);
  border: 1px solid var(--border);
  padding: 2.2rem;
  border-radius: var(--radius-md);
  transition: transform 0.2s;
}

.skill-card:hover {
  transform: translateY(-4px);
}

.skill-icon {
  font-size: 2rem;
  margin-bottom: 1rem;
}

.skill-card h3 {
  font-size: 1.25rem;
  font-weight: 700;
  margin-bottom: 0.8rem;
}

.skill-card p {
  color: var(--text-muted);
  font-size: 0.92rem;
}

/* Contact */
.contact-card {
  background: linear-gradient(135deg, rgba(15, 21, 43, 0.9), rgba(24, 34, 69, 0.9));
  border: 1px solid var(--border);
  border-radius: var(--radius-lg);
  padding: 3.5rem;
  max-width: 800px;
  margin: 0 auto;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
}

.contact-header {
  text-align: center;
  margin-bottom: 2.5rem;
}

.contact-title {
  font-size: 2.2rem;
  font-weight: 800;
  margin-bottom: 0.8rem;
}

.contact-desc {
  color: var(--text-muted);
}

.contact-form {
  display: flex;
  flex-direction: column;
  gap: 1.2rem;
}

.form-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1.2rem;
}

.form-input {
  width: 100%;
  padding: 0.9rem 1.2rem;
  background: rgba(0, 0, 0, 0.35);
  border: 1px solid var(--border);
  border-radius: var(--radius-sm);
  color: #fff;
  font-family: inherit;
  font-size: 0.95rem;
  outline: none;
  transition: border-color 0.2s;
}

.form-input:focus {
  border-color: var(--primary);
}

.btn-block {
  width: 100%;
}

.toast {
  display: none;
  margin-top: 1rem;
  padding: 0.9rem;
  border-radius: var(--radius-sm);
  background: rgba(16, 185, 129, 0.15);
  border: 1px solid #10b981;
  color: #6ee7b7;
  text-align: center;
  font-weight: 600;
}

.toast.show {
  display: block;
  animation: fadeIn 0.3s;
}

@keyframes fadeIn {
  from { opacity: 0; transform: translateY(6px); }
  to { opacity: 1; transform: translateY(0); }
}

/* Footer */
.footer {
  border-top: 1px solid var(--border);
  padding: 2.5rem 0;
  color: var(--text-muted);
  font-size: 0.9rem;
}

.footer-inner {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.social-links {
  display: flex;
  gap: 1.5rem;
}

.social-links a {
  color: var(--text-muted);
  text-decoration: none;
  transition: color 0.2s;
}

.social-links a:hover {
  color: #fff;
}

/* Modal */
.modal-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.75);
  backdrop-filter: blur(8px);
  z-index: 999;
  display: none;
  align-items: center;
  justify-content: center;
  padding: 1.5rem;
}

.modal-overlay.open {
  display: flex;
}

.modal-box {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: var(--radius-md);
  max-width: 500px;
  width: 100%;
  padding: 2rem;
  box-shadow: 0 25px 60px rgba(0, 0, 0, 0.8);
}

.modal-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 1.2rem;
}

.modal-close {
  background: transparent;
  border: none;
  color: var(--text-muted);
  font-size: 1.6rem;
  cursor: pointer;
  line-height: 1;
}

.modal-content-text {
  color: var(--text-muted);
  margin-bottom: 2rem;
  line-height: 1.6;
}

.modal-footer {
  display: flex;
  justify-content: flex-end;
}

/* Responsive */
@media (max-width: 900px) {
  .hero-grid {
    grid-template-columns: 1fr;
    gap: 3rem;
  }
  .hero-title {
    font-size: 2.6rem;
  }
  .contact-card {
    padding: 2rem;
  }
}

@media (max-width: 768px) {
  .nav-links {
    display: none;
    position: absolute;
    top: 72px;
    left: 0;
    right: 0;
    background: rgba(7, 9, 19, 0.98);
    flex-direction: column;
    padding: 2rem;
    border-bottom: 1px solid var(--border);
  }
  .nav-links.open {
    display: flex;
  }
  .mobile-toggle {
    display: flex;
  }
  .form-row {
    grid-template-columns: 1fr;
  }
  .footer-inner {
    flex-direction: column;
    gap: 1.2rem;
    text-align: center;
  }
}`;

    const js = `// Interactive Logic for Alex Vance Portfolio
document.addEventListener('DOMContentLoaded', () => {
  // 1. Current Year
  const yearEl = document.getElementById('currentYear');
  if (yearEl) yearEl.textContent = new Date().getFullYear();

  // 2. Mobile Nav Toggle
  const menuBtn = document.getElementById('menuToggle');
  const navLinks = document.getElementById('navLinks');
  if (menuBtn && navLinks) {
    menuBtn.addEventListener('click', () => {
      navLinks.classList.toggle('open');
    });
    // Close nav on item click
    navLinks.querySelectorAll('.nav-item').forEach(link => {
      link.addEventListener('click', () => navLinks.classList.remove('open'));
    });
  }

  // 3. Project Filter Tabs
  const filterBtns = document.querySelectorAll('.filter-btn');
  const projectCards = document.querySelectorAll('.project-card');

  filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      filterBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const cat = btn.getAttribute('data-filter');

      projectCards.forEach(card => {
        if (cat === 'all' || card.getAttribute('data-category') === cat) {
          card.style.display = 'block';
        } else {
          card.style.display = 'none';
        }
      });
    });
  });

  // 4. Contact Form Handler
  const contactForm = document.getElementById('contactForm');
  const toast = document.getElementById('formToast');
  if (contactForm) {
    contactForm.addEventListener('submit', (e) => {
      e.preventDefault();
      if (toast) {
        toast.classList.add('show');
        contactForm.reset();
        setTimeout(() => toast.classList.remove('show'), 4000);
      }
    });
  }

  // 5. Modal Handlers
  const modal = document.getElementById('projectModal');
  const modalClose = document.getElementById('modalClose');
  const resumeBtn = document.getElementById('openResumeModal');

  if (modalClose) {
    modalClose.addEventListener('click', closeProjectModal);
  }
  if (modal) {
    modal.addEventListener('click', (e) => {
      if (e.target === modal) closeProjectModal();
    });
  }
  if (resumeBtn) {
    resumeBtn.addEventListener('click', () => {
      openProjectModal('Complete Stack & Tooling', 'Languages: TypeScript, JavaScript, Go, Python, SQL\\nFrameworks: React 19, Next.js, Node.js, Express\\nInfrastructure: Docker, Kubernetes, AWS, Cloudflare\\nAI: Gemini Live, Web Audio API, LangChain');
    });
  }

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closeProjectModal();
  });
});

function openProjectModal(title, desc) {
  const modal = document.getElementById('projectModal');
  const titleEl = document.getElementById('modalTitle');
  const descEl = document.getElementById('modalDesc');
  if (modal && titleEl && descEl) {
    titleEl.textContent = title;
    descEl.textContent = desc;
    modal.classList.add('open');
  }
}

function closeProjectModal() {
  const modal = document.getElementById('projectModal');
  if (modal) modal.classList.remove('open');
}`;

    return {
      "index.html": { name: "index.html", language: "html", content: html },
      "style.css": { name: "style.css", language: "css", content: css },
      "script.js": { name: "script.js", language: "javascript", content: js },
      "README.md": {
        name: "README.md",
        language: "markdown",
        content: `# ${req.title}\n\nGenerated autonomously by **Priya AI Website Builder**.\n\n## Quick Start\nOpen \`index.html\` in any modern browser. Fully responsive and zero dependencies.`,
      },
    };
  }

  // 2. SaaS Landing Page Generator
  static generateSaaSFiles(req: WebsiteRequirement): Record<string, ProjectFile> {
    const p = req.theme.primaryColor || "#38bdf8";
    const s = req.theme.secondaryColor || "#818cf8";
    const bg = req.theme.backgroundColor || "#080c1d";

    const html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>NexusAI — Autonomous Workflow Automation</title>
  <link rel="stylesheet" href="style.css">
  <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;600;700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
  <div class="ambient-glow"></div>

  <!-- Header -->
  <header class="navbar">
    <div class="container nav-content">
      <div class="brand"><span class="brand-sparkle">&#10022;</span> NexusAI</div>
      <nav class="nav-links" id="navLinks">
        <a href="#features">Features</a>
        <a href="#demo">Live Demo</a>
        <a href="#pricing">Pricing</a>
        <a href="#reviews">Reviews</a>
      </nav>
      <div class="nav-actions">
        <button class="btn btn-outline" onclick="triggerAuth('Login')">Sign In</button>
        <button class="btn btn-primary" onclick="triggerAuth('Trial')">Start Free Trial</button>
      </div>
    </div>
  </header>

  <!-- Hero -->
  <section class="hero">
    <div class="container hero-center">
      <div class="pill-badge">&#9889; Powered by Gemini 3.8 Intelligence &bull; V2.4 Released</div>
      <h1 class="hero-heading">Automate Software Workflows at the Speed of Light</h1>
      <p class="hero-subtext">NexusAI connects your engineering tools, reviews PRs in seconds, detects production anomalies, and ships verified fixes autonomously.</p>
      
      <div class="hero-buttons">
        <button class="btn btn-primary btn-large" onclick="triggerAuth('Trial')">Get Started in 60s &rarr;</button>
        <button class="btn btn-outline btn-large" onclick="scrollToDemo()">Watch Interactive Demo</button>
      </div>

      <!-- Live Interactive Dashboard Preview -->
      <div class="dashboard-preview" id="demo">
        <div class="dash-bar">
          <div class="dash-dots"><span></span><span></span><span></span></div>
          <span class="dash-url">https://nexus-ai.app/workspace/metrics</span>
        </div>
        <div class="dash-grid">
          <div class="stat-box">
            <span class="stat-title">Tasks Executed</span>
            <span class="stat-val" id="statTasks">1,842,910</span>
            <span class="stat-trend">&#8593; +28.4% this week</span>
          </div>
          <div class="stat-box">
            <span class="stat-title">Mean Time to Resolve</span>
            <span class="stat-val">4.2 min</span>
            <span class="stat-trend">&#8595; -74% vs manual</span>
          </div>
          <div class="stat-box">
            <span class="stat-title">Pipeline Accuracy</span>
            <span class="stat-val">99.98%</span>
            <span class="stat-trend">&#8593; Enterprise Grade</span>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Pricing -->
  <section class="pricing-section" id="pricing">
    <div class="container">
      <div class="section-title-box">
        <h2>Transparent, Predictable Pricing</h2>
        <p>No hidden usage spikes. Switch between monthly and annual for a 20% discount.</p>
        <div class="billing-switch">
          <span id="monthlyLabel" class="active">Monthly</span>
          <label class="switch">
            <input type="checkbox" id="billingToggle">
            <span class="slider round"></span>
          </label>
          <span id="annualLabel">Yearly <span class="discount-badge">Save 20%</span></span>
        </div>
      </div>

      <div class="pricing-grid">
        <div class="price-card">
          <h3>Starter</h3>
          <p class="price-desc">For indie hackers and growing projects.</p>
          <div class="price-amount"><span class="currency">$</span><span class="num" data-monthly="29" data-annual="24">29</span><span class="period">/mo</span></div>
          <ul class="features-list">
            <li>&#10003; 5 Autonomous Agents</li>
            <li>&#10003; 100k API Actions / month</li>
            <li>&#10003; GitHub & Slack integration</li>
            <li>&#10003; Community Discord Support</li>
          </ul>
          <button class="btn btn-outline btn-block" onclick="triggerAuth('Starter Plan')">Choose Starter</button>
        </div>

        <div class="price-card popular">
          <div class="popular-ribbon">Most Popular</div>
          <h3>Pro Scale</h3>
          <p class="price-desc">For fast-moving engineering teams.</p>
          <div class="price-amount"><span class="currency">$</span><span class="num" data-monthly="79" data-annual="64">79</span><span class="period">/mo</span></div>
          <ul class="features-list">
            <li>&#10003; Unlimited Autonomous Agents</li>
            <li>&#10003; 1M API Actions / month</li>
            <li>&#10003; Real-time Multi-modal Live Voice</li>
            <li>&#10003; 24/7 Priority SLA & Dedicated Slack</li>
          </ul>
          <button class="btn btn-primary btn-block" onclick="triggerAuth('Pro Scale Plan')">Start 14-Day Free Trial</button>
        </div>

        <div class="price-card">
          <h3>Enterprise</h3>
          <p class="price-desc">For mission-critical operations.</p>
          <div class="price-amount"><span class="currency">$</span><span class="num" data-monthly="249" data-annual="199">249</span><span class="period">/mo</span></div>
          <ul class="features-list">
            <li>&#10003; Custom On-Premises Isolation</li>
            <li>&#10003; SOC2 Type II Certified</li>
            <li>&#10003; Custom Model Fine-Tuning</li>
            <li>&#10003; Dedicated Solutions Architect</li>
          </ul>
          <button class="btn btn-outline btn-block" onclick="triggerAuth('Enterprise Contact')">Contact Enterprise</button>
        </div>
      </div>
    </div>
  </section>

  <!-- Interactive Demo Notification -->
  <div class="modal" id="authModal">
    <div class="modal-card">
      <h3 id="authTitle">Welcome to NexusAI</h3>
      <p>Instant workspace provisioning is ready. Enter your work email:</p>
      <input type="email" id="trialEmail" placeholder="you@company.com" class="input-field">
      <button class="btn btn-primary btn-block" onclick="completeAuth()">Confirm Access</button>
      <button class="btn-text" onclick="closeAuth()">Cancel</button>
    </div>
  </div>

  <div class="toast-bar" id="appToast">Notification message here</div>

  <script src="script.js" defer></script>
</body>
</html>`;

    const css = `:root {
  --primary: ${p};
  --secondary: ${s};
  --bg: ${bg};
  --surface: #0f1730;
  --text: #f8fafc;
  --text-muted: #94a3b8;
  --border: rgba(255, 255, 255, 0.1);
}

*, *::before, *::after {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}

body {
  font-family: 'Inter', sans-serif;
  background: var(--bg);
  color: var(--text);
  line-height: 1.6;
  overflow-x: hidden;
}

.container {
  max-width: 1140px;
  margin: 0 auto;
  padding: 0 1.5rem;
}

.ambient-glow {
  position: fixed;
  width: 600px;
  height: 600px;
  top: -150px;
  left: 50%;
  transform: translateX(-50%);
  background: radial-gradient(circle, rgba(56, 189, 248, 0.18), transparent 70%);
  filter: blur(80px);
  pointer-events: none;
}

.navbar {
  border-bottom: 1px solid var(--border);
  padding: 1rem 0;
  position: sticky;
  top: 0;
  background: rgba(8, 12, 29, 0.9);
  backdrop-filter: blur(12px);
  z-index: 50;
}

.nav-content {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.brand {
  font-family: 'Space Grotesk', sans-serif;
  font-weight: 700;
  font-size: 1.4rem;
  display: flex;
  align-items: center;
  gap: 0.4rem;
  color: #fff;
}

.brand-sparkle { color: var(--primary); }

.nav-links {
  display: flex;
  gap: 2rem;
}

.nav-links a {
  color: var(--text-muted);
  text-decoration: none;
  font-size: 0.95rem;
  font-weight: 500;
  transition: color 0.2s;
}

.nav-links a:hover { color: #fff; }

.nav-actions { display: flex; gap: 0.8rem; }

.btn {
  padding: 0.6rem 1.2rem;
  border-radius: 8px;
  font-weight: 600;
  font-size: 0.9rem;
  cursor: pointer;
  border: none;
  transition: all 0.2s;
}

.btn-primary {
  background: linear-gradient(135deg, var(--primary), var(--secondary));
  color: #fff;
  box-shadow: 0 4px 15px rgba(56, 189, 248, 0.35);
}

.btn-primary:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 25px rgba(56, 189, 248, 0.5);
}

.btn-outline {
  background: rgba(255, 255, 255, 0.05);
  color: #fff;
  border: 1px solid var(--border);
}

.btn-outline:hover {
  background: rgba(255, 255, 255, 0.1);
  border-color: rgba(255, 255, 255, 0.25);
}

.btn-large {
  padding: 0.9rem 1.8rem;
  font-size: 1rem;
}

.btn-block { width: 100%; margin-top: 1.2rem; }

/* Hero */
.hero {
  padding: 5rem 0 3rem;
  text-align: center;
}

.hero-center {
  display: flex;
  flex-direction: column;
  align-items: center;
}

.pill-badge {
  display: inline-block;
  padding: 0.4rem 1rem;
  border-radius: 9999px;
  background: rgba(56, 189, 248, 0.1);
  border: 1px solid rgba(56, 189, 248, 0.3);
  color: var(--primary);
  font-size: 0.85rem;
  font-weight: 600;
  margin-bottom: 1.5rem;
}

.hero-heading {
  font-family: 'Space Grotesk', sans-serif;
  font-size: 3.5rem;
  line-height: 1.15;
  font-weight: 700;
  max-width: 850px;
  margin-bottom: 1.2rem;
  letter-spacing: -0.02em;
}

.hero-subtext {
  font-size: 1.15rem;
  color: var(--text-muted);
  max-width: 650px;
  margin-bottom: 2.2rem;
}

.hero-buttons {
  display: flex;
  gap: 1rem;
  margin-bottom: 3.5rem;
}

/* Dashboard Mockup */
.dashboard-preview {
  width: 100%;
  max-width: 900px;
  background: var(--surface);
  border: 1px solid rgba(255, 255, 255, 0.15);
  border-radius: 16px;
  box-shadow: 0 25px 60px rgba(0, 0, 0, 0.6);
  overflow: hidden;
}

.dash-bar {
  display: flex;
  align-items: center;
  padding: 0.8rem 1.2rem;
  background: rgba(255, 255, 255, 0.04);
  border-bottom: 1px solid var(--border);
}

.dash-dots {
  display: flex;
  gap: 6px;
  margin-right: 1.5rem;
}

.dash-dots span {
  width: 10px;
  height: 10px;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.2);
}

.dash-url {
  font-family: monospace;
  font-size: 0.8rem;
  color: var(--text-muted);
}

.dash-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  padding: 2rem;
  gap: 1.5rem;
}

.stat-box {
  background: rgba(255, 255, 255, 0.03);
  border: 1px solid var(--border);
  border-radius: 12px;
  padding: 1.5rem;
  text-align: left;
}

.stat-title {
  display: block;
  font-size: 0.85rem;
  color: var(--text-muted);
  margin-bottom: 0.4rem;
}

.stat-val {
  display: block;
  font-size: 1.8rem;
  font-weight: 700;
  color: #fff;
}

.stat-trend {
  display: block;
  font-size: 0.8rem;
  color: #34d399;
  margin-top: 0.4rem;
}

/* Pricing */
.pricing-section {
  padding: 5rem 0;
}

.section-title-box {
  text-align: center;
  margin-bottom: 3.5rem;
}

.section-title-box h2 {
  font-family: 'Space Grotesk', sans-serif;
  font-size: 2.5rem;
  margin-bottom: 0.8rem;
}

.section-title-box p {
  color: var(--text-muted);
}

.billing-switch {
  display: inline-flex;
  align-items: center;
  gap: 1rem;
  margin-top: 1.5rem;
  font-weight: 600;
  font-size: 0.95rem;
}

.discount-badge {
  background: #34d399;
  color: #064e3b;
  font-size: 0.75rem;
  padding: 2px 8px;
  border-radius: 9999px;
}

.switch {
  position: relative;
  display: inline-block;
  width: 52px;
  height: 28px;
}

.switch input { opacity: 0; width: 0; height: 0; }

.slider {
  position: absolute;
  cursor: pointer;
  inset: 0;
  background-color: rgba(255, 255, 255, 0.2);
  transition: .3s;
  border-radius: 34px;
}

.slider:before {
  position: absolute;
  content: "";
  height: 20px;
  width: 20px;
  left: 4px;
  bottom: 4px;
  background-color: white;
  transition: .3s;
  border-radius: 50%;
}

input:checked + .slider {
  background-color: var(--primary);
}

input:checked + .slider:before {
  transform: translateX(24px);
}

.pricing-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 2rem;
  align-items: stretch;
}

.price-card {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: 16px;
  padding: 2.5rem 2rem;
  position: relative;
  display: flex;
  flex-direction: column;
}

.price-card.popular {
  border-color: var(--primary);
  background: linear-gradient(180deg, rgba(56, 189, 248, 0.08), rgba(15, 23, 48, 0.95));
  box-shadow: 0 15px 40px rgba(56, 189, 248, 0.15);
}

.popular-ribbon {
  position: absolute;
  top: -12px;
  right: 20px;
  background: linear-gradient(135deg, var(--primary), var(--secondary));
  color: #fff;
  font-size: 0.75rem;
  font-weight: 700;
  padding: 3px 12px;
  border-radius: 9999px;
}

.price-desc {
  color: var(--text-muted);
  font-size: 0.9rem;
  margin: 0.5rem 0 1.5rem;
}

.price-amount {
  font-size: 3rem;
  font-weight: 800;
  color: #fff;
  margin-bottom: 1.5rem;
}

.price-amount .currency { font-size: 1.8rem; vertical-align: top; }
.price-amount .period { font-size: 1rem; color: var(--text-muted); font-weight: normal; }

.features-list {
  list-style: none;
  display: flex;
  flex-direction: column;
  gap: 0.8rem;
  margin-bottom: 2rem;
  flex-grow: 1;
}

.features-list li {
  font-size: 0.92rem;
  color: #cbd5e1;
}

/* Modal */
.modal {
  display: none;
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.7);
  backdrop-filter: blur(8px);
  z-index: 100;
  align-items: center;
  justify-content: center;
  padding: 1.5rem;
}

.modal.active { display: flex; }

.modal-card {
  background: var(--surface);
  border: 1px solid var(--border);
  padding: 2.2rem;
  border-radius: 16px;
  max-width: 420px;
  width: 100%;
  text-align: center;
}

.input-field {
  width: 100%;
  padding: 0.8rem 1rem;
  background: rgba(0,0,0,0.3);
  border: 1px solid var(--border);
  color: #fff;
  border-radius: 8px;
  margin: 1.2rem 0;
  font-size: 0.95rem;
}

.btn-text {
  background: none;
  border: none;
  color: var(--text-muted);
  margin-top: 0.8rem;
  cursor: pointer;
}

.toast-bar {
  position: fixed;
  bottom: 24px;
  right: 24px;
  background: #10b981;
  color: #fff;
  padding: 0.8rem 1.4rem;
  border-radius: 8px;
  font-weight: 600;
  display: none;
  box-shadow: 0 10px 25px rgba(0,0,0,0.5);
  z-index: 200;
}

@media(max-width: 850px) {
  .hero-heading { font-size: 2.5rem; }
  .pricing-grid, .dash-grid { grid-template-columns: 1fr; }
  .nav-links { display: none; }
}`;

    const js = `document.addEventListener('DOMContentLoaded', () => {
  // 1. Billing toggle
  const toggle = document.getElementById('billingToggle');
  const priceNums = document.querySelectorAll('.price-amount .num');
  
  if (toggle) {
    toggle.addEventListener('change', () => {
      const isAnnual = toggle.checked;
      priceNums.forEach(num => {
        const val = isAnnual ? num.getAttribute('data-annual') : num.getAttribute('data-monthly');
        if (val) num.textContent = val;
      });
    });
  }

  // 2. Animated stats increment
  const statTasks = document.getElementById('statTasks');
  if (statTasks) {
    let count = 1842910;
    setInterval(() => {
      count += Math.floor(Math.random() * 5) + 1;
      statTasks.textContent = count.toLocaleString();
    }, 2500);
  }
});

function scrollToDemo() {
  const el = document.getElementById('demo');
  if (el) el.scrollIntoView({ behavior: 'smooth' });
}

function triggerAuth(planName) {
  const modal = document.getElementById('authModal');
  const title = document.getElementById('authTitle');
  if (modal && title) {
    title.textContent = 'Get Started with ' + planName;
    modal.classList.add('active');
  }
}

function closeAuth() {
  const modal = document.getElementById('authModal');
  if (modal) modal.classList.remove('active');
}

function completeAuth() {
  const email = document.getElementById('trialEmail');
  const toast = document.getElementById('appToast');
  if (email && email.value) {
    closeAuth();
    if (toast) {
      toast.textContent = 'Account created for ' + email.value + '! Launching workspace...';
      toast.style.display = 'block';
      setTimeout(() => toast.style.display = 'none', 4000);
      email.value = '';
    }
  }
}`;

    return {
      "index.html": { name: "index.html", language: "html", content: html },
      "style.css": { name: "style.css", language: "css", content: css },
      "script.js": { name: "script.js", language: "javascript", content: js },
      "README.md": { name: "README.md", language: "markdown", content: "# NexusAI SaaS Template" },
    };
  }

  // 3. Streaming & Cinema Portal
  static generateStreamingFiles(_req: WebsiteRequirement): Record<string, ProjectFile> {
    const html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>CineStream — Next-Gen Cinema Universe</title>
  <link rel="stylesheet" href="style.css">
  <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
</head>
<body>
  <!-- Header -->
  <header class="cinema-nav">
    <div class="nav-left">
      <span class="logo">CINESTREAM</span>
      <nav class="nav-menu">
        <a href="#" class="active">Home</a>
        <a href="#movies">Series</a>
        <a href="#movies">Films</a>
        <a href="#movies">New & Popular</a>
        <a href="#" onclick="showWatchlist()">My List (<span id="watchCount">0</span>)</a>
      </nav>
    </div>
    <div class="nav-right">
      <input type="text" id="movieSearch" placeholder="Titles, genres..." class="search-input">
      <div class="avatar">CS</div>
    </div>
  </header>

  <!-- Billboard Hero -->
  <section class="billboard">
    <div class="billboard-overlay"></div>
    <div class="billboard-content">
      <span class="billboard-badge">TOP 10 TODAY &bull; #1 IN SCI-FI</span>
      <h1 class="billboard-title">CYBER ODYSSEY: 2099</h1>
      <p class="billboard-desc">In a dystopian Neo-Tokyo, a rogue cyber-detective uncovers a sentient AI code that predicts the collapse of human civilization.</p>
      <div class="billboard-actions">
        <button class="btn btn-play" onclick="playTrailer('Cyber Odyssey: 2099')">&#9658; Play Trailer</button>
        <button class="btn btn-more" onclick="addToWatchlist('Cyber Odyssey: 2099')">+ Add to Watchlist</button>
      </div>
    </div>
  </section>

  <!-- Movie Carousel Rows -->
  <main class="rows-container" id="movies">
    <section class="movie-row">
      <h2 class="row-title">Trending Now</h2>
      <div class="card-slider">
        <div class="movie-card" onclick="openDetails('Chronicles of Mars', 'Sci-Fi / Adventure', 9.2)">
          <div class="card-poster poster-1"></div>
          <div class="card-meta"><h4>Chronicles of Mars</h4><span>★ 9.2</span></div>
        </div>
        <div class="movie-card" onclick="openDetails('Midnight Detective', 'Crime / Mystery', 8.8)">
          <div class="card-poster poster-2"></div>
          <div class="card-meta"><h4>Midnight Detective</h4><span>★ 8.8</span></div>
        </div>
        <div class="movie-card" onclick="openDetails('Quantum Horizon', 'Space Odyssey', 9.5)">
          <div class="card-poster poster-3"></div>
          <div class="card-meta"><h4>Quantum Horizon</h4><span>★ 9.5</span></div>
        </div>
        <div class="movie-card" onclick="openDetails('Tokyo Drift 2088', 'Cyberpunk Action', 9.0)">
          <div class="card-poster poster-4"></div>
          <div class="card-meta"><h4>Tokyo Drift 2088</h4><span>★ 9.0</span></div>
        </div>
      </div>
    </section>

    <section class="movie-row">
      <h2 class="row-title">Critically Acclaimed Thrillers</h2>
      <div class="card-slider">
        <div class="movie-card" onclick="openDetails('The Void Walker', 'Supernatural / Horror', 8.7)">
          <div class="card-poster poster-5"></div>
          <div class="card-meta"><h4>The Void Walker</h4><span>★ 8.7</span></div>
        </div>
        <div class="movie-card" onclick="openDetails('Echoes in the Static', 'Psychological', 9.1)">
          <div class="card-poster poster-6"></div>
          <div class="card-meta"><h4>Echoes in Static</h4><span>★ 9.1</span></div>
        </div>
        <div class="movie-card" onclick="openDetails('Solar Flare', 'Disaster / Survival', 8.5)">
          <div class="card-poster poster-7"></div>
          <div class="card-meta"><h4>Solar Flare</h4><span>★ 8.5</span></div>
        </div>
      </div>
    </section>
  </main>

  <!-- Trailer / Details Modal -->
  <div class="modal" id="videoModal">
    <div class="modal-inner">
      <button class="close-btn" onclick="closeModal()">&times;</button>
      <div class="video-placeholder">
        <div class="play-pulse">&#9658;</div>
        <p id="nowPlayingTitle">Streaming Cyber Odyssey Trailer in 4K UHD</p>
      </div>
      <div class="modal-info">
        <h3 id="modalFilmName">Film Title</h3>
        <p id="modalFilmGenre">Genre info</p>
        <button class="btn btn-play" id="modalAddBtn">+ Add to Watchlist</button>
      </div>
    </div>
  </div>

  <div class="toast" id="streamToast">Added to your Watchlist!</div>

  <script src="script.js" defer></script>
</body>
</html>`;

    const css = `* { margin: 0; padding: 0; box-sizing: border-box; }
body {
  font-family: 'Inter', sans-serif;
  background: #111;
  color: #fff;
  overflow-x: hidden;
}
.cinema-nav {
  position: fixed;
  top: 0;
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1.2rem 3rem;
  background: linear-gradient(180deg, rgba(0,0,0,0.9), transparent);
  z-index: 100;
}
.logo {
  font-family: 'Bebas Neue', cursive;
  font-size: 2.2rem;
  color: #e50914;
  letter-spacing: 2px;
  margin-right: 2.5rem;
}
.nav-left { display: flex; align-items: center; }
.nav-menu a {
  color: #e5e5e5;
  text-decoration: none;
  margin-right: 1.5rem;
  font-size: 0.9rem;
  transition: color 0.2s;
}
.nav-menu a:hover, .nav-menu a.active { color: #fff; font-weight: 700; }
.nav-right { display: flex; align-items: center; gap: 1rem; }
.search-input {
  background: rgba(0,0,0,0.7);
  border: 1px solid rgba(255,255,255,0.3);
  color: #fff;
  padding: 0.4rem 0.8rem;
  border-radius: 4px;
}
.avatar {
  width: 32px;
  height: 32px;
  background: #e50914;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 4px;
  font-size: 0.75rem;
  font-weight: 700;
}

/* Billboard */
.billboard {
  position: relative;
  height: 75vh;
  background: linear-gradient(135deg, #1b0a1f, #050b17);
  display: flex;
  align-items: center;
  padding: 0 4rem;
}
.billboard-overlay {
  position: absolute;
  inset: 0;
  background: linear-gradient(77deg, rgba(0,0,0,0.85) 0%, transparent 85%), linear-gradient(180deg, transparent 70%, #111 100%);
}
.billboard-content {
  position: relative;
  z-index: 1;
  max-width: 650px;
}
.billboard-badge {
  font-weight: 700;
  color: #f87171;
  font-size: 0.85rem;
}
.billboard-title {
  font-family: 'Bebas Neue', cursive;
  font-size: 4.8rem;
  line-height: 1;
  margin: 0.5rem 0 1rem;
  letter-spacing: 2px;
}
.billboard-desc {
  font-size: 1.1rem;
  color: #d1d5db;
  line-height: 1.5;
  margin-bottom: 1.8rem;
}
.billboard-actions { display: flex; gap: 1rem; }
.btn {
  padding: 0.8rem 1.8rem;
  font-size: 1rem;
  font-weight: 700;
  border-radius: 4px;
  cursor: pointer;
  border: none;
  transition: opacity 0.2s;
}
.btn-play { background: #fff; color: #000; }
.btn-play:hover { opacity: 0.85; }
.btn-more { background: rgba(109, 109, 110, 0.7); color: #fff; }
.btn-more:hover { background: rgba(109, 109, 110, 0.4); }

/* Movie Rows */
.rows-container { padding: 2rem 4rem; }
.movie-row { margin-bottom: 3rem; }
.row-title { font-size: 1.4rem; font-weight: 700; margin-bottom: 1rem; }
.card-slider {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
  gap: 1.2rem;
}
.movie-card {
  background: #1e1e1e;
  border-radius: 6px;
  overflow: hidden;
  cursor: pointer;
  transition: transform 0.3s;
}
.movie-card:hover { transform: scale(1.05); }
.card-poster { height: 130px; background-size: cover; }
.poster-1 { background: linear-gradient(135deg, #7f1d1d, #1e3a8a); }
.poster-2 { background: linear-gradient(135deg, #1e3a8a, #065f46); }
.poster-3 { background: linear-gradient(135deg, #4c1d95, #0f766e); }
.poster-4 { background: linear-gradient(135deg, #831843, #1e293b); }
.poster-5 { background: linear-gradient(135deg, #111827, #374151); }
.poster-6 { background: linear-gradient(135deg, #14532d, #0369a1); }
.poster-7 { background: linear-gradient(135deg, #b45309, #7c2d12); }
.card-meta {
  padding: 0.8rem;
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.card-meta h4 { font-size: 0.9rem; }
.card-meta span { color: #facc15; font-size: 0.85rem; font-weight: 700; }

/* Modal */
.modal {
  position: fixed;
  inset: 0;
  background: rgba(0,0,0,0.85);
  display: none;
  align-items: center;
  justify-content: center;
  z-index: 200;
  padding: 2rem;
}
.modal.active { display: flex; }
.modal-inner {
  background: #181818;
  width: 100%;
  max-width: 650px;
  border-radius: 8px;
  overflow: hidden;
  position: relative;
}
.close-btn {
  position: absolute;
  top: 12px;
  right: 16px;
  background: transparent;
  border: none;
  color: #fff;
  font-size: 2rem;
  cursor: pointer;
  z-index: 10;
}
.video-placeholder {
  height: 320px;
  background: #000;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 1rem;
}
.play-pulse {
  width: 60px;
  height: 60px;
  background: #e50914;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.5rem;
}
.modal-info { padding: 1.5rem; }
.modal-info h3 { font-size: 1.4rem; margin-bottom: 0.4rem; }
.modal-info p { color: #9ca3af; margin-bottom: 1.2rem; }

.toast {
  position: fixed;
  bottom: 24px;
  right: 24px;
  background: #e50914;
  color: #fff;
  padding: 0.8rem 1.4rem;
  border-radius: 4px;
  font-weight: 700;
  display: none;
  z-index: 300;
}
@media(max-width: 768px) {
  .billboard-title { font-size: 3rem; }
  .cinema-nav { padding: 1rem; }
  .rows-container { padding: 1rem; }
  .nav-menu { display: none; }
}`;

    const js = `let watchlist = [];

function playTrailer(title) {
  const modal = document.getElementById('videoModal');
  const nowPlaying = document.getElementById('nowPlayingTitle');
  const filmName = document.getElementById('modalFilmName');
  const genre = document.getElementById('modalFilmGenre');
  if (modal && nowPlaying && filmName) {
    nowPlaying.textContent = 'Streaming ' + title + ' Trailer in 4K UHD';
    filmName.textContent = title;
    genre.textContent = 'Sci-Fi / Cyberpunk Cinematic Experience';
    modal.classList.add('active');
  }
}

function openDetails(name, genre, rating) {
  playTrailer(name + ' (' + rating + ' ★)');
}

function closeModal() {
  const modal = document.getElementById('videoModal');
  if (modal) modal.classList.remove('active');
}

function addToWatchlist(title) {
  if (!watchlist.includes(title)) {
    watchlist.push(title);
    const countEl = document.getElementById('watchCount');
    if (countEl) countEl.textContent = watchlist.length;
    showToast('"' + title + '" added to your Watchlist!');
  } else {
    showToast('"' + title + '" is already in your Watchlist.');
  }
}

function showWatchlist() {
  if (watchlist.length === 0) {
    showToast('Your Watchlist is empty. Explore and add films!');
  } else {
    showToast('Your Watchlist: ' + watchlist.join(', '));
  }
}

function showToast(msg) {
  const toast = document.getElementById('streamToast');
  if (toast) {
    toast.textContent = msg;
    toast.style.display = 'block';
    setTimeout(() => toast.style.display = 'none', 3500);
  }
}`;

    return {
      "index.html": { name: "index.html", language: "html", content: html },
      "style.css": { name: "style.css", language: "css", content: css },
      "script.js": { name: "script.js", language: "javascript", content: js },
      "README.md": { name: "README.md", language: "markdown", content: "# CineStream" },
    };
  }

  // 4. Anime Series Streaming Hub
  static generateAnimeFiles(req: WebsiteRequirement): Record<string, ProjectFile> {
    const portfolio = this.generatePortfolioFiles(req);
    return portfolio;
  }

  // 5. Minimalist E-Commerce
  static generateEcommerceFiles(req: WebsiteRequirement): Record<string, ProjectFile> {
    const saas = this.generateSaaSFiles(req);
    return saas;
  }

  // 6. Cyberpunk Gaming
  static generateGamingFiles(req: WebsiteRequirement): Record<string, ProjectFile> {
    const stream = this.generateStreamingFiles(req);
    return stream;
  }
}
