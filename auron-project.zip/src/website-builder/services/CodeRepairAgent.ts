import type { CodeValidationError, ProjectFile } from "../types/website";

export class CodeRepairAgent {
  /**
   * Automatically repairs detected code issues in project files.
   * Modifies files in-place and returns the fixed file map and repaired log messages.
   */
  static repair(
    files: Record<string, ProjectFile>,
    errors: CodeValidationError[]
  ): {
    repairedFiles: Record<string, ProjectFile>;
    fixedCount: number;
    actionsTaken: string[];
  } {
    const cloned: Record<string, ProjectFile> = {};
    for (const [key, file] of Object.entries(files)) {
      cloned[key] = { ...file };
    }

    const actionsTaken: string[] = [];
    let fixedCount = 0;

    for (const err of errors) {
      if (!err.autoFixable) continue;

      if (err.file === "index.html" && cloned["index.html"]) {
        let html = cloned["index.html"].content;

        // 1. Fix DOCTYPE
        if (err.message.includes("<!DOCTYPE html>")) {
          if (!html.toLowerCase().includes("<!doctype html>")) {
            html = "<!DOCTYPE html>\n" + html;
            actionsTaken.push("Added standard <!DOCTYPE html> declaration");
            fixedCount++;
          }
        }

        // 2. Fix viewport meta
        if (err.message.includes("viewport")) {
          if (!html.includes('name="viewport"')) {
            const headIdx = html.indexOf("<head>");
            if (headIdx !== -1) {
              const metaTag =
                '\n  <meta name="viewport" content="width=device-width, initial-scale=1.0">';
              html = html.slice(0, headIdx + 6) + metaTag + html.slice(headIdx + 6);
              actionsTaken.push("Injected mobile-responsive viewport meta tag");
              fixedCount++;
            }
          }
        }

        // 3. Link style.css
        if (err.message.includes("style.css exists") && cloned["style.css"]) {
          if (!html.includes("style.css")) {
            const headClose = html.indexOf("</head>");
            const linkTag = '  <link rel="stylesheet" href="style.css">\n';
            if (headClose !== -1) {
              html = html.slice(0, headClose) + linkTag + html.slice(headClose);
            } else {
              html = linkTag + html;
            }
            actionsTaken.push("Linked style.css in <head>");
            fixedCount++;
          }
        }

        // 4. Link script.js
        if (err.message.includes("script.js exists") && cloned["script.js"]) {
          if (!html.includes("script.js")) {
            const bodyClose = html.indexOf("</body>");
            const scriptTag = '  <script src="script.js" defer></script>\n';
            if (bodyClose !== -1) {
              html = html.slice(0, bodyClose) + scriptTag + html.slice(bodyClose);
            } else {
              html = html + "\n" + scriptTag;
            }
            actionsTaken.push("Linked script.js before </body>");
            fixedCount++;
          }
        }

        cloned["index.html"].content = html;
      }

      if (err.file === "style.css" && cloned["style.css"]) {
        let css = cloned["style.css"].content;

        // Balance unclosed braces
        if (err.message.includes("Unbalanced CSS braces")) {
          const open = (css.match(/\{/g) || []).length;
          const close = (css.match(/\}/g) || []).length;
          if (open > close) {
            css += "\n" + "}".repeat(open - close);
            actionsTaken.push(`Closed ${open - close} unclosed CSS rule blocks`);
            fixedCount++;
          }
        }

        // Box sizing reset
        if (err.message.includes("universal box-sizing")) {
          const reset = "*, *::before, *::after {\n  box-sizing: border-box;\n}\n\n";
          css = reset + css;
          actionsTaken.push("Added standard CSS box-sizing reset");
          fixedCount++;
        }

        cloned["style.css"].content = css;
      }

      if (err.file === "script.js" && cloned["script.js"]) {
        let js = cloned["script.js"].content;

        // Safe DOMContentLoaded wrapper
        if (err.message.includes("DOMContentLoaded guard")) {
          if (!js.includes("DOMContentLoaded")) {
            js = `// Initialized safely by Priya AI Website Builder\ndocument.addEventListener('DOMContentLoaded', () => {\n${js}\n});`;
            actionsTaken.push("Wrapped scripts inside DOMContentLoaded event listener");
            fixedCount++;
          }
        }

        cloned["script.js"].content = js;
      }
    }

    return {
      repairedFiles: cloned,
      fixedCount,
      actionsTaken,
    };
  }
}
