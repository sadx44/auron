import type { WebsiteRequirement } from "../types/website";

export class WebsiteRequirementAnalyzer {
  /**
   * Analyzes raw user voice or text input and extracts rich, structured requirements.
   * If details are missing, infers sensible, high-converting aesthetic defaults.
   */
  static analyze(prompt: string): WebsiteRequirement {
    const p = prompt.trim();
    const lower = p.toLowerCase();

    // 1. Detect Website Type
    let websiteType = "Landing Page";
    let title = "Modern Digital Experience";
    let purpose = "Present services, convert visitors, and deliver a polished digital presence.";
    let targetAudience = "Tech enthusiasts, potential clients, and modern digital consumers.";

    if (lower.includes("portfolio") || lower.includes("developer") || lower.includes("designer") || lower.includes("resume")) {
      websiteType = "Developer / Creator Portfolio";
      title = "Alex Vance — Full Stack Engineer & Creative Developer";
      purpose = "Showcase premium projects, technical skills, open-source work, and client testimonials.";
      targetAudience = "Recruiters, engineering leads, founders, and creative directors.";
    } else if (lower.includes("netflix") || lower.includes("movie") || lower.includes("cinema") || lower.includes("stream")) {
      websiteType = "Streaming & Cinema Portal";
      title = "CineStream — Next-Gen Cinematic Universe";
      purpose = "Deliver immersive movie browsing, trailers, category filtering, and watchlists.";
      targetAudience = "Movie lovers, binge-watchers, and entertainment enthusiasts.";
    } else if (lower.includes("anime") || lower.includes("manga")) {
      websiteType = "Anime Hub & Streaming Hub";
      title = "AnimeVerse — Stream Legendary Series in Ultra HD";
      purpose = "Browse trending anime, episode tracker, character spotlights, and community reviews.";
      targetAudience = "Anime fans, otaku culture lovers, and international viewers.";
    } else if (lower.includes("saas") || lower.includes("ai tool") || lower.includes("software") || lower.includes("startup")) {
      websiteType = "SaaS Product Landing Page";
      title = "NexusAI — Intelligent Autonomous Workflow Engine";
      purpose = "Convert visitors into trial users with interactive demos, feature metrics, and tiered pricing.";
      targetAudience = "CTOs, startup founders, product managers, and developers.";
    } else if (lower.includes("ecommerce") || lower.includes("store") || lower.includes("shop") || lower.includes("fashion") || lower.includes("product")) {
      websiteType = "E-Commerce Boutique";
      title = "AURA — Premium Minimalist Lifestyle Goods";
      purpose = "Showcase curated products with responsive cart, live filters, and quick checkout flow.";
      targetAudience = "Discerning shoppers seeking premium craftsmanship and minimalist design.";
    } else if (lower.includes("restaurant") || lower.includes("cafe") || lower.includes("food") || lower.includes("dining")) {
      websiteType = "Artisan Culinary & Dining";
      title = "L'Osteria Nocturne — Modern Culinary Experience";
      purpose = "Display seasonal menu, chef tasting stories, table reservation form, and location.";
      targetAudience = "Food connoisseurs, date night diners, and local culinary explorers.";
    } else if (lower.includes("game") || lower.includes("gaming") || lower.includes("esport")) {
      websiteType = "Gaming Studio & Title Portal";
      title = "CYBERPUNK 2088 — The Neon Rebellion";
      purpose = "Promote gameplay reveal, character lore, interactive sound effects, and preorder countdown.";
      targetAudience = "Hardcore gamers, streamers, and sci-fi fans.";
    }

    // 2. Detect Color Theme & Visual Direction
    let mode: "dark" | "light" | "cyberpunk" | "minimal" | "glassmorphism" | "neon" = "dark";
    let primary = "#22d3ee";
    let secondary = "#a855f7";
    let bg = "#070913";
    let text = "#f8fafc";
    let accent = "#38bdf8";

    if (lower.includes("neon") || lower.includes("cyberpunk") || lower.includes("synthwave")) {
      mode = "neon";
      primary = "#00f0ff";
      secondary = "#ff007f";
      bg = "#05050c";
      text = "#ffffff";
      accent = "#ffe600";
    } else if (lower.includes("glass") || lower.includes("glassmorphism")) {
      mode = "glassmorphism";
      primary = "#38bdf8";
      secondary = "#818cf8";
      bg = "#0b1021";
      text = "#f1f5f9";
      accent = "#60a5fa";
    } else if (lower.includes("light") || lower.includes("white") || lower.includes("clean")) {
      mode = "light";
      primary = "#2563eb";
      secondary = "#7c3aed";
      bg = "#f8fafc";
      text = "#0f172a";
      accent = "#0284c7";
    } else if (lower.includes("minimal")) {
      mode = "minimal";
      primary = "#e2e8f0";
      secondary = "#94a3b8";
      bg = "#09090b";
      text = "#fafafa";
      accent = "#71717a";
    } else if (lower.includes("anime")) {
      mode = "glassmorphism";
      primary = "#ec4899";
      secondary = "#8b5cf6";
      bg = "#0a0a1a";
      text = "#ffffff";
      accent = "#f43f5e";
    } else if (lower.includes("netflix") || lower.includes("movie")) {
      mode = "dark";
      primary = "#e50914";
      secondary = "#b81d24";
      bg = "#111111";
      text = "#ffffff";
      accent = "#ff4d5a";
    }

    // 3. Determine Required Sections
    const sections: string[] = [
      "Navigation Bar (Brand, Links, CTA, Mobile Menu)",
      "Hero Section (Headline, Subhead, Primary Action, Live Visual Card)",
    ];

    if (websiteType.includes("Portfolio")) {
      sections.push(
        "Featured Projects Showcase (Filterable grid with live demo links)",
        "Technical Skills & Tooling Matrix (Animated badges)",
        "Experience & Timeline Roadmap",
        "Interactive Testimonials Carousel",
        "Direct Contact Form & Social Links"
      );
    } else if (websiteType.includes("Streaming") || websiteType.includes("Anime")) {
      sections.push(
        "Trending Billboard Banner with Trailer Modal trigger",
        "Category Rows (Action, Sci-Fi, Award Winners, New Releases)",
        "Interactive Watchlist & Rating Badge",
        "Top 10 Spotlight Carousel",
        "Subscription Tier Plans",
        "FAQ Accordion"
      );
    } else if (websiteType.includes("SaaS")) {
      sections.push(
        "Social Proof (Trusted by 50,000+ teams)",
        "Core Capabilities Grid (Bento Box style)",
        "Interactive Interactive Live Demo Widget",
        "Tiered Pricing Plans (Monthly/Yearly toggle)",
        "Customer Wall of Love",
        "High-Converting Pre-Footer CTA"
      );
    } else if (websiteType.includes("E-Commerce")) {
      sections.push(
        "Seasonal Collection Hero",
        "Product Catalog with Quick-View & Add-to-Cart drawer",
        "Category Filters (All, Apparel, Accessories, Tech)",
        "Customer Reviews & Quality Guarantee Badges",
        "Newsletter Discount Form"
      );
    } else {
      sections.push(
        "Core Value Proposition Grid",
        "Feature Deep Dive with Interactive Tabs",
        "Statistics & Performance Metrics Bar",
        "Client Testimonials & Trust Badges",
        "FAQ Section",
        "Interactive Newsletter Signup"
      );
    }

    sections.push("Comprehensive Footer (Copyright, Site map, Social icons, Back-to-top)");

    // 4. Interactive Features
    const interactiveFeatures = [
      "Mobile Responsive Hamburger Navigation with smooth toggle",
      "Dynamic Filter Tabs with zero-page reload",
      "Interactive Modal dialog with keyboard ESC and backdrop close",
      "Notification Toast on action (e.g. Added to Cart / Message Sent)",
      "Lightweight smooth scroll to sections",
    ];

    if (websiteType.includes("SaaS")) {
      interactiveFeatures.push("Annual / Monthly billing price recalculator toggle");
    }
    if (websiteType.includes("Streaming") || websiteType.includes("Anime")) {
      interactiveFeatures.push("Interactive video trailer modal preview with sound simulation");
      interactiveFeatures.push("Dynamic Bookmark/Watchlist counter increment");
    }
    if (websiteType.includes("E-Commerce")) {
      interactiveFeatures.push("Slide-over Shopping Cart drawer with live badge count & total sum");
    }

    return {
      title,
      websiteType,
      purpose,
      targetAudience,
      sections,
      theme: {
        mode,
        primaryColor: primary,
        secondaryColor: secondary,
        backgroundColor: bg,
        textColor: text,
        accentColor: accent,
      },
      typography: "'Inter', -apple-system, BlinkMacSystemFont, sans-serif",
      animations: true,
      interactiveFeatures,
      responsiveRequirements: "100% fluid responsive from 320px mobile to 4K ultra-wide, no horizontal overflow, touch-friendly tap targets (>44px)",
    };
  }
}
