import type { AIModelCandidate } from "../types/website";

/**
 * ModelSelector
 * Automatically detects available AI coding models and selects the best candidate
 * based on coding benchmarks, HTML/CSS/JS syntax fidelity, speed, context window, and reliability.
 */
export const AVAILABLE_CODING_MODELS: AIModelCandidate[] = [
  {
    id: "gemini-2.5-pro",
    name: "Gemini 2.5 Pro (Coding Specialist)",
    provider: "Google Gemini",
    codingScore: 98,
    speed: "Balanced",
    contextWindow: "1M tokens",
    recommendedFor: "Complex web applications, interactive JavaScript, comprehensive responsive layouts",
    isAvailable: true,
    isDefault: true,
  },
  {
    id: "gemini-2.5-flash",
    name: "Gemini 2.5 Flash (Ultra-Fast)",
    provider: "Google Gemini",
    codingScore: 94,
    speed: "Maximum",
    contextWindow: "1M tokens",
    recommendedFor: "Rapid prototyping, landing pages, lightning-fast generation",
    isAvailable: true,
  },
  {
    id: "gemini-3.8-flash-live-preview",
    name: "Gemini 3.8 Flash Live",
    provider: "Google Gemini",
    codingScore: 96,
    speed: "Maximum",
    contextWindow: "1M tokens",
    recommendedFor: "Voice-driven real-time updates and quick iterative website edits",
    isAvailable: true,
  },
  {
    id: "gemini-3.1-flash-live-preview",
    name: "Gemini 3.1 Flash Live",
    provider: "Google Gemini",
    codingScore: 93,
    speed: "Fast",
    contextWindow: "128k tokens",
    recommendedFor: "Standard website generation & component styling",
    isAvailable: true,
  },
  {
    id: "claude-3-7-sonnet",
    name: "Claude 3.7 Sonnet (Hybrid Thinking)",
    provider: "Anthropic",
    codingScore: 99,
    speed: "Balanced",
    contextWindow: "200k tokens",
    recommendedFor: "Architectural frontend engineering & CSS art",
    isAvailable: false,
  },
  {
    id: "gpt-4o",
    name: "GPT-4o Web Edition",
    provider: "OpenAI",
    codingScore: 95,
    speed: "Fast",
    contextWindow: "128k tokens",
    recommendedFor: "General web coding and UI polish",
    isAvailable: false,
  },
];

export class ModelSelector {
  /**
   * Selects the best coding model based on requirements and project complexity
   */
  static selectBestModel(prompt: string, preferredModelId?: string): AIModelCandidate {
    // 1. If explicit preferred model is requested and available, use it
    if (preferredModelId) {
      const match = AVAILABLE_CODING_MODELS.find(
        (m) => m.id === preferredModelId && m.isAvailable
      );
      if (match) return match;
    }

    // 2. Filter only currently available models
    const available = AVAILABLE_CODING_MODELS.filter((m) => m.isAvailable);
    if (available.length === 0) {
      return AVAILABLE_CODING_MODELS[0];
    }

    // 3. Evaluate complexity of request
    const lower = prompt.toLowerCase();
    const isComplex =
      lower.includes("ecommerce") ||
      lower.includes("e-commerce") ||
      lower.includes("dashboard") ||
      lower.includes("calculator") ||
      lower.includes("game") ||
      lower.includes("interactive") ||
      lower.includes("database") ||
      lower.includes("cart") ||
      lower.includes("auth") ||
      lower.includes("filter");

    if (isComplex) {
      // Pick highest coding score
      const sorted = [...available].sort((a, b) => b.codingScore - a.codingScore);
      return sorted[0];
    }

    // For standard / landing page, pick fast high-fidelity model
    const flash = available.find((m) => m.id === "gemini-2.5-flash");
    if (flash) return flash;

    return available[0];
  }

  static getAvailableModels(): AIModelCandidate[] {
    return AVAILABLE_CODING_MODELS;
  }
}
