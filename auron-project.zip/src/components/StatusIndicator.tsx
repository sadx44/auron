import type { AssistantState } from "../types/assistant";
import { STATUS_COPY } from "../config/constants";
import { cn } from "../utils/cn";

interface Props {
  state: AssistantState;
  labelOverride?: { title: string; sub: string };
}

export default function StatusIndicator({ state, labelOverride }: Props) {
  const copy = labelOverride ?? STATUS_COPY[state];
  const dot =
    state === "listening"
      ? "bg-emerald-400 shadow-[0_0_12px_rgba(52,211,153,0.9)]"
      : state === "speaking"
        ? "bg-fuchsia-400 shadow-[0_0_12px_rgba(232,121,249,0.9)] animate-pulse"
        : state === "thinking"
          ? "bg-violet-400 shadow-[0_0_12px_rgba(167,139,250,0.9)] animate-pulse"
          : state === "connecting"
            ? "bg-amber-400 shadow-[0_0_12px_rgba(251,191,36,0.9)] animate-ping"
            : state === "error"
              ? "bg-rose-500 shadow-[0_0_12px_rgba(244,63,94,0.9)]"
              : "bg-slate-500 shadow-[0_0_8px_rgba(100,116,139,0.6)]";

  return (
    <div className="flex flex-col items-center gap-1.5 text-center">
      <div className="flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.06] px-4 py-1.5 backdrop-blur-xl">
        <span className={cn("h-2 w-2 rounded-full", dot)} aria-hidden="true" />
        <span className="text-sm font-semibold tracking-wide text-white">{copy.title}</span>
      </div>
      <p className="text-xs text-slate-400">{copy.sub}</p>
    </div>
  );
}
