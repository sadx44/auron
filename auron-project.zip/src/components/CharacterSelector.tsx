import { Mars, Venus } from "lucide-react";
import type { Character } from "../types/assistant";
import { CHARACTER_META } from "../config/characterVideos";
import { cn } from "../utils/cn";

interface Props {
  value: Character;
  onChange: (c: Character) => void;
  disabled?: boolean;
}

const ORDER: Character[] = ["mark", "priya"];

export default function CharacterSelector({ value, onChange, disabled }: Props) {
  return (
    <div role="radiogroup" aria-label="Choose assistant character" className="grid grid-cols-2 gap-2.5">
      {ORDER.map((c) => {
        const meta = CHARACTER_META[c];
        const active = value === c;
        const isMark = c === "mark";
        return (
          <button
            key={c}
            role="radio"
            aria-checked={active}
            disabled={disabled}
            onClick={() => onChange(c)}
            className={cn(
              "group relative overflow-hidden rounded-2xl border p-2.5 text-left transition-all duration-200 active:scale-[0.98]",
              active
                ? isMark
                  ? "border-cyan-300/60 bg-cyan-400/[0.14] shadow-[0_0_28px_rgba(34,211,238,0.3)] ring-1 ring-cyan-300/40"
                  : "border-fuchsia-300/60 bg-fuchsia-400/[0.14] shadow-[0_0_28px_rgba(232,121,249,0.3)] ring-1 ring-fuchsia-300/40"
                : "border-white/10 bg-black/40 hover:border-white/25 hover:bg-white/[0.05]",
              disabled && "cursor-not-allowed opacity-60"
            )}
          >
            {/* Top row: character portrait thumbnail + gender icon */}
            <div className="mb-2 flex items-center justify-between">
              <div
                className={cn(
                  "relative h-12 w-12 overflow-hidden rounded-xl border shadow-md transition-transform duration-200 group-hover:scale-105",
                  active
                    ? isMark
                      ? "border-cyan-300/80 ring-2 ring-cyan-400/40"
                      : "border-fuchsia-300/80 ring-2 ring-fuchsia-400/40"
                    : "border-white/15"
                )}
              >
                <img
                  src={meta.image}
                  alt={meta.name}
                  className="h-full w-full object-cover object-top"
                  loading="lazy"
                />
              </div>
              <span
                className={cn(
                  "flex h-7 w-7 items-center justify-center rounded-full border transition-colors",
                  active
                    ? isMark
                      ? "border-cyan-300/60 bg-cyan-400/30 text-cyan-100 shadow-[0_0_12px_rgba(34,211,238,0.4)]"
                      : "border-fuchsia-300/60 bg-fuchsia-400/30 text-fuchsia-100 shadow-[0_0_12px_rgba(232,121,249,0.4)]"
                    : "border-white/15 bg-white/5 text-slate-400"
                )}
              >
                {isMark ? <Mars className="h-3.5 w-3.5" /> : <Venus className="h-3.5 w-3.5" />}
              </span>
            </div>

            <div className={cn("text-sm font-extrabold tracking-wide", active ? "text-white" : "text-slate-200")}>
              {meta.name}
            </div>
            <div className="text-[11px] font-medium text-slate-400">{meta.title}</div>
            <div className="mt-1 line-clamp-1 text-[10px] text-slate-500">{meta.tagline}</div>

            {active && (
              <span
                className={cn(
                  "mt-2 inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-bold",
                  isMark ? "bg-cyan-400/25 text-cyan-200" : "bg-fuchsia-400/25 text-fuchsia-200"
                )}
              >
                <span className={cn("h-1.5 w-1.5 rounded-full animate-pulse", isMark ? "bg-cyan-300" : "bg-fuchsia-300")} />
                Active
              </span>
            )}
          </button>
        );
      })}
    </div>
  );
}
