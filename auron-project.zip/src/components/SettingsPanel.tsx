import {
  X,
  Mic,
  Volume2,
  Cpu,
  KeyRound,
  Radio,
  ShieldCheck,
  Sparkles,
  Clapperboard,
  Activity,
} from "lucide-react";
import type { AssistantState, Character, MicPermissionState } from "../types/assistant";
import { GEMINI_MODELS, VOICE_OPTIONS } from "../config/constants";
import { CHARACTER_META } from "../config/characterVideos";
import CharacterSelector from "./CharacterSelector";
import { cn } from "../utils/cn";

interface Props {
  open: boolean;
  onClose: () => void;
  apiKey: string;
  onApiKeyChange: (v: string) => void;
  model: string;
  onModelChange: (v: string) => void;
  voice: string;
  onVoiceChange: (v: string) => void;
  character: Character;
  onCharacterChange: (c: Character) => void;
  animationEnabled: boolean;
  onAnimationEnabledChange: (on: boolean) => void;
  micPermission: MicPermissionState;
  connection: AssistantState;
  sessionStartedAt: number | null;
  isLive: boolean;
}

export default function SettingsPanel({
  open,
  onClose,
  apiKey,
  onApiKeyChange,
  model,
  onModelChange,
  voice,
  onVoiceChange,
  character,
  onCharacterChange,
  animationEnabled,
  onAnimationEnabledChange,
  micPermission,
  connection,
  sessionStartedAt,
  isLive,
}: Props) {
  const meta = CHARACTER_META[character];
  const prefersReduced =
    typeof window !== "undefined" &&
    typeof window.matchMedia === "function" &&
    window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  return (
    <>
      <div
        onClick={onClose}
        className={cn(
          "fixed inset-0 z-40 bg-black/60 backdrop-blur-sm transition-opacity duration-300",
          open ? "opacity-100" : "pointer-events-none opacity-0"
        )}
        aria-hidden="true"
      />
      <aside
        className={cn(
          "fixed right-0 top-0 z-50 flex h-full w-[88%] max-w-[390px] flex-col border-l border-white/10 bg-[#0a0f1e]/95 shadow-2xl backdrop-blur-2xl transition-transform duration-300 ease-out",
          open ? "translate-x-0" : "translate-x-full"
        )}
        role="dialog"
        aria-label="Auron settings"
        aria-hidden={!open}
      >
        <div className="flex items-center justify-between border-b border-white/10 px-5 py-4">
          <div>
            <h2 className="text-base font-bold tracking-wide text-white">Control Deck</h2>
            <p className="text-xs text-slate-400">Tune {meta.name} to your vibe</p>
          </div>
          <button
            onClick={onClose}
            aria-label="Close settings"
            className="flex h-9 w-9 items-center justify-center rounded-full border border-white/10 bg-white/5 text-slate-300 transition hover:bg-white/10 hover:text-white"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="flex-1 space-y-5 overflow-y-auto px-5 py-5">
          {/* API key */}
          <section className="rounded-2xl border border-amber-300/20 bg-amber-400/[0.06] p-4">
            <div className="mb-2 flex items-center gap-2">
              <KeyRound className="h-4 w-4 text-amber-300" />
              <h3 className="text-sm font-semibold text-amber-100">Gemini API Key</h3>
            </div>
            <p className="mb-3 text-[11px] leading-relaxed text-slate-400">
              Stored only in this browser. Get one free from Google AI Studio.
            </p>
            <input
              type="password"
              value={apiKey}
              onChange={(e) => onApiKeyChange(e.target.value)}
              placeholder="AIza… paste your key"
              autoComplete="off"
              spellCheck={false}
              aria-label="Gemini API key"
              className="w-full rounded-xl border border-white/10 bg-black/40 px-3 py-2.5 text-sm text-white placeholder:text-slate-600 outline-none focus:border-amber-300/50 focus:ring-2 focus:ring-amber-300/20"
            />
            <a
              href="https://aistudio.google.com/apikey"
              target="_blank"
              rel="noreferrer"
              className="mt-2 inline-block text-xs font-medium text-amber-300 hover:text-amber-200 hover:underline"
            >
              Get a key → aistudio.google.com
            </a>
          </section>

          {/* ASSISTANT */}
          <section className="rounded-2xl border border-white/10 bg-white/[0.04] p-4">
            <div className="mb-3 flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-cyan-300" />
              <h3 className="text-xs font-extrabold tracking-[0.2em] text-slate-300">ASSISTANT</h3>
            </div>

            <p className="mb-2 text-xs font-semibold text-slate-400">Character</p>
            <CharacterSelector value={character} onChange={onCharacterChange} />
            <p className="mt-2 text-[11px] leading-relaxed text-slate-500">
              {isLive
                ? `Video switches instantly. Voice applies on next session (reconnect to hear ${character === "priya" ? "Priya" : "Mark"}'s voice).`
                : `Video + voice switch together on next tap. ${meta.name} · ${meta.tagline}.`}
            </p>

            <div className="mt-3 space-y-3 text-sm">
              <div className="flex items-center justify-between gap-2">
                <span className="text-slate-400">Assistant name</span>
                <span className="rounded-full border border-white/10 bg-white/5 px-2.5 py-1 text-xs font-bold text-white">
                  {meta.name} · Auron AI
                </span>
              </div>
              <div className="flex items-center justify-between gap-2">
                <span className="text-slate-400">Personality</span>
                <span className="max-w-[180px] truncate rounded-full border border-cyan-300/20 bg-cyan-400/10 px-2.5 py-1 text-xs font-semibold text-cyan-200">
                  {meta.tagline}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Voice status</span>
                <span className="rounded-full bg-white/5 px-2.5 py-1 font-mono text-xs text-slate-200">
                  {voice}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Connection</span>
                <span
                  className={cn(
                    "flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-semibold",
                    connection === "listening" || connection === "speaking"
                      ? "bg-emerald-400/10 text-emerald-300"
                      : connection === "error"
                        ? "bg-rose-400/10 text-rose-300"
                        : "bg-white/5 text-slate-300"
                  )}
                >
                  <span
                    className={cn(
                      "h-1.5 w-1.5 rounded-full",
                      connection === "listening" || connection === "speaking"
                        ? "bg-emerald-400"
                        : connection === "error"
                          ? "bg-rose-400"
                          : "bg-slate-400"
                    )}
                  />
                  {connection}
                </span>
              </div>
              {sessionStartedAt && (
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Session</span>
                  <span className="text-xs text-slate-300">
                    live since {new Date(sessionStartedAt).toLocaleTimeString()}
                  </span>
                </div>
              )}

              <div>
                <label className="mb-1.5 block text-xs text-slate-400">Model · Gemini Live</label>
                <div className="grid gap-2">
                  {GEMINI_MODELS.map((m) => (
                    <button
                      key={m.id}
                      onClick={() => onModelChange(m.id)}
                      className={cn(
                        "flex items-center justify-between rounded-xl border px-3 py-2 text-left text-xs transition",
                        model === m.id
                          ? "border-cyan-300/40 bg-cyan-400/10 text-white"
                          : "border-white/10 bg-black/30 text-slate-400 hover:border-white/20 hover:text-slate-200"
                      )}
                    >
                      <span className="font-mono">{m.label}</span>
                      <span
                        className={cn(
                          "rounded-full px-2 py-0.5 text-[10px] font-bold",
                          model === m.id ? "bg-cyan-400/20 text-cyan-200" : "bg-white/5 text-slate-500"
                        )}
                      >
                        {m.tag}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="mb-1.5 block text-xs text-slate-400">
                  Voice {character === "priya" ? "· female" : "· male"}
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {VOICE_OPTIONS.filter((v) =>
                    character === "priya" ? v.gender === "female" : v.gender === "male"
                  ).map((v) => (
                    <button
                      key={v.id}
                      onClick={() => onVoiceChange(v.id)}
                      className={cn(
                        "rounded-xl border px-3 py-2 text-left transition",
                        voice === v.id
                          ? character === "priya"
                            ? "border-fuchsia-300/40 bg-fuchsia-400/10"
                            : "border-cyan-300/40 bg-cyan-400/10"
                          : "border-white/10 bg-black/30 hover:border-white/20"
                      )}
                    >
                      <div className={cn("text-xs font-bold", voice === v.id ? "text-white" : "text-slate-300")}>
                        {v.label}
                      </div>
                      <div className="text-[10px] text-slate-500">{v.desc}</div>
                    </button>
                  ))}
                </div>
                {isLive && (
                  <p className="mt-1.5 text-[11px] text-slate-500">
                    Voice change applies when you reconnect.
                  </p>
                )}
              </div>
            </div>
          </section>

          {/* AUDIO */}
          <section className="rounded-2xl border border-white/10 bg-white/[0.04] p-4">
            <div className="mb-3 flex items-center gap-2">
              <Radio className="h-4 w-4 text-emerald-300" />
              <h3 className="text-xs font-extrabold tracking-[0.2em] text-slate-300">AUDIO</h3>
            </div>
            <ul className="space-y-2.5 text-sm">
              <li className="flex items-center justify-between">
                <span className="flex items-center gap-2 text-slate-400">
                  <Mic className="h-3.5 w-3.5" /> Microphone
                </span>
                <span
                  className={cn(
                    "rounded-full px-2 py-0.5 text-xs font-semibold",
                    micPermission === "granted"
                      ? "bg-emerald-400/10 text-emerald-300"
                      : micPermission === "denied"
                        ? "bg-rose-400/10 text-rose-300"
                        : "bg-white/5 text-slate-400"
                  )}
                >
                  {micPermission}
                </span>
              </li>
              <li className="flex items-center justify-between">
                <span className="flex items-center gap-2 text-slate-400">
                  <Activity className="h-3.5 w-3.5" /> Input status
                </span>
                <span className="rounded-full bg-white/5 px-2 py-0.5 font-mono text-[11px] text-slate-300">
                  {isLive ? "streaming · 16k" : "idle"}
                </span>
              </li>
              <li className="flex items-center justify-between">
                <span className="flex items-center gap-2 text-slate-400">
                  <Volume2 className="h-3.5 w-3.5" /> Output status
                </span>
                <span className="rounded-full bg-white/5 px-2 py-0.5 font-mono text-[11px] text-slate-300">
                  {connection === "speaking" ? "playing · 24k" : "ready · 24k"}
                </span>
              </li>
              <li className="flex items-center justify-between">
                <span className="flex items-center gap-2 text-slate-400">
                  <Cpu className="h-3.5 w-3.5" /> Pipeline
                </span>
                <span className="font-mono text-[11px] text-slate-300">PCM16 · low-latency</span>
              </li>
            </ul>
            <p className="mt-3 text-[11px] leading-relaxed text-slate-500">
              Tip: use earbuds to prevent echo. Just start talking to interrupt {meta.name}.
            </p>
          </section>

          {/* VISUAL */}
          <section className="rounded-2xl border border-white/10 bg-white/[0.04] p-4">
            <div className="mb-3 flex items-center gap-2">
              <Clapperboard className="h-4 w-4 text-fuchsia-300" />
              <h3 className="text-xs font-extrabold tracking-[0.2em] text-slate-300">VISUAL</h3>
            </div>
            <div className="flex items-center justify-between gap-3">
              <div>
                <p className="text-sm font-semibold text-white">Live Avatar Animation</p>
                <p className="text-[11px] text-slate-400">
                  Real-time eye blinking, lip-sync mouth, natural breathing & head tracking.
                </p>
              </div>
              <button
                role="switch"
                aria-checked={animationEnabled}
                aria-label="Toggle character animation"
                onClick={() => onAnimationEnabledChange(!animationEnabled)}
                className={cn(
                  "relative h-7 w-12 shrink-0 rounded-full border transition-colors",
                  animationEnabled ? "border-cyan-300/40 bg-cyan-400/30" : "border-white/10 bg-white/10"
                )}
              >
                <span
                  className={cn(
                    "absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all",
                    animationEnabled ? "left-[22px]" : "left-0.5"
                  )}
                />
              </button>
            </div>
            <div className="mt-3 flex items-center justify-between gap-3 rounded-xl border border-white/10 bg-black/30 px-3 py-2.5">
              <div>
                <p className="text-xs font-semibold text-slate-200">Reduced motion</p>
                <p className="text-[11px] text-slate-500">
                  {prefersReduced ? "System requests reduced motion — respected." : "Follow system setting automatically."}
                </p>
              </div>
              <span
                className={cn(
                  "rounded-full px-2 py-0.5 text-[11px] font-bold",
                  prefersReduced || !animationEnabled
                    ? "bg-emerald-400/15 text-emerald-200"
                    : "bg-white/5 text-slate-400"
                )}
              >
                {prefersReduced || !animationEnabled ? "ON" : "OFF"}
              </span>
            </div>
            <p className="mt-2 font-mono text-[10px] leading-relaxed text-slate-600">
              idle → Mark_idle / Priya_idle · thinking → *_thinking · speaking → *_speaking · listening → idle
            </p>
          </section>

          {/* ABOUT */}
          <section className="rounded-2xl border border-white/10 bg-gradient-to-br from-cyan-500/10 via-transparent to-fuchsia-500/10 p-4">
            <div className="mb-1 flex items-center gap-2">
              <ShieldCheck className="h-4 w-4 text-cyan-200" />
              <h3 className="text-xs font-extrabold tracking-[0.2em] text-slate-200">ABOUT</h3>
            </div>
            <p className="text-xs leading-relaxed text-slate-400">
              Auron AI Assistant · Real-time voice AI · Powered by Gemini Live audio-to-audio. Videos:
              place your 6 MP4s in <code className="rounded bg-white/10 px-1 text-[10px]">public/videos/</code>.
              Browser tools run only after URL validation.
            </p>
          </section>
        </div>
      </aside>
    </>
  );
}
