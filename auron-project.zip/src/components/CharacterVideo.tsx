import { useEffect, useRef, useState } from "react";
import type { AssistantState, Character, CharacterVideoState } from "../types/assistant";
import { CHARACTER_META, characterVideos } from "../config/characterVideos";
import LiveCharacterCanvas from "./LiveCharacterCanvas";
import { cn } from "../utils/cn";

interface Props {
  character: Character;
  state: CharacterVideoState;
  assistantState?: AssistantState;
  inputLevelRef?: React.MutableRefObject<number>;
  outputLevelRef?: React.MutableRefObject<number>;
  animationEnabled?: boolean;
  className?: string;
  onVideoMissing?: (missing: boolean) => void;
}

const STATES: CharacterVideoState[] = ["idle", "thinking", "speaking"];
const FADE_MS = 260;

/**
 * Production Character Visual Engine:
 * - Mark: First boy character image (/characters/mark.jpg) with black hoodie & crown
 * - Priya: Second girl character image (/characters/priya.jpg) with pink hoodie & butterfly clip
 * - Triple-layer video engine (/videos/Mark_idle.mp4 etc.) preloaded when MP4s exist
 * - Audio-reactive speaking aura, neural thinking scan, breathing idle animations
 * - 250ms smooth crossfade without black flashes
 */
export default function CharacterVideo({
  character,
  state,
  assistantState = "disconnected",
  inputLevelRef,
  outputLevelRef,
  animationEnabled = true,
  className,
  onVideoMissing,
}: Props) {
  const refs = useRef<Record<CharacterVideoState, HTMLVideoElement | null>>({
    idle: null,
    thinking: null,
    speaking: null,
  });
  const [failed, setFailed] = useState<Record<string, boolean>>({});
  const [ready, setReady] = useState<Record<string, boolean>>({});
  const [speechGlow, setSpeechGlow] = useState(0);

  const characterRef = useRef(character);
  const stateRef = useRef(state);
  stateRef.current = state;

  const meta = CHARACTER_META[character];
  const isPriya = character === "priya";

  // Audio-reactive RAF loop for lighting aura
  useEffect(() => {
    let raf = 0;
    const updateAudioFx = () => {
      const isSpeaking = assistantState === "speaking" || stateRef.current === "speaking";
      const isListening = assistantState === "listening";

      if (isSpeaking && outputLevelRef) {
        const out = outputLevelRef.current || 0;
        setSpeechGlow((prev) => prev * 0.7 + out * 0.3);
      } else if (isListening && inputLevelRef) {
        const inp = inputLevelRef.current || 0;
        setSpeechGlow((prev) => prev * 0.8 + inp * 0.2);
      } else {
        setSpeechGlow((prev) => prev * 0.85);
      }
      raf = requestAnimationFrame(updateAudioFx);
    };
    raf = requestAnimationFrame(updateAudioFx);
    return () => cancelAnimationFrame(raf);
  }, [assistantState, outputLevelRef, inputLevelRef]);

  // When character changes: reload video set
  useEffect(() => {
    const prev = characterRef.current;
    if (prev === character) return;
    characterRef.current = character;
    setReady({});
    const els = refs.current;
    const order: CharacterVideoState[] = ["idle", "thinking", "speaking"];
    order.forEach((vs, idx) => {
      const el = els[vs];
      if (!el) return;
      const src = characterVideos[character][vs];
      if (el.getAttribute("src") !== src) {
        el.src = src;
        el.load();
      }
      window.setTimeout(() => {
        try {
          if (vs !== stateRef.current) el.pause();
        } catch {
          /* noop */
        }
      }, idx * 120);
    });
  }, [character]);

  // Play active / pause hidden video
  useEffect(() => {
    const els = refs.current;
    const active = els[state];
    if (active) {
      const key = `${character}:${state}`;
      if (!failed[key]) {
        active.currentTime = active.currentTime || 0;
        const p = active.play();
        if (p && typeof p.catch === "function") p.catch(() => undefined);
      }
    }
    const t = window.setTimeout(() => {
      (Object.keys(els) as CharacterVideoState[]).forEach((vs) => {
        if (vs === stateRef.current) return;
        try {
          els[vs]?.pause();
        } catch {
          /* noop */
        }
      });
    }, FADE_MS + 60);
    return () => window.clearTimeout(t);
  }, [state, character, failed]);

  // Check if any video is active and playing
  const currentKey = `${character}:${state}`;
  const hasActiveVideo = !!ready[currentKey] && !failed[currentKey];

  useEffect(() => {
    onVideoMissing?.(!hasActiveVideo);
  }, [hasActiveVideo, onVideoMissing]);

  return (
    <div className={cn("relative h-full w-full overflow-hidden select-none", className)}>
      {/* ── BASE STATIC FALLBACK IMAGE (Visible while canvas/image initializes) ── */}
      <div className="absolute inset-0">
        <img
          src={meta.image}
          alt={meta.name}
          className="h-full w-full object-cover object-center"
        />
      </div>

      {/* ── LIVE ANIMATED CHARACTER CANVAS (Blinking, Lip-Sync, Breathing, Swaying, Parallax) ── */}
      <LiveCharacterCanvas
        character={character}
        videoState={state}
        assistantState={assistantState}
        inputLevelRef={inputLevelRef}
        outputLevelRef={outputLevelRef}
        animationEnabled={animationEnabled}
      />

      {/* ── OPTIONAL VIDEO OVERLAY (crossfades over image if MP4s exist) ── */}
      {STATES.map((vs) => {
        const src = characterVideos[character][vs];
        const key = `${character}:${vs}`;
        const isActive = state === vs;
        const isFailed = !!failed[key];
        const isReady = !!ready[key];
        return (
          <video
            key={vs}
            ref={(el) => {
              refs.current[vs] = el;
            }}
            src={src}
            muted
            playsInline
            loop
            autoPlay={vs === "idle"}
            preload="auto"
            disablePictureInPicture
            controls={false}
            tabIndex={-1}
            aria-hidden="true"
            onError={() => {
              setFailed((prev) => (prev[key] ? prev : { ...prev, [key]: true }));
            }}
            onCanPlay={() => {
              setReady((prev) => (prev[key] ? prev : { ...prev, [key]: true }));
              if (stateRef.current === vs) {
                refs.current[vs]?.play().catch(() => undefined);
              }
            }}
            className="absolute inset-0 h-full w-full pointer-events-none"
            style={{
              objectFit: "cover",
              opacity: isActive && !isFailed && isReady ? 1 : 0,
              transition: animationEnabled ? `opacity ${FADE_MS}ms ease-in-out` : "none",
            }}
          />
        );
      })}

      {/* ── AUDIO-REACTIVE SPEAKING AURA OVERLAY ── */}
      {assistantState === "speaking" && (
        <div
          className="pointer-events-none absolute inset-0 transition-opacity duration-150"
          style={{
            opacity: 0.25 + speechGlow * 0.75,
            background: isPriya
              ? "radial-gradient(circle at 50% 45%, rgba(244,114,182,0.35) 0%, rgba(232,121,249,0.2) 40%, transparent 75%)"
              : "radial-gradient(circle at 50% 45%, rgba(56,189,248,0.35) 0%, rgba(34,211,238,0.2) 40%, transparent 75%)",
            mixBlendMode: "screen",
          }}
        />
      )}

      {/* ── THINKING SCANNING LIGHT & HOLOGRAPHIC SHIMMER ── */}
      {state === "thinking" && (
        <div className="pointer-events-none absolute inset-0 overflow-hidden">
          <div
            className="absolute inset-0 bg-gradient-to-b from-transparent via-violet-400/15 to-transparent animate-[auron-shimmer_2s_ease-in-out_infinite]"
            style={{ mixBlendMode: "overlay" }}
          />
          <div
            className="absolute left-0 right-0 h-28 bg-gradient-to-b from-transparent via-cyan-300/25 to-transparent blur-sm"
            style={{
              animation: "auron-scan 2.4s cubic-bezier(0.4, 0, 0.6, 1) infinite",
            }}
          />
        </div>
      )}

      {/* ── LISTENING ACTIVE GLOW ── */}
      {assistantState === "listening" && (
        <div
          className="pointer-events-none absolute inset-0 transition-opacity duration-200"
          style={{
            opacity: 0.2 + speechGlow * 0.5,
            background: isPriya
              ? "radial-gradient(ellipse at 50% 90%, rgba(244,114,182,0.3) 0%, transparent 65%)"
              : "radial-gradient(ellipse at 50% 90%, rgba(52,211,153,0.3) 0%, transparent 65%)",
          }}
        />
      )}

      {/* ── CINEMATIC VIGNETTE & LIGHTING GRADIENT ── */}
      <div
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            "radial-gradient(ellipse 80% 65% at 50% 45%, transparent 45%, rgba(4,6,15,0.4) 80%, rgba(4,6,15,0.85) 100%), linear-gradient(to top, rgba(4,6,15,0.75) 0%, transparent 25%, transparent 75%, rgba(4,6,15,0.45) 100%)",
        }}
      />
    </div>
  );
}
