import { useEffect, useRef } from "react";
import type { AssistantState } from "../types/assistant";

interface Props {
  state: AssistantState;
  inputLevelRef: React.MutableRefObject<number>;
  outputLevelRef: React.MutableRefObject<number>;
}

const COLORS: Record<AssistantState, { core: string; glow: string; ring: string }> = {
  disconnected: { core: "#38bdf8", glow: "rgba(56,189,248,0.35)", ring: "rgba(148,163,184,0.5)" },
  connecting: { core: "#fbbf24", glow: "rgba(251,191,36,0.4)", ring: "rgba(251,191,36,0.65)" },
  listening: { core: "#22d3ee", glow: "rgba(34,211,238,0.45)", ring: "rgba(34,211,238,0.7)" },
  thinking: { core: "#a78bfa", glow: "rgba(167,139,250,0.5)", ring: "rgba(167,139,250,0.75)" },
  speaking: { core: "#e879f9", glow: "rgba(232,121,249,0.5)", ring: "rgba(34,211,238,0.7)" },
  error: { core: "#fb7185", glow: "rgba(251,113,133,0.4)", ring: "rgba(251,113,133,0.6)" },
};

export default function AuronAvatar({ state, inputLevelRef, outputLevelRef }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const stateRef = useRef(state);
  stateRef.current = state;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let raf = 0;
    let t = Math.random() * 1000;
    const particles = Array.from({ length: 42 }, (_, i) => ({
      angle: (i / 42) * Math.PI * 2,
      radiusJitter: 0.75 + Math.random() * 0.45,
      speed: 0.15 + Math.random() * 0.5,
      size: 1 + Math.random() * 2.2,
      alpha: 0.25 + Math.random() * 0.55,
    }));

    const render = () => {
      const s = stateRef.current;
      const dpr = Math.min(2, window.devicePixelRatio || 1);
      const rect = canvas.getBoundingClientRect();
      const W = Math.max(1, rect.width);
      const H = Math.max(1, rect.height);
      if (canvas.width !== Math.floor(W * dpr) || canvas.height !== Math.floor(H * dpr)) {
        canvas.width = Math.floor(W * dpr);
        canvas.height = Math.floor(H * dpr);
      }
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, W, H);

      const cx = W / 2;
      const cy = H / 2;
      const base = Math.min(W, H) * 0.30;

      const inLevel = inputLevelRef.current ?? 0;
      const outLevel = outputLevelRef.current ?? 0;

      let energy = 0.12;
      let spin = 0.4;
      if (s === "listening") {
        energy = 0.18 + inLevel * 0.9;
        spin = 0.6 + inLevel * 1.6;
      } else if (s === "speaking") {
        energy = 0.3 + outLevel * 1.1;
        spin = 1.1 + outLevel * 2.2;
      } else if (s === "thinking") {
        energy = 0.32 + Math.sin(t * 0.06) * 0.12;
        spin = 2.2;
      } else if (s === "connecting") {
        energy = 0.25 + Math.sin(t * 0.05) * 0.12;
        spin = 1.4;
      } else if (s === "disconnected") {
        energy = 0.1 + Math.sin(t * 0.02) * 0.04;
        spin = 0.25;
      } else if (s === "error") {
        energy = 0.2 + Math.sin(t * 0.08) * 0.08;
        spin = 0.5;
      }

      t += 0.016 * (0.7 + energy);

      const col = COLORS[s];
      const pulse = 1 + Math.sin(t * 2.2) * 0.045 + energy * 0.22;
      const R = base * pulse;

      // Outer ambient glow
      const glowR = R * 2.6;
      const glow = ctx.createRadialGradient(cx, cy, R * 0.2, cx, cy, glowR);
      glow.addColorStop(0, col.glow);
      glow.addColorStop(0.45, col.glow.replace(/[\d.]+\)$/, "0.14)"));
      glow.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = glow;
      ctx.beginPath();
      ctx.arc(cx, cy, glowR, 0, Math.PI * 2);
      ctx.fill();

      // Orbit particles
      for (const p of particles) {
        p.angle += 0.008 * p.speed * spin;
        const rr = R * (1.35 + Math.sin(t * 1.4 + p.angle * 3) * 0.12 * (0.5 + energy)) * p.radiusJitter;
        const x = cx + Math.cos(p.angle) * rr;
        const y = cy + Math.sin(p.angle) * rr * 0.92;
        ctx.globalAlpha = p.alpha * (0.4 + energy);
        ctx.fillStyle = s === "speaking" ? "#a5f3fc" : col.core;
        ctx.beginPath();
        ctx.arc(x, y, p.size * (0.8 + energy * 0.7), 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.globalAlpha = 1;

      // Rotating rings
      const rings = [
        { r: R * 1.55, w: 1.5, dash: [6, 14], rot: t * spin * 0.7, alpha: 0.55 },
        { r: R * 1.32, w: 2, dash: [28, 18], rot: -t * spin * 0.9, alpha: 0.7 },
        { r: R * 1.12, w: 1, dash: [3, 9], rot: t * spin * 1.3, alpha: 0.5 },
      ];
      for (const rg of rings) {
        ctx.save();
        ctx.translate(cx, cy);
        ctx.rotate(rg.rot);
        ctx.globalAlpha = rg.alpha;
        ctx.strokeStyle = col.ring;
        ctx.lineWidth = rg.w;
        ctx.setLineDash(rg.dash);
        ctx.beginPath();
        ctx.arc(0, 0, rg.r, 0, Math.PI * 2);
        ctx.stroke();
        ctx.restore();
      }
      ctx.globalAlpha = 1;
      ctx.setLineDash([]);

      // Core orb — layered gradients
      const coreGrad = ctx.createRadialGradient(
        cx - R * 0.25,
        cy - R * 0.3,
        R * 0.1,
        cx,
        cy,
        R
      );
      coreGrad.addColorStop(0, "#ffffff");
      coreGrad.addColorStop(0.18, col.core);
      coreGrad.addColorStop(0.55, s === "speaking" ? "#0e7490" : "#0f172a");
      coreGrad.addColorStop(1, "rgba(2,6,23,0.95)");
      ctx.fillStyle = coreGrad;
      ctx.beginPath();
      ctx.arc(cx, cy, R, 0, Math.PI * 2);
      ctx.fill();

      // Inner wave highlight (speaking bounce)
      const waveAmp = s === "speaking" ? outLevel * R * 0.28 : s === "listening" ? inLevel * R * 0.2 : R * 0.06;
      ctx.save();
      ctx.beginPath();
      ctx.arc(cx, cy, R * 0.98, 0, Math.PI * 2);
      ctx.clip();
      ctx.globalAlpha = 0.5;
      ctx.strokeStyle = "rgba(255,255,255,0.85)";
      ctx.lineWidth = 1.6;
      ctx.beginPath();
      for (let x = -R; x <= R; x += 4) {
        const y =
          Math.sin(x * 0.08 + t * (s === "speaking" ? 9 : 3.2)) * waveAmp * Math.cos((x / R) * 1.1);
        const px = cx + x;
        const py = cy + y;
        if (x === -R) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      }
      ctx.stroke();
      // second harmonic
      ctx.globalAlpha = 0.28;
      ctx.beginPath();
      for (let x = -R; x <= R; x += 4) {
        const y =
          Math.sin(x * 0.05 - t * (s === "thinking" ? 7 : 4)) * waveAmp * 0.7;
        const px = cx + x;
        const py = cy + y * 0.6 - R * 0.18;
        if (x === -R) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      }
      ctx.stroke();
      ctx.restore();
      ctx.globalAlpha = 1;

      // Glass rim
      const rim = ctx.createLinearGradient(cx - R, cy - R, cx + R, cy + R);
      rim.addColorStop(0, "rgba(255,255,255,0.55)");
      rim.addColorStop(0.3, "rgba(255,255,255,0.08)");
      rim.addColorStop(0.7, "rgba(255,255,255,0.06)");
      rim.addColorStop(1, "rgba(255,255,255,0.35)");
      ctx.strokeStyle = rim;
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(cx, cy, R, 0, Math.PI * 2);
      ctx.stroke();

      raf = requestAnimationFrame(render);
    };

    raf = requestAnimationFrame(render);
    return () => cancelAnimationFrame(raf);
  }, [inputLevelRef, outputLevelRef]);

  return (
    <div className="relative mx-auto aspect-square w-full select-none">
      <canvas ref={canvasRef} className="h-full w-full" aria-hidden="true" />
      {/* Center monogram */}
      <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
        <div className="flex h-16 w-16 items-center justify-center rounded-2xl border border-white/20 bg-white/[0.06] shadow-[0_0_40px_rgba(34,211,238,0.25)] backdrop-blur-xl">
          <span className="bg-gradient-to-br from-white via-cyan-200 to-fuchsia-300 bg-clip-text text-3xl font-black tracking-tighter text-transparent">
            A
          </span>
        </div>
      </div>
    </div>
  );
}
