import { useEffect, useRef } from "react";
import type { AssistantState, Character, CharacterVideoState } from "../types/assistant";
import { CHARACTER_META } from "../config/characterVideos";

interface Props {
  character: Character;
  videoState: CharacterVideoState;
  assistantState: AssistantState;
  inputLevelRef?: React.MutableRefObject<number>;
  outputLevelRef?: React.MutableRefObject<number>;
  animationEnabled?: boolean;
  className?: string;
}

interface LandmarkConfig {
  mouth: { x: number; y: number; w: number; h: number };
  hand: { x: number; y: number; w: number; h: number; pivotX: number; pivotY: number };
  skinColor: string;
}

const LANDMARKS: Record<Character, LandmarkConfig> = {
  mark: {
    mouth: { x: 0.528, y: 0.401, w: 0.044, h: 0.024 },
    hand: { x: 0.38, y: 0.40, w: 0.16, h: 0.22, pivotX: 0.36, pivotY: 0.60 },
    skinColor: "rgb(215, 175, 160)",
  },
  priya: {
    mouth: { x: 0.507, y: 0.386, w: 0.042, h: 0.026 },
    hand: { x: 0.46, y: 0.36, w: 0.18, h: 0.24, pivotX: 0.56, pivotY: 0.60 },
    skinColor: "rgb(238, 192, 175)",
  },
};

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  alpha: number;
  maxAlpha: number;
  hue: number;
  sparkleSpeed: number;
}

export default function LiveCharacterCanvas({
  character,
  videoState,
  assistantState,
  inputLevelRef,
  outputLevelRef,
  animationEnabled = true,
  className = "",
}: Props) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const imgRef = useRef<HTMLImageElement | null>(null);
  const characterRef = useRef(character);
  characterRef.current = character;

  const stateRef = useRef({ videoState, assistantState, animationEnabled });
  stateRef.current = { videoState, assistantState, animationEnabled };

  // Mouse / Pointer Parallax target
  const pointerRef = useRef({ x: 0.5, y: 0.5, currentX: 0.5, currentY: 0.5 });

  // Preload and cache character images
  useEffect(() => {
    const meta = CHARACTER_META[character];
    const img = new Image();
    img.src = meta.image;
    img.onload = () => {
      imgRef.current = img;
    };
    if (img.complete && img.naturalWidth > 0) {
      imgRef.current = img;
    }
  }, [character]);

  // Pointer movement tracking
  useEffect(() => {
    const onPointerMove = (e: PointerEvent) => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const rect = canvas.getBoundingClientRect();
      const px = (e.clientX - rect.left) / rect.width;
      const py = (e.clientY - rect.top) / rect.height;
      pointerRef.current.x = Math.max(0, Math.min(1, px));
      pointerRef.current.y = Math.max(0, Math.min(1, py));
    };

    window.addEventListener("pointermove", onPointerMove);
    return () => window.removeEventListener("pointermove", onPointerMove);
  }, []);

  // Main 60fps Live Animation Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let rafId = 0;
    const startTime = performance.now();

    // ── MOUTH LIP-SYNC STATE MACHINE ──
    let mouthOpen = 0; // 0 = closed, 1 = open

    // ── HAND ANIMATION STATE MACHINE ──
    const handOffset = { x: 0, y: 0, rot: 0, scale: 1 };

    // Floating atmospheric particles
    const isPriya = character === "priya";
    const particles: Particle[] = Array.from({ length: 32 }, () => ({
      x: Math.random(),
      y: Math.random(),
      vx: (Math.random() - 0.5) * 0.0003,
      vy: -0.0004 - Math.random() * 0.0006,
      size: 1.5 + Math.random() * 3.5,
      alpha: Math.random() * 0.7,
      maxAlpha: 0.3 + Math.random() * 0.5,
      hue: isPriya ? 330 + Math.random() * 40 : 185 + Math.random() * 40,
      sparkleSpeed: 0.003 + Math.random() * 0.004,
    }));

    const render = (now: number) => {
      const elapsed = now - startTime;
      const curChar = characterRef.current;
      const lm = LANDMARKS[curChar];
      const { assistantState: astState, videoState: vidState, animationEnabled: animOn } =
        stateRef.current;

      // Handle HiDPI Crisp Canvas Scaling
      const dpr = Math.min(2, window.devicePixelRatio || 1);
      const rect = canvas.getBoundingClientRect();
      const W = Math.max(1, rect.width);
      const H = Math.max(1, rect.height);
      if (canvas.width !== Math.floor(W * dpr) || canvas.height !== Math.floor(H * dpr)) {
        canvas.width = Math.floor(W * dpr);
        canvas.height = Math.floor(H * dpr);
      }
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, W, H);

      // Smooth Pointer Parallax Lerp
      const ptr = pointerRef.current;
      ptr.currentX += (ptr.x - ptr.currentX) * 0.06;
      ptr.currentY += (ptr.y - ptr.currentY) * 0.06;
      const lookOffsetX = (ptr.currentX - 0.5) * 2; // -1 to +1
      const lookOffsetY = (ptr.currentY - 0.5) * 2; // -1 to +1

      // Audio Levels
      const outLevel = outputLevelRef?.current || 0;
      const inLevel = inputLevelRef?.current || 0;

      // Breathing & Head Motion
      const breathTime = animOn ? elapsed * 0.0022 : 0;
      const breathY = Math.sin(breathTime) * (H * 0.006);
      const breathScale = 1 + Math.sin(breathTime) * 0.004;

      // Head Tilt & Sway by State
      let tiltAngle = Math.sin(elapsed * 0.0011) * 0.008;
      let nodY = 0;

      const isThinking = astState === "thinking" || vidState === "thinking";
      const isSpeaking = astState === "speaking" || vidState === "speaking";
      const isListening = astState === "listening";

      // ── DYNAMIC STATE ANIMATION BEHAVIORS ──
      let targetHandY = 0;
      let targetHandX = 0;
      let targetHandRot = 0;

      if (isThinking) {
        // 🤔 THINKING STATE:
        // Pensive head tilt, eyes wander up, finger gently taps chin/cheek
        tiltAngle = curChar === "mark" ? -0.052 : 0.046;
        nodY = Math.sin(elapsed * 0.0035) * 5 - 2;

        const fingerTap = Math.sin(elapsed * 0.007) * 4.5 + Math.cos(elapsed * 0.014) * 2;
        targetHandY = -8 + fingerTap;
        targetHandX = curChar === "mark" ? -3 : 3;
        targetHandRot = curChar === "mark" ? -0.035 : 0.035;
      } else if (isListening) {
        // 👂 LISTENING STATE:
        // Attentive lean forward
        nodY = -5 + Math.sin(elapsed * 0.002) * 2;
        tiltAngle = Math.sin(elapsed * 0.0015) * 0.008;
        targetHandY = -2;
        targetHandX = 0;
        targetHandRot = 0;
      } else if (isSpeaking) {
        // 🗣️ SPEAKING STATE:
        // Head nods to speech cadence, hand gestures naturally
        const speechEnergy = Math.min(1, outLevel * 3.8);
        nodY = Math.sin(elapsed * 0.016) * (7 * speechEnergy) + Math.sin(elapsed * 0.008) * 3;
        tiltAngle += Math.sin(elapsed * 0.011) * (0.024 * speechEnergy);

        const gestureSwing = Math.sin(elapsed * 0.012) * (14 * speechEnergy) + Math.cos(elapsed * 0.006) * 5;
        const gestureLift = Math.abs(Math.sin(elapsed * 0.008)) * (16 * speechEnergy);
        targetHandY = gestureLift;
        targetHandX = curChar === "mark" ? -gestureSwing * 0.6 : gestureSwing * 0.6;
        targetHandRot = curChar === "mark" ? (gestureSwing * 0.004) : (-gestureSwing * 0.004);
      } else {
        // 😴 IDLE STATE:
        targetHandY = Math.sin(breathTime * 0.8) * 2.5;
        targetHandX = Math.cos(breathTime * 0.6) * 1.5;
        targetHandRot = 0;
      }

      // Smooth Lerp for Hand movement
      handOffset.y += (targetHandY - handOffset.y) * 0.12;
      handOffset.x += (targetHandX - handOffset.x) * 0.12;
      handOffset.rot += (targetHandRot - handOffset.rot) * 0.12;

      // Parallax rotation
      tiltAngle += lookOffsetX * 0.02;

      // ── Draw Base Character Image ──
      const img = imgRef.current;
      if (img && img.complete && img.naturalWidth > 0) {
        ctx.save();

        // Origin at head center for realistic tilt
        const headCenterX = W * 0.5 + lookOffsetX * 4;
        const headCenterY = H * 0.42 + breathY + nodY + lookOffsetY * 3;
        ctx.translate(headCenterX, headCenterY);
        ctx.rotate(tiltAngle);
        ctx.scale(breathScale, breathScale);
        ctx.translate(-headCenterX, -headCenterY);

        // Object-cover calculation
        const scale = Math.max(W / img.naturalWidth, H / img.naturalHeight);
        const renderW = img.naturalWidth * scale;
        const renderH = img.naturalHeight * scale;
        const renderX = (W - renderW) * 0.5 + lookOffsetX * 6;
        const renderY = (H - renderH) * 0.36 + breathY + nodY + lookOffsetY * 4;

        ctx.drawImage(img, renderX, renderY, renderW, renderH);

        // ── LIVE HAND GESTURE & TAP ANIMATION ──
        if (animOn && (Math.abs(handOffset.y) > 0.4 || Math.abs(handOffset.x) > 0.4)) {
          renderAnimatedHand(ctx, img, renderX, renderY, renderW, renderH, lm.hand, handOffset);
        }

        // ── Lip-Sync Talking Mouth Logic ──
        if (isSpeaking && animOn) {
          const rawEnergy = Math.min(1, outLevel * 4.6);
          const syllable =
            Math.sin(elapsed * 0.026) * 0.35 +
            Math.sin(elapsed * 0.016) * 0.35 +
            Math.sin(elapsed * 0.042) * 0.3;
          const targetOpen = rawEnergy > 0.04 ? Math.max(0.14, rawEnergy * 0.65 + syllable * 0.35) : 0;
          mouthOpen += (targetOpen - mouthOpen) * 0.34;
        } else {
          mouthOpen += (0 - mouthOpen) * 0.24;
        }

        // Render Talking Mouth
        if (mouthOpen > 0.05 && animOn) {
          renderTalkingMouth(ctx, renderX, renderY, renderW, renderH, lm.mouth, mouthOpen, lm, curChar);
        }

        ctx.restore();
      }

      // ── Ambient Room Atmospheric Sparkles / Particles ──
      if (animOn) {
        ctx.save();
        for (const p of particles) {
          p.x += p.vx;
          p.y += p.vy;
          if (p.y < -0.05) {
            p.y = 1.05;
            p.x = Math.random();
          }
          if (p.x < 0) p.x = 1;
          if (p.x > 1) p.x = 0;

          const px = p.x * W;
          const py = p.y * H;
          const sparkle = Math.sin(elapsed * p.sparkleSpeed) * 0.5 + 0.5;
          const a = p.alpha * sparkle * p.maxAlpha;

          ctx.fillStyle = `hsla(${p.hue}, 90%, 75%, ${a})`;
          ctx.beginPath();
          ctx.arc(px, py, p.size, 0, Math.PI * 2);
          ctx.fill();

          if (p.size > 2.6 && a > 0.25) {
            ctx.strokeStyle = `hsla(${p.hue}, 90%, 85%, ${a * 0.6})`;
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(px - p.size * 2, py);
            ctx.lineTo(px + p.size * 2, py);
            ctx.moveTo(px, py - p.size * 2);
            ctx.lineTo(px, py + p.size * 2);
            ctx.stroke();
          }
        }
        ctx.restore();
      }

      // ── State Auras ──
      if (isThinking) {
        renderThinkingAura(ctx, W, H, elapsed, curChar);
      } else if (isListening) {
        renderListeningAura(ctx, W, H, elapsed, inLevel, curChar);
      } else if (isSpeaking) {
        renderSpeakingAura(ctx, W, H, elapsed, outLevel, curChar);
      }

      rafId = requestAnimationFrame(render);
    };

    rafId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(rafId);
  }, [character]);

  return (
    <canvas
      ref={canvasRef}
      className={`absolute inset-0 h-full w-full pointer-events-none select-none ${className}`}
      style={{ touchAction: "none" }}
    />
  );
}

// ─────────────────────────────────────────────────────────────
// ANIMATED HAND RENDERING (Chin/Cheek Tap & Speaking Gestures)
// ─────────────────────────────────────────────────────────────
function renderAnimatedHand(
  ctx: CanvasRenderingContext2D,
  img: HTMLImageElement,
  renderX: number,
  renderY: number,
  renderW: number,
  renderH: number,
  h: LandmarkConfig["hand"],
  offset: { x: number; y: number; rot: number }
) {
  const sx = h.x * img.naturalWidth;
  const sy = h.y * img.naturalHeight;
  const sw = h.w * img.naturalWidth;
  const sh = h.h * img.naturalHeight;

  const dx = renderX + h.x * renderW;
  const dy = renderY + h.y * renderH;
  const dw = h.w * renderW;
  const dh = h.h * renderH;

  const pivotPx = renderX + h.pivotX * renderW;
  const pivotPy = renderY + h.pivotY * renderH;

  ctx.save();
  ctx.translate(pivotPx, pivotPy);
  ctx.rotate(offset.rot);
  ctx.translate(-pivotPx, -pivotPy);

  ctx.beginPath();
  ctx.ellipse(dx + dw * 0.5 + offset.x, dy + dh * 0.5 + offset.y, dw * 0.52, dh * 0.52, 0, 0, Math.PI * 2);
  ctx.clip();

  ctx.shadowColor = "rgba(10, 15, 30, 0.35)";
  ctx.shadowBlur = 12;
  ctx.shadowOffsetX = offset.x * 0.4;
  ctx.shadowOffsetY = offset.y * 0.6 + 2;

  ctx.drawImage(img, sx, sy, sw, sh, dx + offset.x, dy + offset.y, dw, dh);
  ctx.restore();
}

// ─────────────────────────────────────────────────────────────
// LIP-SYNC TALKING MOUTH RENDERING
// ─────────────────────────────────────────────────────────────
function renderTalkingMouth(
  ctx: CanvasRenderingContext2D,
  renderX: number,
  renderY: number,
  renderW: number,
  renderH: number,
  m: LandmarkConfig["mouth"],
  open: number,
  lm: LandmarkConfig,
  character: Character
) {
  const mouthX = renderX + m.x * renderW;
  const mouthY = renderY + m.y * renderH;
  const maxW = m.w * renderW;
  const maxH = m.h * renderH * 1.35;

  const curW = maxW * (0.85 + open * 0.25);
  const curH = maxH * open;

  ctx.save();
  ctx.translate(mouthX, mouthY);

  // 1. Soft feather background to blend seamlessly with original lips
  ctx.fillStyle = lm.skinColor;
  ctx.beginPath();
  ctx.ellipse(0, curH * 0.1, curW * 0.58, curH * 0.65, 0, 0, Math.PI * 2);
  ctx.fill();

  // 2. Interior Mouth Cavity (Dark crimson gradient)
  const mouthGrad = ctx.createLinearGradient(0, -curH * 0.4, 0, curH * 0.6);
  mouthGrad.addColorStop(0, "#3e1217");
  mouthGrad.addColorStop(0.5, "#5a1b22");
  mouthGrad.addColorStop(1, "#7d252f");

  ctx.fillStyle = mouthGrad;
  ctx.beginPath();
  ctx.moveTo(-curW * 0.48, 0);
  ctx.quadraticCurveTo(-curW * 0.15, -curH * 0.45, 0, -curH * 0.35);
  ctx.quadraticCurveTo(curW * 0.15, -curH * 0.45, curW * 0.48, 0);
  ctx.quadraticCurveTo(curW * 0.32, curH * 0.58, 0, curH * 0.62);
  ctx.quadraticCurveTo(-curW * 0.32, curH * 0.58, -curW * 0.48, 0);
  ctx.closePath();
  ctx.fill();

  // 3. Upper Teeth hint
  if (open > 0.2) {
    ctx.fillStyle = "#fafafd";
    ctx.beginPath();
    ctx.moveTo(-curW * 0.35, -curH * 0.15);
    ctx.quadraticCurveTo(0, -curH * 0.32, curW * 0.35, -curH * 0.15);
    ctx.quadraticCurveTo(0, -curH * 0.08, -curW * 0.35, -curH * 0.15);
    ctx.fill();
  }

  // 4. Rosy Tongue hint
  if (open > 0.3) {
    ctx.fillStyle = character === "priya" ? "#e06c78" : "#cf5a67";
    ctx.beginPath();
    ctx.ellipse(0, curH * 0.38, curW * 0.28, curH * 0.24, 0, 0, Math.PI);
    ctx.fill();
  }

  // 5. Lip contour outline & corners
  ctx.strokeStyle = character === "priya" ? "rgba(180, 80, 95, 0.85)" : "rgba(140, 75, 75, 0.85)";
  ctx.lineWidth = 1.6;
  ctx.lineCap = "round";
  ctx.beginPath();
  ctx.moveTo(-curW * 0.48, 0);
  ctx.quadraticCurveTo(0, -curH * 0.42, curW * 0.48, 0);
  ctx.moveTo(-curW * 0.46, 0);
  ctx.quadraticCurveTo(0, curH * 0.62, curW * 0.46, 0);
  ctx.stroke();

  // 6. Subtle anime lower lip gloss highlight
  if (open > 0.25) {
    ctx.fillStyle = "rgba(255, 255, 255, 0.55)";
    ctx.beginPath();
    ctx.ellipse(curW * 0.05, curH * 0.52, curW * 0.15, curH * 0.08, 0.1, 0, Math.PI * 2);
    ctx.fill();
  }

  ctx.restore();
}

// ─────────────────────────────────────────────────────────────
// THINKING AURA
// ─────────────────────────────────────────────────────────────
function renderThinkingAura(
  ctx: CanvasRenderingContext2D,
  W: number,
  H: number,
  elapsed: number,
  character: Character
) {
  ctx.save();
  const cx = W * 0.5;
  const cy = H * 0.38;
  const pulse = Math.sin(elapsed * 0.005) * 0.5 + 0.5;
  const color = character === "priya" ? "232, 121, 249" : "34, 211, 238";

  const r = W * (0.35 + pulse * 0.08);
  const grad = ctx.createRadialGradient(cx, cy, r * 0.3, cx, cy, r);
  grad.addColorStop(0, `rgba(${color}, ${0.12 * pulse})`);
  grad.addColorStop(0.7, `rgba(${color}, ${0.05 * pulse})`);
  grad.addColorStop(1, "rgba(0, 0, 0, 0)");

  ctx.fillStyle = grad;
  ctx.beginPath();
  ctx.arc(cx, cy, r, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

// ─────────────────────────────────────────────────────────────
// LISTENING AURA
// ─────────────────────────────────────────────────────────────
function renderListeningAura(
  ctx: CanvasRenderingContext2D,
  W: number,
  H: number,
  elapsed: number,
  inLevel: number,
  character: Character
) {
  ctx.save();
  const cx = W * 0.5;
  const cy = H * 0.42;
  const boost = Math.min(1, inLevel * 3.5);
  const color = character === "priya" ? "244, 114, 182" : "52, 211, 153";

  for (let i = 0; i < 3; i++) {
    const wave = (elapsed * 0.0018 + i * 0.33) % 1;
    const r = W * (0.28 + wave * 0.28);
    const alpha = (1 - wave) * (0.15 + boost * 0.35);

    ctx.strokeStyle = `rgba(${color}, ${alpha})`;
    ctx.lineWidth = 1.8 + boost * 1.5;
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.stroke();
  }
  ctx.restore();
}

// ─────────────────────────────────────────────────────────────
// SPEAKING AURA
// ─────────────────────────────────────────────────────────────
function renderSpeakingAura(
  ctx: CanvasRenderingContext2D,
  W: number,
  H: number,
  elapsed: number,
  outLevel: number,
  character: Character
) {
  ctx.save();
  const cx = W * 0.5;
  const cy = H * 0.48;
  const energy = Math.min(1, outLevel * 3.8);
  const color = character === "priya" ? "236, 72, 153" : "56, 189, 248";

  const r = W * (0.35 + energy * 0.18 + Math.sin(elapsed * 0.012) * 0.03);
  const grad = ctx.createRadialGradient(cx, cy, r * 0.2, cx, cy, r);
  grad.addColorStop(0, `rgba(${color}, ${0.2 * energy})`);
  grad.addColorStop(0.6, `rgba(${color}, ${0.08 * energy})`);
  grad.addColorStop(1, "rgba(0, 0, 0, 0)");

  ctx.fillStyle = grad;
  ctx.beginPath();
  ctx.arc(cx, cy, r, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}
