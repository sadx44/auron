import { useEffect, useRef } from "react";
import type { AssistantState } from "../types/assistant";

interface Props {
  state: AssistantState;
  inputLevelRef: React.MutableRefObject<number>;
  outputLevelRef: React.MutableRefObject<number>;
}

export default function Waveform({ state, inputLevelRef, outputLevelRef }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const stateRef = useRef(state);
  stateRef.current = state;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    let raf = 0;
    let t = 0;
    const BARS = 48;

    const render = () => {
      t += 0.06;
      const s = stateRef.current;
      const dpr = Math.min(2, window.devicePixelRatio || 1);
      const rect = canvas.getBoundingClientRect();
      const W = Math.max(1, rect.width);
      const H = Math.max(1, rect.height);
      if (canvas.width !== Math.floor(W * dpr) || canvas.height !== Math.floor(H * dpr)) {
        canvas.width = Math.floor(W * dpr);
        canvas.height = Math.floor(H * dpr);
      }
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, W, H);

      const inL = inputLevelRef.current ?? 0;
      const outL = outputLevelRef.current ?? 0;

      const gap = 4;
      const bw = (W - gap * (BARS - 1)) / BARS;
      const mid = H / 2;

      for (let i = 0; i < BARS; i++) {
        const p = i / (BARS - 1); // 0..1
        const centerBias = Math.sin(p * Math.PI); // louder in middle
        let h = 4;

        if (s === "listening") {
          const wave = Math.sin(i * 0.55 + t * 3.1) * 0.5 + 0.5;
          h = 4 + centerBias * (6 + inL * 44 + wave * (6 + inL * 22));
        } else if (s === "speaking") {
          const wave = Math.sin(i * 0.7 - t * 4.2) * 0.5 + 0.5;
          h = 4 + centerBias * (8 + outL * 52 + wave * (8 + outL * 26));
        } else if (s === "thinking") {
          const traveling = Math.sin(i * 0.5 - t * 2.4) * 0.5 + 0.5;
          h = 4 + centerBias * (6 + traveling * 18);
        } else if (s === "connecting") {
          const traveling = Math.sin(i * 0.4 - t * 1.8) * 0.5 + 0.5;
          h = 4 + centerBias * (4 + traveling * 12);
        } else if (s === "error") {
          h = 4 + centerBias * 6;
        } else {
          const breath = Math.sin(t * 0.9 + i * 0.2) * 0.5 + 0.5;
          h = 3 + centerBias * (3 + breath * 5);
        }

        h = Math.min(H - 4, h);
        const x = i * (bw + gap);
        const y = mid - h / 2;

        let fill: string | CanvasGradient;
        if (s === "speaking") {
          const g = ctx.createLinearGradient(0, y, 0, y + h);
          g.addColorStop(0, "#e879f9");
          g.addColorStop(0.5, "#a5f3fc");
          g.addColorStop(1, "#22d3ee");
          fill = g;
        } else if (s === "listening") {
          const g = ctx.createLinearGradient(0, y, 0, y + h);
          g.addColorStop(0, "#67e8f9");
          g.addColorStop(1, "#0ea5e9");
          fill = g;
        } else if (s === "thinking") {
          const g = ctx.createLinearGradient(0, y, 0, y + h);
          g.addColorStop(0, "#c4b5fd");
          g.addColorStop(1, "#7c3aed");
          fill = g;
        } else if (s === "error") {
          fill = "rgba(251,113,133,0.7)";
        } else if (s === "connecting") {
          fill = "rgba(251,191,36,0.8)";
        } else {
          fill = "rgba(148,163,184,0.45)";
        }

        ctx.fillStyle = fill;
        const r = Math.min(bw / 2, 3);
        // rounded bar
        ctx.beginPath();
        if (typeof ctx.roundRect === "function") {
          ctx.roundRect(x, y, bw, h, r);
        } else {
          ctx.rect(x, y, bw, h);
        }
        ctx.fill();

        // glow dot on peaks when active
        if ((s === "listening" && inL > 0.35) || (s === "speaking" && outL > 0.35)) {
          if (h > H * 0.45) {
            ctx.fillStyle = "rgba(255,255,255,0.9)";
            ctx.beginPath();
            ctx.arc(x + bw / 2, y, 1.6, 0, Math.PI * 2);
            ctx.fill();
          }
        }
      }

      raf = requestAnimationFrame(render);
    };
    raf = requestAnimationFrame(render);
    return () => cancelAnimationFrame(raf);
  }, [inputLevelRef, outputLevelRef]);

  return (
    <div className="w-full px-2" aria-hidden="true">
      <canvas ref={canvasRef} className="h-[54px] w-full" />
    </div>
  );
}
