import { Mic, Square, Loader2, PlugZap, RotateCcw } from "lucide-react";
import type { AssistantState } from "../types/assistant";
import { cn } from "../utils/cn";

interface Props {
  state: AssistantState;
  onToggle: () => void;
}

export default function MicButton({ state, onToggle }: Props) {
  const isLive = state === "listening" || state === "thinking" || state === "speaking";
  const isConnecting = state === "connecting";
  const isError = state === "error";

  return (
    <div className="relative flex items-center justify-center">
      {/* pulse rings when live */}
      {(state === "listening" || state === "speaking") && (
        <>
          <span
            className={cn(
              "absolute h-24 w-24 animate-ping rounded-full opacity-20",
              state === "speaking" ? "bg-fuchsia-400" : "bg-cyan-400"
            )}
            style={{ animationDuration: "1.8s" }}
            aria-hidden="true"
          />
          <span
            className={cn(
              "absolute h-28 w-28 animate-ping rounded-full opacity-10",
              state === "speaking" ? "bg-fuchsia-300" : "bg-cyan-300"
            )}
            style={{ animationDuration: "2.6s", animationDelay: "0.4s" }}
            aria-hidden="true"
          />
        </>
      )}

      <button
        onClick={onToggle}
        disabled={isConnecting}
        aria-label={
          state === "disconnected"
            ? "Tap to start talking to Auron"
            : isError
              ? "Retry connection"
              : isConnecting
                ? "Connecting to Auron"
                : "End session"
        }
        className={cn(
          "group relative flex h-20 w-20 items-center justify-center rounded-full border transition-all duration-300 outline-none",
          "focus-visible:ring-4 focus-visible:ring-cyan-400/50 active:scale-95",
          state === "disconnected" &&
            "border-cyan-300/30 bg-gradient-to-br from-cyan-500 via-sky-600 to-blue-700 shadow-[0_0_50px_rgba(34,211,238,0.45)] hover:shadow-[0_0_70px_rgba(34,211,238,0.6)] hover:scale-[1.04]",
          state === "listening" &&
            "border-cyan-200/50 bg-gradient-to-br from-cyan-400 via-sky-500 to-blue-600 shadow-[0_0_60px_rgba(34,211,238,0.6)]",
          state === "speaking" &&
            "border-fuchsia-200/50 bg-gradient-to-br from-fuchsia-500 via-purple-600 to-cyan-600 shadow-[0_0_70px_rgba(232,121,249,0.55)]",
          state === "thinking" &&
            "border-violet-200/50 bg-gradient-to-br from-violet-500 via-purple-600 to-indigo-700 shadow-[0_0_55px_rgba(167,139,250,0.55)]",
          isConnecting &&
            "border-amber-200/40 bg-gradient-to-br from-amber-400 to-orange-600 shadow-[0_0_40px_rgba(251,191,36,0.4)] cursor-wait",
          isError &&
            "border-rose-200/40 bg-gradient-to-br from-rose-500 to-red-700 shadow-[0_0_40px_rgba(251,113,133,0.45)] hover:scale-[1.04]"
        )}
      >
        {/* inner glass */}
        <span className="absolute inset-[3px] rounded-full bg-gradient-to-b from-white/25 via-white/5 to-black/20" aria-hidden="true" />

        {isConnecting ? (
          <Loader2 className="relative h-8 w-8 animate-spin text-white" />
        ) : isError ? (
          <RotateCcw className="relative h-7 w-7 text-white" />
        ) : state === "disconnected" ? (
          <div className="relative flex flex-col items-center">
            <Mic className="h-7 w-7 text-white drop-shadow" />
          </div>
        ) : state === "thinking" ? (
          <Loader2 className="relative h-7 w-7 animate-spin text-white" />
        ) : isLive ? (
          <Square className="relative h-6 w-6 fill-white text-white" />
        ) : (
          <PlugZap className="relative h-7 w-7 text-white" />
        )}

        {/* speaking equalizer dots */}
        {state === "speaking" && (
          <span className="absolute -bottom-1 flex gap-1" aria-hidden="true">
            {[0, 1, 2].map((i) => (
              <span
                key={i}
                className="h-1.5 w-1.5 animate-bounce rounded-full bg-white"
                style={{ animationDelay: `${i * 0.15}s`, animationDuration: "0.7s" }}
              />
            ))}
          </span>
        )}
      </button>
    </div>
  );
}
