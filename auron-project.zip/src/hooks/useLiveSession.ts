import { useCallback, useEffect, useRef, useState } from "react";
import { LiveSession } from "../services/LiveSession";
import { AudioStreamer } from "../services/AudioStreamer";
import { AudioPlayer } from "../services/AudioPlayer";
import type {
  AssistantError,
  AssistantState,
  Captions,
  Character,
  CharacterVideoState,
  MicPermissionState,
  ToolActivityItem,
} from "../types/assistant";
import { DEFAULT_CHARACTER, DEFAULT_VOICE, FRIENDLY_ERRORS, GEMINI_MODEL } from "../config/constants";
import { getCharacterVideoState } from "../config/characterVideos";

const LS_KEY = "auron_api_key";
const LS_MODEL = "auron_model_v2";
const LS_MODEL_LEGACY = "auron_model";
const LS_VOICE = "auron_voice";
const LS_CHARACTER = "auron_character";
const LS_ANIM = "auron_anim_enabled";

function initialApiKey(): string {
  const env = (import.meta as unknown as { env: Record<string, string> }).env
    ?.VITE_GEMINI_API_KEY as string | undefined;
  if (env && env.length > 0) return env;
  try {
    return localStorage.getItem(LS_KEY) ?? "";
  } catch {
    return "";
  }
}

export function useLiveSession() {
  const [assistantState, setAssistantState] = useState<AssistantState>("disconnected");
  const [captions, setCaptions] = useState<Captions>({ user: "", assistant: "" });
  const [tools, setTools] = useState<ToolActivityItem[]>([]);
  const [error, setError] = useState<AssistantError | null>(null);
  const [apiKey, setApiKeyState] = useState<string>(initialApiKey);
  const [model, setModelState] = useState<string>(() => {
    try {
      // Prefer new key (defaults to 3.8). Migrate legacy key only if user
      // explicitly picked something other than the old 3.1 default.
      const current = localStorage.getItem(LS_MODEL);
      if (current) return current;
      const legacy = localStorage.getItem(LS_MODEL_LEGACY);
      if (legacy && legacy !== "gemini-3.1-flash-live-preview") return legacy;
      return GEMINI_MODEL;
    } catch {
      return GEMINI_MODEL;
    }
  });
  const [voice, setVoiceState] = useState<string>(() => {
    try {
      return localStorage.getItem(LS_VOICE) ?? DEFAULT_VOICE;
    } catch {
      return DEFAULT_VOICE;
    }
  });
  const [character, setCharacterState] = useState<Character>(() => {
    try {
      const saved = localStorage.getItem(LS_CHARACTER);
      return saved === "priya" ? "priya" : DEFAULT_CHARACTER;
    } catch {
      return DEFAULT_CHARACTER;
    }
  });
  const [animationEnabled, setAnimationEnabledState] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem(LS_ANIM);
      if (saved !== null) return saved !== "off";
    } catch {
      /* noop */
    }
    try {
      if (window.matchMedia?.("(prefers-reduced-motion: reduce)").matches) return false;
    } catch {
      /* noop */
    }
    return true;
  });
  const [micPermission, setMicPermission] = useState<MicPermissionState>("unknown");
  const [sessionStartedAt, setSessionStartedAt] = useState<number | null>(null);

  const videoState: CharacterVideoState = getCharacterVideoState(assistantState);
  const characterRef = useRef<Character>(character);
  characterRef.current = character;

  const liveRef = useRef<LiveSession | null>(null);
  const streamerRef = useRef<AudioStreamer | null>(null);
  const playerRef = useRef<AudioPlayer | null>(null);
  const stateRef = useRef<AssistantState>("disconnected");
  const inputLevelRef = useRef<number>(0);
  const outputLevelRef = useRef<number>(0);
  const lastSendRef = useRef<number>(0);
  const lastInputActiveRef = useRef<number>(0);
  const bargeCountRef = useRef<number>(0);
  const rafRef = useRef<number>(0);
  const userAccumRef = useRef<string>("");
  const assistantAccumRef = useRef<string>("");

  const syncState = useCallback((s: AssistantState) => {
    stateRef.current = s;
    setAssistantState(s);
  }, []);

  // Mic permission probe
  useEffect(() => {
    let cancelled = false;
    const probe = async () => {
      try {
        const nav = navigator as unknown as {
          permissions?: { query: (o: { name: string }) => Promise<{ state: string }> };
        };
        if (!nav.permissions?.query) return;
        const res = await nav.permissions.query({ name: "microphone" as never });
        if (cancelled) return;
        if (res.state === "granted") setMicPermission("granted");
        else if (res.state === "denied") setMicPermission("denied");
        else setMicPermission("prompt");
      } catch {
        /* unsupported */
      }
    };
    probe();
    return () => {
      cancelled = true;
    };
  }, []);

  // Level polling + client VAD / thinking heuristic / barge-in
  useEffect(() => {
    const loop = () => {
      const st = stateRef.current;
      const live = st === "listening" || st === "thinking" || st === "speaking";
      if (live) {
        try {
          const inLevel = streamerRef.current?.getInputLevel() ?? 0;
          const outLevel = playerRef.current?.getOutputLevel() ?? 0;
          inputLevelRef.current = inLevel;
          outputLevelRef.current = outLevel;
          const now = performance.now();

          if (inLevel > 0.18) {
            lastInputActiveRef.current = now;
          }

          // Instant Thinking Trigger: As soon as user speaks (inLevel was active) and finishes speaking (>350ms silence)
          if (st === "listening" && lastInputActiveRef.current > 0) {
            const sinceActive = now - lastInputActiveRef.current;
            if (sinceActive > 380 && sinceActive < 12000 && inLevel < 0.08) {
              syncState("thinking");
            }
          }

          // Client barge-in: loud mic while Auron speaking → cut playback fast
          if (st === "speaking" && inLevel > 0.28) {
            bargeCountRef.current += 1;
            if (bargeCountRef.current >= 4) {
              bargeCountRef.current = 0;
              try {
                playerRef.current?.interrupt();
              } catch {
                /* noop */
              }
              syncState("listening");
              lastInputActiveRef.current = now;
            }
          } else {
            bargeCountRef.current = Math.max(0, bargeCountRef.current - 1);
          }
        } catch {
          /* meter errors are non-fatal */
        }
      } else {
        inputLevelRef.current *= 0.9;
        outputLevelRef.current *= 0.9;
      }
      rafRef.current = requestAnimationFrame(loop);
    };
    rafRef.current = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(rafRef.current);
  }, [syncState]);

  const setApiKey = useCallback((k: string) => {
    setApiKeyState(k);
    try {
      localStorage.setItem(LS_KEY, k);
    } catch {
      /* noop */
    }
  }, []);

  const setModel = useCallback((m: string) => {
    setModelState(m);
    try {
      localStorage.setItem(LS_MODEL, m);
    } catch {
      /* noop */
    }
  }, []);

  const setVoice = useCallback((v: string) => {
    setVoiceState(v);
    try {
      localStorage.setItem(LS_VOICE, v);
    } catch {
      /* noop */
    }
  }, []);

  const setCharacter = useCallback(
    (c: Character) => {
      setCharacterState(c);
      try {
        localStorage.setItem(LS_CHARACTER, c);
      } catch {
        /* noop */
      }
      // Auto-align voice to character default ONLY when idle (never break a live session).
      // Mark -> Fenrir (male), Priya -> Aoede (female).
      const live = stateRef.current === "listening" || stateRef.current === "thinking" || stateRef.current === "speaking";
      if (!live) {
        const def = c === "priya" ? "Aoede" : "Fenrir";
        const isMaleVoice = ["Fenrir", "Charon", "Puck", "Orus"].includes(voice);
        const needsSwitch =
          (c === "priya" && isMaleVoice) || (c === "mark" && !isMaleVoice);
        if (needsSwitch) {
          setVoiceState(def);
          try {
            localStorage.setItem(LS_VOICE, def);
          } catch {
            /* noop */
          }
        }
      }
    },
    [voice]
  );

  const setAnimationEnabled = useCallback((on: boolean) => {
    setAnimationEnabledState(on);
    try {
      localStorage.setItem(LS_ANIM, on ? "on" : "off");
    } catch {
      /* noop */
    }
  }, []);

  const cleanupAudio = useCallback(() => {
    try {
      streamerRef.current?.stop();
    } catch {
      /* noop */
    }
    streamerRef.current = null;
    // Keep player instance for quick reconnect? Stop on full disconnect.
  }, []);

  const disconnect = useCallback(() => {
    try {
      liveRef.current?.disconnect();
    } catch {
      /* noop */
    }
    liveRef.current = null;
    cleanupAudio();
    try {
      playerRef.current?.interrupt();
    } catch {
      /* noop */
    }
    lastSendRef.current = 0;
    syncState("disconnected");
    setSessionStartedAt(null);
  }, [cleanupAudio, syncState]);

  const connect = useCallback(async () => {
    if (stateRef.current === "connecting") return;
    setError(null);
    userAccumRef.current = "";
    assistantAccumRef.current = "";
    setCaptions({ user: "", assistant: "" });
    setTools([]);

    const key = apiKey.trim();
    if (!key) {
      const err: AssistantError = {
        type: "MissingApiKey",
        message: "Missing API key",
        friendlyMessage: FRIENDLY_ERRORS.MissingApiKey,
        recoverable: true,
      };
      setError(err);
      syncState("error");
      return;
    }

    syncState("connecting");

    try {
      // Player first (needs user gesture)
      if (!playerRef.current) playerRef.current = new AudioPlayer();
      const player = playerRef.current;
      await player.resume();
      player.setCallbacks({
        onFirstChunk: () => {
          if (stateRef.current === "thinking" || stateRef.current === "listening") {
            syncState("speaking");
          }
        },
        onDrained: () => {
          if (stateRef.current === "speaking" || stateRef.current === "thinking") {
            syncState("listening");
          }
        },
      });

      // Mic
      const streamer = new AudioStreamer();
      streamerRef.current = streamer;
      setMicPermission("prompt");
      await streamer.start((b64) => {
        lastSendRef.current = performance.now();
        liveRef.current?.sendAudio(b64);
      });
      setMicPermission("granted");

      // Live session — character controls persona + greeting; video follows audio state.
      const live = new LiveSession();
      liveRef.current = live;
      await live.connect({
        apiKey: key,
        model,
        voice,
        character: characterRef.current,
        player,
        handlers: {
          onStateChange: (s) => {
            syncState(s);
            if (s === "listening" || s === "speaking" || s === "thinking") {
              setSessionStartedAt((prev) => prev ?? Date.now());
            }
          },
          onUserTranscript: (text) => {
            if (!text) return;
            userAccumRef.current = (userAccumRef.current + text).slice(-500);
            const u = userAccumRef.current;
            setCaptions((prev) => ({ ...prev, user: u }));
          },
          onAssistantTranscript: (text) => {
            if (!text) return;
            // Avoid runaway duplication: if new chunk already suffix, skip
            const prev = assistantAccumRef.current;
            if (text.length > 0 && prev.endsWith(text)) return;
            assistantAccumRef.current = (prev + text).slice(-600);
            const a = assistantAccumRef.current;
            setCaptions((prevCap) => ({ ...prevCap, assistant: a }));
            // New assistant text implies user turn ended — reset user accum for next turn after delay?
          },
          onToolActivity: (item) => {
            setTools((prev) => {
              const idx = prev.findIndex((t) => t.id === item.id);
              if (idx >= 0) {
                const copy = [...prev];
                copy[idx] = item;
                return copy.slice(-6);
              }
              return [...prev, item].slice(-6);
            });
            // Clear assistant accum on new tool so post-tool speech starts fresh? keep.
          },
          onError: (e) => {
            const friendly =
              FRIENDLY_ERRORS[e.type] ?? e.friendlyMessage ?? FRIENDLY_ERRORS.UnknownError;
            setError({ ...e, friendlyMessage: friendly });
          },
          onInterrupted: () => {
            // User barged in — freshen accumulators for next turn
            userAccumRef.current = "";
            // keep assistant caption visible briefly
          },
        },
      });

      // Reset accumulators on each model turn? Track turn boundaries via captions clearing timer:
      // When assistant starts new turn after user, clear old assistant text if turnComplete happened.
      // Simplified: clear assistant accum when user speaks anew after silence.
    } catch (e: unknown) {
      console.error("[Auron] connect error", e);
      const name = (e as Error)?.name ?? "";
      cleanupAudio();
      if (name === "MicrophonePermissionDenied") {
        setMicPermission("denied");
        setError({
          type: "MicrophonePermissionDenied",
          message: "Mic denied",
          friendlyMessage: FRIENDLY_ERRORS.MicrophonePermissionDenied,
          recoverable: true,
        });
        syncState("error");
      } else if (name === "MicrophoneNotFound") {
        setError({
          type: "AudioContextError",
          message: "No microphone found",
          friendlyMessage: "No microphone found. Connect a mic and retry.",
          recoverable: true,
        });
        syncState("error");
      } else if ((e as Error)?.message === "MissingApiKey") {
        // already set
      } else if ((stateRef.current as string) === "connecting") {
        // LiveSession already set error state via handlers; ensure error object exists
        setError((prev) =>
          prev ??
          ({
            type: "GeminiConnectionError",
            message: "Connect failed",
            friendlyMessage: FRIENDLY_ERRORS.GeminiConnectionError,
            recoverable: true,
          } as AssistantError)
        );
        syncState("error");
      }
    }
  }, [apiKey, model, voice, cleanupAudio, syncState]);

  const toggle = useCallback(() => {
    const s = stateRef.current;
    if (s === "disconnected" || s === "error") {
      // Reset accumulators on manual reconnect
      userAccumRef.current = "";
      assistantAccumRef.current = "";
      connect();
    } else if (s === "connecting") {
      return;
    } else {
      disconnect();
    }
  }, [connect, disconnect]);

  const retry = useCallback(() => {
    disconnect();
    window.setTimeout(() => connect(), 350);
  }, [connect, disconnect]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      try {
        liveRef.current?.disconnect();
      } catch {
        /* noop */
      }
      try {
        streamerRef.current?.stop();
      } catch {
        /* noop */
      }
      try {
        playerRef.current?.stop();
      } catch {
        /* noop */
      }
    };
  }, []);

  const isLive =
    assistantState === "listening" ||
    assistantState === "thinking" ||
    assistantState === "speaking";

  return {
    assistantState,
    videoState,
    captions,
    tools,
    error,
    apiKey,
    setApiKey,
    model,
    setModel,
    voice,
    setVoice,
    character,
    setCharacter,
    animationEnabled,
    setAnimationEnabled,
    micPermission,
    sessionStartedAt,
    isLive,
    inputLevelRef,
    outputLevelRef,
    connect,
    disconnect,
    toggle,
    retry,
  };
}
