import type { AssistantState, Character, CharacterVideoState } from "../types/assistant";

/**
 * Centralized character video configuration.
 * Drop the 6 provided MP4s into `public/videos/` with EXACT names:
 *   Mark_idle.mp4, Mark_thinking.mp4, Mark_speaking.mp4
 *   Priya_idle.mp4, Priya_thinking.mp4, Priya_speaking.mp4
 *
 * Do NOT mix Mark and Priya assets — selection controls the set.
 */
export const characterVideos: Record<Character, Record<CharacterVideoState, string>> = {
  mark: {
    idle: "/videos/Mark_idle.mp4",
    thinking: "/videos/Mark_thinking.mp4",
    speaking: "/videos/Mark_speaking.mp4",
  },
  priya: {
    idle: "/videos/Priya_idle.mp4",
    thinking: "/videos/Priya_thinking.mp4",
    speaking: "/videos/Priya_speaking.mp4",
  },
};

export const CHARACTER_META: Record<
  Character,
  {
    name: string;
    title: string;
    tagline: string;
    gender: "male" | "female";
    defaultVoice: string;
    accentColor: string;
    image: string;
  }
> = {
  mark: {
    name: "Mark",
    title: "Male AI Companion",
    tagline: "Confident · Witty · Charismatic",
    gender: "male",
    defaultVoice: "Fenrir",
    accentColor: "cyan",
    image: "/characters/mark.jpg",
  },
  priya: {
    name: "Priya",
    title: "Female AI Companion",
    tagline: "Warm · Sharp · Expressive",
    gender: "female",
    defaultVoice: "Aoede",
    accentColor: "fuchsia",
    image: "/characters/priya.jpg",
  },
};

/**
 * Single source of truth: AssistantState -> CharacterVideoState
 *  disconnected -> idle
 *  connecting   -> idle
 *  listening    -> idle   (no separate listening video — intentional)
 *  thinking     -> thinking
 *  speaking     -> speaking (only when audio actually plays)
 *  error        -> idle
 */
export function getCharacterVideoState(assistantState: AssistantState): CharacterVideoState {
  if (assistantState === "thinking") return "thinking";
  if (assistantState === "speaking") return "speaking";
  return "idle";
}

export function getVideoSrc(character: Character, videoState: CharacterVideoState): string {
  return characterVideos[character][videoState];
}
